import {exportGlobal} from 'digitalexp-light-framework';

import Widget from './widget/Test';
import ConnectedWidget from './widget/Test.connect';
import descriptor from '../digitalexp-test-base-l9-module.descriptor';

const widgetObj = {
    Widget,
    ConnectedWidget,
    descriptor,
    id: descriptor.widgetId
};


export default widgetObj;

exportGlobal(`amdocs.widgets.${widgetObj.id}`, widgetObj);
