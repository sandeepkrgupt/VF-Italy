import {connect} from 'react-redux';
import sdk from 'digitalexp-light-sdk-l9';
import GlobalErrorApi from 'digitalexp-global-error-api-l9';
import LoaderApi from 'digitalexp-loader-api-l9';
import CustomerApi from 'digitalexp-customer-api';
import DecoratedComponent from './Test';

export const OUTCOMES = {
    ON_BUTTON_CLICK: 'ON_BUTTON_CLICK'
};

const {getApiInstance} = sdk.getInstance();
const globalErrorApi = getApiInstance(GlobalErrorApi);
const loaderApi = getApiInstance(LoaderApi);
const customerApi = getApiInstance(CustomerApi);

const {errorDecorator} = globalErrorApi;
const {loaderDecorator} = loaderApi;

export const mapStateToProps = (state) => {  
    return {        
        customerId: customerApi.getCustomerId()
    };   
};

export const mapDispatchToProps = (dispatch) => {
    return {
        @errorDecorator
        @loaderDecorator
        asyncAction: () => {
            return new Promise((resolve) => {
                setTimeout(resolve, 1000);
            });
        },
        onButtonClick: () => {
            dispatch({
                type: OUTCOMES.ON_BUTTON_CLICK
            });
        }
    };
};

const ConnectedLoaderWidget = connect(
    mapStateToProps,
    mapDispatchToProps
)(DecoratedComponent);

export default ConnectedLoaderWidget;
