class PropsProvider {
    constructor(context) {
        this.context = context;
    }
    getComponentProps(props) {
        const {config, onButtonClick} = props;
        const {defaultName, displayTitle} = config;
        return {
            intl: props.intl,
            widgetName: config.defaultName,
            displayTitle,
            onButtonClick,
            name: props.name
        };
    }
}

export default PropsProvider;
