import Component from './Test.component';
import Decorator from './Test.decorator';

export default Decorator(Component);
