import {Container} from 'digitalexp-common-components-l9';
import defaultConfig from './Test.config';

const ContainerDecorator = Container({
    config: {
        ...defaultConfig
    },
    propTypes: {
    }
});

export default ContainerDecorator;
