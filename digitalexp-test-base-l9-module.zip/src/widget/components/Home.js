import React, {Component} from 'react';

export default function Home() {
    return <h1>Hoome</h1>;
}
