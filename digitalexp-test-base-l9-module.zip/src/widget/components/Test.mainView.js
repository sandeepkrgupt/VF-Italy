import React from 'react';
import {FormattedMessage} from 'react-intl';
import messages from '../Test.i18n';

export default function TestMainView({widgetName, displayTitle, name, onButtonClick, intl}) {
    // such handlers, which are bound to specific JSX should be part of the view component
    const handleInputChange = (event) => {
        const value = event.target.value;
        onButtonClick(value);
    };
    return (
        <div>
            {displayTitle &&
            (<h1>
                <FormattedMessage {...messages.test} values={{name: widgetName}} />
            </h1>)
            }
            <input
                type="button"
                value={intl.formatMessage(messages.dispatchAction)}
                onClick={handleInputChange} />          
        </div>
    );
}

