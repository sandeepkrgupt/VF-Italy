import React, {Component} from 'react';
import PropTypes from 'prop-types';

import TestMainView from './components/Test.mainView';
import TestProps from './Test.propsProvider';
import Home from './components/Home';

const types = {
    name: 'txtname',
    value: 'Enter Your FirstName',
    id: 1,
    btnName: 'Ok'
};

class TestComponent extends Component {

    static get contextTypes() {
        return {
            policy: PropTypes.func,
            permissions: PropTypes.object,
            config: PropTypes.object
        };
    }

    constructor(props) {
        super(props);
        this.props = props;
        const {
            messages
        } = this.props;
        this.state = {
            disabled: false,
            msg: messages
        };
        this.propsProvider = new TestProps(this.context);
        this.welcomeToTest = this.welcomeToTest.bind(this);
        this.handleDisplay = this.handleDisplay.bind(this);
        this.handleChange = this.handleChange.bind(this);
        console.log('this.props.messages', messages);
    }

    handleChange(resp) {
        console.log(resp, 'handleChange');
        this.setState({
            value: resp
        });
    }

    handleDisplay() {
        console.log('test app');
        this.setState({
            disabled: true
        });
    }

    welcomeToTest() {
        return (
            <div className="ds-field__title">
                <h1>Welcome To Test App</h1>
                <span>Your Name </span>
                <input 
                    id={types.id} 
                    name={types.name} 
                    value={types.value} 
                    onChange={() => this.handleChange(types.value)} 
                    disabled={this.state.disabled} />
                <input 
                    id={types.id} 
                    name={types.name} 
                    value={types.value} 
                    onChange={() => this.handleChange(types.value)} 
                    disabled={this.state.disabled} />
                <button onClick={() => this.handleDisplay()}>{types.btnName}</button>
            </div>
        );
    }

    render() {
        return (
            <TestMainView {...this.propsProvider.getComponentProps(this.props)} />,
                {...this.welcomeToTest(this.props)}
        );
    }
}

export default TestComponent;

