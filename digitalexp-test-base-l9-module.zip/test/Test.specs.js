/* eslint no-unused-expressions: 0  prefer-arrow-callback: 0 */
import React from 'react';

import {expect} from 'chai';
import {shallow} from 'enzyme';

import Test from '../src/widget/Test';

export function tests() {
    describe('DigitalExpTestWidget', function() {
        context('when instantiated', function() {
            it('initialization', function() {
                const wrapper = shallow(<Test />);
                expect(wrapper).to.not.be.null;
            }); 
        });
    });
}

export default tests();
