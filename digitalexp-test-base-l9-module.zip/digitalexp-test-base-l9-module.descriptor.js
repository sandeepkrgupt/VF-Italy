const descriptor = {
    displayName: 'digitalexp-test-base-l9-module',
    widgetId: 'digitalexp-test-base-l9-module',
    widgetCategory: 'Digital Experience',
    widgetDomain: 'Application',
    widgetSalesChannel: 'Base',
    widgetDescription: 'testing purpose only',
    topicName: 'test',
    behaviorParams: [
        {
            groupId: '',
            itemId: 'displayTitle',
            displayName: 'Show Title',
            type: 'boolean',
            description: 'Determine to display or nto the title.',
            defaultValue: true
        }
    ],
    outcomes: [
        /*{
            displayName: '',
            actionId: 'dummy_action_id',
            actionType: 'navigate',
            defaultValue: '',
            description: ''
        }*/
    ],
    content: [
        {
            groupId: '',
            displayName: 'test message',
            itemId: 'test',
            description: '',
            defaultValue: 'This is a test View for: {name}'
        },
        {
            groupId: '',
            displayName: 'dispatchAction',
            itemId: 'dispatchAction',
            description: '',
            defaultValue: 'Dispatch Action'
        }
    ],
    groups: [
        /*{
            groupId: 'groupId',
            displayName: 'display name'
        }*/
    ],
    initializationParams: [
        /*{
            itemId: '',
            displayName: '',
            type: 'boolean',
            description: '',
            defaultValue: true,
            enableUrlInput: true
        }*/
    ],
    stateParams: [
        /*{
            itemId: '',
            displayName: '',
            type: 'boolean',
            description: '',
            defaultValue: true
        }*/
    ]
};

module.exports = descriptor;
