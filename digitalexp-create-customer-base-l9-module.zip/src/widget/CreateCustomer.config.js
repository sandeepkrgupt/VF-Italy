import descriptor from '../../digitalexp-create-customer-base-l9-module.descriptor';

// Import the behaviors from the descriptor
const {behaviorParams} = descriptor;
const descriptorValues = behaviorParams.reduce((map, descriptorBehaviour) => {
    const {itemId, defaultValue} = descriptorBehaviour;
    map[itemId] = defaultValue;
    return map;
}, {});

export default {
    ...descriptorValues    
};
