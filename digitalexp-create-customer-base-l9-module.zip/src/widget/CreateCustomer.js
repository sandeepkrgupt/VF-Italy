import CreateCustomerComponent from './CreateCustomer.component';
import CreateCustomerDecorator from './CreateCustomer.decorator';

const decoratedComponent = CreateCustomerDecorator(CreateCustomerComponent);
export default decoratedComponent;
