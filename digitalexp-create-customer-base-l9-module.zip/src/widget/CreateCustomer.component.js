import React, {Component} from 'react';
import PropTypes from 'prop-types';
import isEmpty from 'lodash/isEmpty';
import _omit from 'lodash/omit';
import moment from 'moment';
import ExternalizeComponent from 'digitalexp-generic-button-control-module/lib/common/ExternalizeComponent';
import CreateCustomerProps from './CreateCustomer.propsProvider';
import CreateCustomer from './createCustomer/CreateCustomerComponent';
import ReviewCustomer from './reviewCustomer/ReviewCustomerComponentView';
import EligibilityCheckView from './createCustomer/CreateCustomer.eligibilityCheckView';
import {WIDGET_MODES, COMPONENT_MODES, SECTIONS, ComponentMode, DATE_FORMAT} from './CreateCustomer.consts';

class CreateCustomerComponent extends Component {
    static get childContextTypes() {
        return {
            config: PropTypes.object
        };
    }

    static get contextTypes() {
        return {
            MESSAGE_CONTEXT: PropTypes.string
        };
    }

    constructor(props, context) {
        super(props, context);

        this.state = {
            isEditFlow: false,
            isFormInvalid: false,
            showEligibilityCheckPopup: false
        };

        this.showEligibilityCheck = this.showEligibilityCheck.bind(this);
        this.handleCreateCustomer = this.handleCreateCustomer.bind(this);
        this.handleUpdateCustomer = this.handleUpdateCustomer.bind(this);
        this.changeLinkHandler = this.changeLinkHandler.bind(this);
        this.saveLinkHandler = this.saveLinkHandler.bind(this);
        this.cancelLinkHandler = this.cancelLinkHandler.bind(this);
        this.editCustomer = this.editCustomer.bind(this);
        this.getSubmitHandler = this.getSubmitHandler.bind(this);
        this.callExternalizeComponent = this.callExternalizeComponent.bind(this);
        this.setFormInvalid = this.setFormInvalid.bind(this);

        this.createCustomerProps = new CreateCustomerProps(context);
    }

    getChildContext() {
        return {config: this.props.config};
    }

    componentDidMount() {
        this.props.onLoadEventTagging();
        // Provide controller to connect
        this.props.provideController({
            getIntl: () => this.props.intl,
            getMessageContext: () => this.context.MESSAGE_CONTEXT
        });

        const {
            customerId, 
            customerDetails, 
            loadCustomerDetails,
            loadCustomerReferenceData, 
            loadContactMethods,
            loadPreferredContactTime,
            loadPreferredLanguages,
            contactMethods,
            identificationTypes,
            preferredcontactTime,
            preferredLanguage
        } = this.props;
        
        if (isEmpty(contactMethods)) {
            loadContactMethods();
        }

        if (isEmpty(identificationTypes)) {
            loadPreferredContactTime();
        }
        if (isEmpty(preferredLanguage)) {
            loadPreferredLanguages();
        }

        if (isEmpty(preferredcontactTime)) {
            loadCustomerReferenceData();
        }

        if (isEmpty(customerDetails) && customerId) {
            loadCustomerDetails(customerId);
        }
    }

    componentWillUnmount() {
        const {clearWidgetMessages, provideController} = this.props;

        clearWidgetMessages();

        // Remove controller from connect
        provideController(null);
    }

    getCreateCustomerDisplayProps() {
        const {customerDetails, userInformation, alreadyUpdated} = this.props;
        const {owningIndividual} = customerDetails;
        if (owningIndividual) {
            if (owningIndividual.birthDate && owningIndividual.birthDate.length > 0) {
                const formattedDate = moment(owningIndividual.birthDate).format(DATE_FORMAT.DISPLAY_FORMAT);
                if (formattedDate !== owningIndividual.birthDate) {
                    owningIndividual.birthDate = formattedDate;
                }
            }

            if (owningIndividual.gender && owningIndividual.gender.length > 0) {
                owningIndividual.gender = owningIndividual.gender.replace(/^\w/, c => c.toUpperCase());
            }

            const mailObj = owningIndividual.email;
            if (mailObj.emailAddress && mailObj.emailAddress.length > 0 && !mailObj.confirmEmailAddress) {
                owningIndividual.email.confirmEmailAddress = mailObj.emailAddress;
            }
        }

        let omittedOwningIndividual = owningIndividual;

        const {customer = []} = userInformation;

        if (!isEmpty(customer) && !alreadyUpdated) {
            const {identification} = owningIndividual;
            const omittedIdentification = _omit(identification, [
                'identificationType',
                'identificationNumber',
                'nationality'
            ]);
            omittedOwningIndividual = {
                ...omittedOwningIndividual,
                identification: omittedIdentification
            };
        }

        return {
            ...this.getCreateCustomerProps(),
            customerDetails: {
                ...customerDetails,
                owningIndividual: omittedOwningIndividual
            }
        };
    } 

    getPersonalDetailsHeader() {
        const {config: {
            showPersonalDetailsComponentTitle,
            showPersonalDetailsComponentIcon,
            showPersonalDetailsComponentInformationText,
            showChangeLinkInPersonalDetailsComponentInViewMode,
            showRevertLinkInPersonalDetailsComponentInEditMode,
            showSaveLinkInPersonalDetailsComponentInEditMode
        }} = this.props;
        return {
            showSectionTitle: showPersonalDetailsComponentTitle,
            showSectionIcon: showPersonalDetailsComponentIcon,
            showSectionInformationText: showPersonalDetailsComponentInformationText,
            changeLinkDetails: {
                showChangeLink: showChangeLinkInPersonalDetailsComponentInViewMode,
                handleChange: () => { this.changeLinkHandler(SECTIONS.PERSONAL_DETAILS); }
            },
            revertLinkDetails: {
                showRevertLink: showRevertLinkInPersonalDetailsComponentInEditMode,
                handleRevert: () => { this.cancelLinkHandler(SECTIONS.PERSONAL_DETAILS); }
            },
            saveLinkDetails: {
                showSaveLink: showSaveLinkInPersonalDetailsComponentInEditMode,
                handleSave: () => { this.saveLinkHandler(SECTIONS.PERSONAL_DETAILS); }
            }
        };
    }

    getIdDetailsHeader() {
        const {config: {
            showIDDetailsComponentTitle,
            showIDDetailsComponentIcon,
            showIDDetailsComponentInformationText,
            showChangeLinkInIDDetailsComponentInViewMode,
            showRevertLinkInIDDetailsComponentInEditMode,
            showSaveLinkInIDDetailsComponentInEditMode
        }} = this.props;
        return {
            showSectionTitle: showIDDetailsComponentTitle,
            showSectionIcon: showIDDetailsComponentIcon,
            showSectionInformationText: showIDDetailsComponentInformationText,
            changeLinkDetails: {
                showChangeLink: showChangeLinkInIDDetailsComponentInViewMode,
                handleChange: () => { this.changeLinkHandler(SECTIONS.ID_DETAILS); }
            },
            revertLinkDetails: {
                showRevertLink: showRevertLinkInIDDetailsComponentInEditMode,
                handleRevert: () => { this.cancelLinkHandler(SECTIONS.ID_DETAILS); }
            },
            saveLinkDetails: {
                showSaveLink: showSaveLinkInIDDetailsComponentInEditMode,
                handleSave: () => { this.saveLinkHandler(SECTIONS.ID_DETAILS); }
            }
        };
    }

    getComponentModes() {
        const {config, setAddressEventTagging} = this.props;
        const {addressComponentMode} = config;
        const state = this.state;
        const personalDetailsComponentMode = state.personalDetailsComponentMode || config.personalDetailsComponentMode;
        const IDDetailsComponentMode = state.IdDetailsComponentMode || config.IDDetailsComponentMode;
        return {
            personalDetailsComponentMode,
            IDDetailsComponentMode,
            addressComponentMode,
            setAddressEventTagging
        };
    }

    getCreateCustomerProps() {
        const {isEditFlow, isFormInvalid} = this.state;
        return {
            getValidationForField: this.createCustomerProps.getValidationForField(this.props),
            personalDetailsHeader: this.getPersonalDetailsHeader(),
            idDetailsHeader: this.getIdDetailsHeader(),
            addressDetailsHeader: this.createCustomerProps.getAddressDetailsHeader(this.props),
            addressDetails: this.createCustomerProps.getAddressDetails(this.props, isEditFlow),
            onSubmit: this.getSubmitHandler,
            loadBirthPlacesData: this.props.loadBirthPlacesData,
            clearGeneralMessage: this.props.clearWidgetMessages,
            showGeneralMessage: this.props.showGeneralMessage,
            setAddressDetails: this.props.setAddressDetails,
            findCaller: this.props.findCaller,
            onContinueIncorrectMSISDN: this.props.onContinueIncorrectMSISDN,
            onContinueIncompatiblePM: this.props.onContinueIncompatiblePM,
            contactNumberDetails: this.props.contactNumberDetails,
            selectedPaymentMethod: this.props.selectedPaymentMethod,
            selectedPaymentOption: this.props.selectedPaymentOption,
            orderId: this.props.orderId,
            isFormInvalid,
            setFormInvalid: this.setFormInvalid,
            isLoggedIn: this.props.isLoggedIn,
            ...this.getComponentModes(),
            ...this.createCustomerProps.getCommonProps(this.props)
        };
    }

    getReviewCustomerProps() {
        const {isEditFlow} = this.state;
        return {
            getValidationForField: this.createCustomerProps.getValidationForField(this.props),
            personalDetailsHeader: this.getPersonalDetailsHeader(),
            idDetailsHeader: this.getIdDetailsHeader(),
            addressDetailsHeader: this.createCustomerProps.getAddressDetailsHeader(this.props),
            addressDetails: this.createCustomerProps.getAddressDetails(this.props, isEditFlow),
            handleEdit: this.editCustomer,
            ...this.getComponentModes(),
            ...this.createCustomerProps.getCommonProps(this.props)
        };
    }

    getSubmitHandler(values) {
        const {customerId} = this.props;
        if (customerId) {
            return this.handleUpdateCustomer(values);
        }
        return this.handleCreateCustomer(values);
    }

    setFormInvalid () {
        this.setState({
            isFormInvalid: true
        });
    }

    changeLinkHandler(section) {
        this.setState({
            [section + ComponentMode]: COMPONENT_MODES.EDIT
        });
    }

    saveLinkHandler(section) {
        this.setState({
            [section + ComponentMode]: COMPONENT_MODES.VIEW
        });
    }

    cancelLinkHandler(section) {
        this.setState({
            [section + ComponentMode]: COMPONENT_MODES.VIEW
        });
    }

    mergeAdditionalValues(values) {
        const {addressDetails: {postalAddress, billingAddress}} = values;
        const {contactId, identificationId} = this.props;
        const newValues = values;
        if (postalAddress) {
            newValues.owningIndividual.postalAddress = postalAddress;
            if (billingAddress) {
                newValues.billingAddress = billingAddress;
            }
            delete newValues.addressDetails;
        }
        if (contactId) {
            newValues.owningIndividual.id = contactId;
        }
        if (identificationId) {
            newValues.owningIndividual.identification.identObjId = identificationId;
        }
        return newValues;
    }

    editCustomer() {
        this.props.editCustomer();
    }

    showEligibilityCheck() {
        const {
            clearCartAndCustomerData: cancelOrder,
            clearCartData
        } = this.props;
        return (
            <EligibilityCheckView 
                cancelOrder={() => {
                    this.setState({
                        showEligibilityCheckPopup: false
                    });
                    cancelOrder();
                }}
                clearCartData={() => {
                    this.setState({
                        showEligibilityCheckPopup: false
                    });
                    clearCartData();
                }}
                />
        ); 
    }

    handleCreateCustomer(values = {}) {
        const mergedValues = this.mergeAdditionalValues(values);
        const {owningIndividual = {}} = values;
        const {fiscalCode} = owningIndividual;

        return this.props.createCustomer(mergedValues).then((customerId) => {
            if (this.props.orderId) {
                this.props.associateCustomerWithCart(customerId, this.props.orderId, fiscalCode)
                    .then((eligibilityCheck) => {
                        if (eligibilityCheck) {
                            this.setState({
                                showEligibilityCheckPopup: true
                            });
                        } else {
                            this.callExternalizeComponent();
                        }
                    });
            } else {
                this.callExternalizeComponent();
                Promise.resolve(customerId);
            }
        }, (err) => {
            const {duplicateCustomerError} = err;
            if (duplicateCustomerError) {
                this.setState({showDuplicateCustomerModal: true});
            }
            this.setFormInvalid();
            Promise.reject();
        });
    }

    handleUpdateCustomer(values) {
        const mergedValues = this.mergeAdditionalValues(values);
        return this.props.updateCustomer(mergedValues).then((customerId) => {
            this.props.setAlreadyUpdated();
            this.callExternalizeComponent();
            Promise.resolve(customerId);
        }, () => {
            this.setFormInvalid();
            Promise.reject();
        });
    }

    callExternalizeComponent () {
        const {config} = this.props;
        const {onCustomerSubmit} = config;
        if (onCustomerSubmit) {
            const externalizeObj = ExternalizeComponent.getExternalizedComponent(onCustomerSubmit);
            if (externalizeObj.functionCallback) {
                externalizeObj.functionCallback();
            }
        }
    }

    render() {
        const {config, customerId} = this.props;
        const {displayMode} = config;
        const {showEligibilityCheckPopup} = this.state;
        if (displayMode === WIDGET_MODES.REVIEW) {
            return (
                <ReviewCustomer
                    {...this.getReviewCustomerProps()}
                    personalDetailsComponentMode={COMPONENT_MODES.VIEW}
                    IDDetailsComponentMode={COMPONENT_MODES.VIEW}
                    addressComponentMode={COMPONENT_MODES.VIEW}
                />
            );
        } else if (displayMode === WIDGET_MODES.CREATE) {
            if (customerId) {
                return (
                    <CreateCustomer
                        {...this.getCreateCustomerDisplayProps()}
                        personalDetailsComponentMode={COMPONENT_MODES.EDIT}
                        IDDetailsComponentMode={COMPONENT_MODES.EDIT}
                        addressComponentMode={COMPONENT_MODES.EDIT}
                        showEligibilityCheckPopup={showEligibilityCheckPopup}
                        showEligibilityCheck={this.showEligibilityCheck}
                        isEditEnabled
                    />
                );
            }
            return (
                <CreateCustomer
                    {...this.getCreateCustomerProps()}
                    personalDetailsComponentMode={COMPONENT_MODES.NEW}
                    IDDetailsComponentMode={COMPONENT_MODES.NEW}
                    addressComponentMode={COMPONENT_MODES.NEW}
                />
            );
        }
        return null;
    }
}

export default CreateCustomerComponent;
