import {connect} from 'react-redux';
import {
    OUTCOMES as BASEOUTCOMES,
    mapStateToProps as baseMapStateToProps,
    mapDispatchToProps as baseMapDispatchToProps
} from 'digitalexp-create-customer-base-module/lib/widget/CreateCustomer.connect';
import sdk from 'digitalexp-light-sdk-l9';
import CustomerProfileApi from 'digitalexp-customer-profile-api-l9';
import CustomerApiL9 from 'digitalexp-customer-api-l9';
import AddressManagementApiL9 from 'digitalexp-address-management-api-l9';
import MessageHandlerApiL9 from 'digitalexp-message-handler-api-l9';
import CartApi from 'digitalexp-cart-api-l9';
import TagManagementApi from 'digitalexp-tag-management-api-l9';
import CheckoutFlowApi, {consts as checkoutFlowConsts} from 'digitalexp-checkout-flow-api-l9';
import UserManagementApi from 'digitalexp-user-management-api';
import ServicabilityApi from 'digitalexp-servicability-api-l9';
import PlanSettingsApi from 'digitalexp-plan-settings-api-l9';
import OrderApi from 'digitalexp-order-api-l9';
import GlobalErrorApi from 'digitalexp-global-error-api-l9';
import LoaderApi from 'digitalexp-loader-api-l9';
import PageUrlApi from 'digitalexp-page-url-api-l9';
import find from 'lodash/find';
import get from 'lodash/get';
import shoppingCartConsts from 'digitalexp-shopping-cart-base-module/lib/widgets/ShoppingCart/ShoppingCart.consts';
import CreateCustomerBase from './CreateCustomer';
import descriptor from '../../digitalexp-create-customer-base-l9-module.descriptor';
import {GeneralMessageConfiguration, TagManagement} from './CreateCustomer.consts';

const {getApiInstance} = sdk.getInstance();
const customerProfileApi = getApiInstance(CustomerProfileApi);
const customerApiL9 = getApiInstance(CustomerApiL9);
const serviceAddress = getApiInstance(AddressManagementApiL9).getInstance('servicabilityAddress');
const addressManagementApiL9 = getApiInstance(AddressManagementApiL9).getInstance('create_customer_postalAddress');
const messageHandlerApiL9 = getApiInstance(MessageHandlerApiL9);
const cartApi = getApiInstance(CartApi);
const tagManagementApi = getApiInstance(TagManagementApi);
const checkoutFlowApi = getApiInstance(CheckoutFlowApi);
const userManagementApi = getApiInstance(UserManagementApi);
const servicabilityApi = getApiInstance(ServicabilityApi);
const planSettingsApi = getApiInstance(PlanSettingsApi);
const orderApi = getApiInstance(OrderApi);
const globalErrorApi = getApiInstance(GlobalErrorApi);
const loaderApi = getApiInstance(LoaderApi);
const pageUrlApi = getApiInstance(PageUrlApi);

const {errorDecorator} = globalErrorApi;
const {loaderDecorator} = loaderApi;

const createCustomerL9Outcomes = {
    NAVIGATE_TO_PLAN_LIST: 'NAVIGATE_TO_PLAN_LIST'
};

export const OUTCOMES = {
    ...BASEOUTCOMES,
    ...createCustomerL9Outcomes
};

const getConfiguredPlan = (paymentOptions) => {
    const configuredPlan = find(paymentOptions, (plan) => {
        return plan.configured;
    });
    return configuredPlan;
};

export const mapStateToProps = (state, ownProps) => {
    const planConfiguration = planSettingsApi.getPlanConfig();
    const paymentOptions =
        planConfiguration && planConfiguration.paymentOptions ? [...planConfiguration.paymentOptions] : [];
    const selectedPaymentOption = getConfiguredPlan(paymentOptions);
    return {
        ...baseMapStateToProps(state, ownProps),
        birthPlaces: customerApiL9.getBirthPlaces(),
        preferredcontactTime: customerProfileApi.getContactTime(),
        preferredLanguage: customerProfileApi.getPreferredLanguages(),
        countries: addressManagementApiL9.getCountries(),
        serviceabilityAddress: serviceAddress.getAddress(),
        postalAddress: addressManagementApiL9.getAddress(),
        userInformation: userManagementApi.getUserInformation(),
        alreadyUpdated: customerProfileApi.getAlreadyUpdated(),
        contactNumberDetails: servicabilityApi.getContactNumberData(),
        selectedPaymentMethod: planSettingsApi.getConfiguredPaymentMethod(),
        selectedPaymentOption,
        contactId: customerProfileApi.getContactId(),
        identificationId: customerProfileApi.getIdentificationId()
    };
};

export const mapDispatchToProps = (dispatch, ownProps) => {
    const cartCheckOut = (orderId, customerId) => {
        return cartApi.checkout().then(() => {
            const {checkoutStatus} = cartApi.getAdditionalData();
            if (checkoutStatus === shoppingCartConsts.checkoutStatus.DELIVERY_OPTIONS) {
                dispatch({
                    type: OUTCOMES.CUSTOMER_CART_DELIVERY_OPTIONS_REQUIRED,
                    payload: {orderId, customerId}
                });
            } else if (checkoutStatus === shoppingCartConsts.checkoutStatus.COMPLETED) {
                dispatch({
                    type: OUTCOMES.CUSTOMER_CART_CHECKOUT_COMPLETED,
                    payload: {orderId, customerId}
                });
            }
        });
    };
    const navigateToPlanList = (URL) => {
        dispatch({type: OUTCOMES.NAVIGATE_TO_PLAN_LIST, payload: {URL}});
    };
    const getPlanListUrlBasedOnPOType = () => {
        const cart = cartApi.getCart();
        const cartItem = get(cart, 'cartItem[0]');
        if (cartItem) {
            const PO = cartApi.getCartItemPO(cartItem);
            // Get the URL for pageUrlApi
            const URL = pageUrlApi.getPlanListUrl(PO);
            return URL;
        }
        return null;
    };
    return {
        ...baseMapDispatchToProps(dispatch, ownProps),
        @errorDecorator
        @loaderDecorator
        associateCustomerWithCart: (customerId, orderId, fiscalCode) => {
            let eligibilityCheck = false;
            return cartApi.associateCustomerWithCart(customerId, orderId, fiscalCode).then((cart) => {
                const {id: cartId} = cart;
                const validationStatus = cart.cartValidation.status;
                if (validationStatus === shoppingCartConsts.CartValidationStatus.BLOCKED) {
                    eligibilityCheck = true;
                    return eligibilityCheck;
                }
                cartCheckOut(orderId, customerId);
                return eligibilityCheck;
            });
        },

        clearCartData: () => {
            const URL = getPlanListUrlBasedOnPOType();
            cartApi.deleteCart().then(() => {
                navigateToPlanList(URL);
            });
        },

        clearCartAndCustomerData: () => {
            const URL = getPlanListUrlBasedOnPOType();
            cartApi.deleteCart().then(() => {
                customerApiL9.clear();
                navigateToPlanList(URL);
            });
        },
        provideController: (ctl) => {
            this.ctl = ctl;
        },
        @errorDecorator
        @loaderDecorator
        loadContactMethods: () => {
            return customerProfileApi.fetchContactMediumOptions();
        },
        @errorDecorator
        @loaderDecorator
        loadBirthPlacesData: async (registryCode) => {
            const birthPlaces = await customerApiL9.loadBirthPlaces(registryCode);
            return birthPlaces;
        },
        @errorDecorator
        @loaderDecorator
        loadPreferredContactTime: () => {
            return customerProfileApi.fetchPreferredContactTime();
        },
        @errorDecorator
        @loaderDecorator
        updateCustomer: (updateCustomerPayload) => {
            return customerProfileApi.updateCustomer(updateCustomerPayload);
        },
        showGeneralMessage: (primaryMessage, category = GeneralMessageConfiguration.BUSINESS, errorCode = null) => {
            messageHandlerApiL9.addErrorMessage({
                primaryMessage,
                category,
                errorCode,
                messageContext: this.ctl.getMessageContext(),
                messageOrigin: descriptor.widgetId
            });
        },
        clearWidgetMessages: () => {
            messageHandlerApiL9.clearMessagesByOrigin(descriptor.widgetId);
        },
        setAddressDetails: (address) => {
            addressManagementApiL9.setAddressDetails(address);
        },
        onLoadEventTagging: () => {
            if (checkoutFlowApi.getFlow() &&
                    checkoutFlowApi.getFlow()[0].state === checkoutFlowConsts.flowStepState.EDIT) {
                tagManagementApi.setCustomLink(TagManagement.INFORMATION_ID_SECONDARY_PAGE);
                tagManagementApi.setEvent(TagManagement.CHECKOUT_START_EVENT,
                    tagManagementApi.eventCategories.SALES);
                tagManagementApi.tag(tagManagementApi.tagTypes.LINK);
            }
        },
        setAddressEventTagging: () => {
            if (checkoutFlowApi.getFlow() &&
                    checkoutFlowApi.getFlow()[0].state === checkoutFlowConsts.flowStepState.EDIT) {
                tagManagementApi.setCustomLink(TagManagement.ADDRESS_SECONDARY_PAGE);
                tagManagementApi.setEvent(TagManagement.CHECKOUT_ADDRESS_EVENT,
                    tagManagementApi.eventCategories.SALES);
                tagManagementApi.tag(tagManagementApi.tagTypes.LINK);
            }
        },
        setAlreadyUpdated: () => {
            customerProfileApi.setAlreadyUpdated();
        },
        isLoggedIn: () => {
            const userInformation = userManagementApi.getUserInformation();
            const {isUserLogin} = userInformation || {};
            return isUserLogin;
        },
        @errorDecorator
        @loaderDecorator
        findCaller: (fiscalCode) => {
            return customerProfileApi.findCaller(fiscalCode);
        },
        @errorDecorator
        @loaderDecorator
        onContinueIncorrectMSISDN: () => {
            const URL = getPlanListUrlBasedOnPOType();

            return cartApi.deleteCart().then(() => {
                orderApi.clear();
                servicabilityApi.setShowServcability(true);
                servicabilityApi.setForceShowServcability(true);
                servicabilityApi.setContactNumberDetails({});
                navigateToPlanList(URL);
            });
        },
        @errorDecorator
        @loaderDecorator
        onContinueIncompatiblePM: (payload) => {
            return planSettingsApi.savePlanSettings(payload);
        },
        @errorDecorator
        @loaderDecorator
        loadPreferredLanguages: () => {
            return customerProfileApi.loadPreferredLanguages();
        }
    };
};

const ConnectedWidget = connect(
    mapStateToProps,
    mapDispatchToProps
)(CreateCustomerBase);

export default ConnectedWidget;
