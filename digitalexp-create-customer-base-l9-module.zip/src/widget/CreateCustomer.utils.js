import getConfig, {appConfig} from 'digitalexp-runtime-configuration-l9';
import {Formatter} from 'digitalexp-formatters-l9-module';
import clone from 'lodash/clone';
import Messages from './CreateCustomer.i18n';
import {GeneralMessageConfiguration} from './CreateCustomer.consts';

export default class CreateCustomerUtils {
    static getIdDocumentValidations(intl, config, mandatoryFieldValidation = false) {
        const {showIDDocumentAttachment, IDDocumentAttachmentMandatory} = config;
        let idDocumentValidations = {};
        if (showIDDocumentAttachment) {
            if (IDDocumentAttachmentMandatory && mandatoryFieldValidation) {
                idDocumentValidations = {
                    presence: {message: {
                        ...Messages.id_document_mandatory_validation, 
                        ...{fieldLabel: Messages.id_document_label.defaultMessage, 
                            errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                    }}
                };
            }
            const validAttachmentFileFormats = getConfig('validAttachmentFileFormats');
            const noOfValidAttachmentFileFormats = validAttachmentFileFormats.length;
            const maxAttachmentSize = getConfig('maxAttachmentSize');
            const maxAttachmentSizeUnitOfMeasure = getConfig('maxAttachmentSizeUnitOfMeasure');
            idDocumentValidations = {
                ...idDocumentValidations,
                fileFormat: {
                    formats: validAttachmentFileFormats,
                    message: {
                        ...Messages.id_document_invalid_file_format_validation, 
                        ...{
                            defaultMessage: 
                                intl.formatMessage(
                                        Messages.id_document_invalid_file_format_validation,
                                    {
                                        formats: validAttachmentFileFormats
                                            .slice(0, noOfValidAttachmentFileFormats - 1)
                                            .join(', '),
                                        lastFormat: validAttachmentFileFormats[noOfValidAttachmentFileFormats - 1]
                                    })
                        },
                        ...{fieldLabel: Messages.id_document_label.defaultMessage,
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }
                },
                fileSize: {
                    max: maxAttachmentSize,
                    unitOfMeasure: maxAttachmentSizeUnitOfMeasure,
                    message: {
                        ...Messages.id_document_max_file_size_validation, 
                        ...{
                            defaultMessage: 
                                intl.formatMessage(
                                        Messages.id_document_max_file_size_validation,
                                    {
                                        maxSize: maxAttachmentSize,
                                        unitOfMeasure: maxAttachmentSizeUnitOfMeasure
                                    })
                        },
                        ...{fieldLabel: Messages.id_document_label.defaultMessage,
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }
                }
            };
        }
        return idDocumentValidations;
    }

    static getMinMaxValidation(config, intl) {
        const {validatePhoneNumberMinDigits, validatePhoneNumberMaxDigits} = config;
        const phoneNumberMaxDigits = getConfig('phoneNumberMaxDigits');
        const phoneNumberMinDigits = getConfig('phoneNumberMinDigits');
        let phoneMinMaxValidation = {};
        if (validatePhoneNumberMaxDigits) {
            phoneMinMaxValidation = {
                maximum: phoneNumberMaxDigits,
                tooLong: {...Messages.phone_validation_max_length, 
                    ...{defaultMessage: 
                        intl.formatMessage(Messages.phone_validation_max_length, {phoneNumberMaxDigits})
                    },
                    ...{fieldLabel: Messages.contactNumber_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                }
            };
        }

        if (validatePhoneNumberMinDigits) {
            phoneMinMaxValidation = {
                ...phoneMinMaxValidation,
                minimum: phoneNumberMinDigits,
                tooShort: {...Messages.phone_validation_min_length, 
                    ...{defaultMessage: 
                        intl.formatMessage(Messages.phone_validation_min_length, {phoneNumberMinDigits})
                    },
                    ...{fieldLabel: Messages.contactNumber_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                }
            };
        }
        return phoneMinMaxValidation;
    }

    static getPhoneValidations(config) {
        const phoneNumberPrefix = getConfig('phoneNumberPrefix');
        const {validatePhoneNumberPrefix} = config;
        let phoneValidation = {};

        // TODO: add pattern configuration support
        if (validatePhoneNumberPrefix) {
            phoneValidation = {
                format: {
                    pattern: `^[${phoneNumberPrefix}][0-9]+`,
                    flags: 'i',
                    message: {
                        ...Messages.phone_prefix_validation, 
                        ...{fieldLabel: Messages.contactNumber_label.defaultMessage, 
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }
                }
            };
        }
        return phoneValidation;
    }
  
    static getMinAgeValidations(intl, config) {
        const {validateMinimumAge, minimumAge} = config;
        if (validateMinimumAge) {
            return {
                minAge: {
                    age: minimumAge,
                    message: {...Messages.min_age_validation, 
                        ...{defaultMessage: intl.formatMessage(Messages.min_age_validation, {minimumAge})
                        },
                        ...{fieldLabel: Messages.birthDate_label.defaultMessage, 
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }
                }
            };
        }
        return {};
    }

    static validations(intl, config, mandatoryFieldValidation = false) {
        const {addressLengthLimit,
            cityLengthLimit,
            zipLengthLimit,
            defaultExpirationOffset} = config;
        const firstnameMaxLength = getConfig('firstNameMaxChars');
        const lastnameMaxLength = getConfig('lastNameMaxChars');
        const maxCharsInEmailAddress = getConfig('maxCharsInEmailAddress');
        const maxYearRangePast = getConfig('maxYearRangePast');
        const maxYearRangeFuture = getConfig('maxYearRangeFuture');
        const {phoneNoFormat, fiscalCodeMaxLength, fiscalCodeMinLength, letterOnly} = appConfig;
        const validation = {
            firstName: {
                presence: {message: {
                    ...Messages.firstname_validation_presence, 
                    ...{fieldLabel: Messages.firstname_label.defaultMessage, 
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }},
                length: {
                    maximum: firstnameMaxLength,
                    tooLong: {
                        ...Messages.firstname_validation_max_length, 
                        ...{fieldLabel: Messages.firstname_label.defaultMessage, 
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }},
                format: {
                    pattern: letterOnly,
                    flags: 'i',
                    message: {
                        ...Messages.firstname_formate_validation,
                        fieldLabel: Messages.firstname_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION
                    }
                }
            },
            lastName: {
                presence: {message: {
                    ...Messages.lastname_validation_presence, 
                    ...{fieldLabel: Messages.lastname_label.defaultMessage, 
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }},
                length: {
                    maximum: lastnameMaxLength,
                    tooLong: {
                        ...Messages.lastname_validation_max_length, 
                        ...{fieldLabel: Messages.lastname_label.defaultMessage, 
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }},
                format: {
                    pattern: letterOnly,
                    flags: 'i',
                    message: {
                        ...Messages.lastname_formate_validation,
                        fieldLabel: Messages.lastname_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION
                    }
                }
            },
            gender: {
                presence: {message: {
                    ...Messages.gender_validation_presence, 
                    ...{fieldLabel: Messages.gender_label.defaultMessage, 
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }}
            },
            birthDate: {
                ...this.getMinAgeValidations(intl, config)
            },
            phone: {
                length: {
                    ...this.getMinMaxValidation(config, intl)
                },
                presence: {message: {
                    ...Messages.phone_validation_presence, 
                    ...{fieldLabel: Messages.contactNumber_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }},
                format: {
                    pattern: phoneNoFormat,
                    flags: 'i',
                    message: {
                        ...Messages.phone_prefix_validation,
                        fieldLabel: Messages.contactNumber_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION
                    }
                },
                ...this.getPhoneValidations(config)
            },
            preferredContactMethod: {
                presence: {message: {
                    ...Messages.preferred_contact_validation_presence, 
                    ...{fieldLabel: Messages.preferredContact_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }}
            },
            preferredContactTime: {
                presence: {message: {
                    ...Messages.preferred_contact_time_validation_presence,
                    ...{fieldLabel: Messages.preferredContactTime_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }}
            },
            preferredLanguage: {
                presence: {message: {
                    ...Messages.preferred_langugage_validation_presence,
                    ...{fieldLabel: Messages.preferredLanguage_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }}
            },
            email: {
                length: {
                    maximum: maxCharsInEmailAddress,
                    tooLong: {...Messages.email_validation_max_length, 
                        ...{fieldLabel: Messages.email_label.defaultMessage, 
                            errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                    }
                },
                optionalEmail: {message: {
                    ...Messages.email_validation_email, 
                    ...{fieldLabel: Messages.email_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                }},
                presence: {
                    message: {
                        ...Messages.email_validation_presence,
                        fieldLabel: Messages.email.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY
                    }
                }
            },
            confirmEmail: {
                length: {
                    maximum: maxCharsInEmailAddress,
                    tooLong: {...Messages.email_validation_max_length, 
                        ...{fieldLabel: Messages.confirm_email_label.defaultMessage, 
                            errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                    }
                },
                optionalEmail: {message: {
                    ...Messages.email_validation_email, 
                    ...{fieldLabel: Messages.confirm_email_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                }},
                presence: {
                    message: {
                        ...Messages.confirm_email_validation_presence,
                        fieldLabel: Messages.confirm_email.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY
                    }
                }
            },
            idType: {
                selectListPresence: {message: {
                    ...Messages.idType_validation_presence, 
                    ...{fieldLabel: Messages.idType_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }}
            },
            idNumber: {
                presence: {message: {
                    ...Messages.idNumber_validation_presence, 
                    ...{fieldLabel: Messages.idNumber_label.defaultMessage, 
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }},
                format: {
                    pattern: '^[a-z0-9]+',
                    flags: 'i',
                    message: {
                        ...Messages.idNumber_validation_format, 
                        ...{fieldLabel: Messages.idNumber_label.defaultMessage, 
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }
                }
            },
            issuedBy: {
                presence: {message: {
                    ...Messages.issue_by_validation_presence, 
                    ...{fieldLabel: Messages.issuedBy_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }}
            },
            issuedOn: {
                presence: {message: {
                    ...Messages.issue_on_validation_presence, 
                    ...{fieldLabel: Messages.issuedOn_label.defaultMessage, 
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }},
                datetime: {
                    message: {...Messages.issued_on_validation,
                        ...{fieldLabel: Messages.issuedOn_label.defaultMessage,
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }
                },
                futureDate: {
                    message: {...Messages.issued_on_validation,
                        ...{fieldLabel: Messages.issuedOn_label.defaultMessage,
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }
                },
                tooEarlyDate: {
                    yearsLimit: maxYearRangePast,
                    message: {...Messages.date_validation_early,
                        ...{fieldLabel: Messages.issuedOn_label.defaultMessage,
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }
                }
            },
            expirationDate: {
                presence: {message: {
                    ...Messages.expiration_date_validation_presence, 
                    ...{fieldLabel: Messages.expirationDate_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }},
                format: {
                    pattern: '^[0-9]{4}-[0-9]{2}-[0-9]{2}$',
                    flags: 'i',
                    message: {...Messages.expiration_date_validation,
                        ...{fieldLabel: Messages.expirationDate_label.defaultMessage,
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }
                },
                datetime: {
                    message: {...Messages.expiration_date_validation,
                        ...{fieldLabel: Messages.expirationDate_label.defaultMessage,
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }
                },
                documentExpirationPast: {
                    message: {...Messages.expiration_date_validation_past,
                        ...{fieldLabel: Messages.expirationDate_label.defaultMessage,
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    },
                    expirationDaysOffset: defaultExpirationOffset
                },
                tooLateDate: {
                    yearsLimit: maxYearRangeFuture,
                    message: {...Messages.date_validation_late,
                        ...{fieldLabel: Messages.expirationDate_label.defaultMessage, 
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }
                }
            },
            address: {
                presence: {message: {
                    ...Messages.address_validation_presence, 
                    ...{fieldLabel: Messages.address_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }},
                length: {
                    maximum: addressLengthLimit,
                    tooLong: {...Messages.address_validation_max_length,
                        ...{fieldLabel: Messages.address_label.defaultMessage,
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }
                }
            },
            city: {
                presence: {message: {
                    ...Messages.city_validation_presence, 
                    ...{fieldLabel: Messages.city_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }},
                length: {
                    maximum: cityLengthLimit,
                    tooLong: {...Messages.city_validation_max_length,
                        ...{fieldLabel: Messages.city_label.defaultMessage,
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }
                }
            },
            country: {
                selectListPresence: {...Messages.country_validation_presence,
                    ...{fieldLabel: Messages.country_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }
            },
            zip: {
                presence: {message: {
                    ...Messages.zip_on_validation_presence, 
                    ...{fieldLabel: Messages.zip_label.defaultMessage, 
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }},
                length: {
                    maximum: zipLengthLimit,
                    tooLong: {...Messages.zip_validation_max_length,
                        ...{fieldLabel: Messages.zip_label.defaultMessage,
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }
                }
            },
            fiscalCode: {
                presence: {
                    message: {
                        ...Messages.fiscalCode_validation_presence,
                        fieldLabel: Messages.fiscalCode_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY
                    }
                },
                length: {
                    maximum: fiscalCodeMaxLength,
                    tooLong: {
                        ...Messages.fiscalCode_validation_max_length, 
                        fieldLabel: Messages.fiscalCode_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION
                    },
                    minimum: fiscalCodeMinLength,
                    tooShort: {
                        ...Messages.fiscalCode_invalid,
                        fieldLabel: Messages.fiscalCode_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION
                    }

                }
            },
            nationality: {
                presence: {
                    message: {
                        ...Messages.country_validation_presence,
                        fieldLabel: Messages.nationality_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY
                    }
                }
            },
            documentNationality: {
                presence: {
                    message: {
                        ...Messages.country_validation_presence,
                        fieldLabel: Messages.nationality_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY
                    }
                }
            },
            attachment: this.getIdDocumentValidations(intl, config, mandatoryFieldValidation),
            additionalAttachment: this.getIdDocumentValidations(intl, config, false)
        };
        return validation;
    }

    static formatIdentificationDates(identification) {
        const newIdentificationDates = clone(identification);
        newIdentificationDates.issueDate = Formatter.formatDateView(identification.issueDate);
        newIdentificationDates.expirationDate = Formatter.formatDateView(identification.expirationDate);
        return newIdentificationDates;
    }
}
