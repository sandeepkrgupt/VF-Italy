import React from 'react';
import moment from 'moment';
import _isEmpty from 'lodash/isEmpty';
import {DATE_FORMAT} from '../CreateCustomer.consts';

export default function ReviewCustomerComponentView({
    customerDetails,
    addressDetails
}) {
    if (_isEmpty(customerDetails)) {
        return null;
    }

    const {
        firstName,
        lastName,
        fiscalCode,
        email: {emailAddress},
        phone: {phoneNumber},
        birthDate
    } = customerDetails.owningIndividual;

    const {
        street,
        streetNumber,
        stateOrProvince,
        city,
        postalCode,
        displayCountry
    } = addressDetails.addressDetailsProps.customerAddress.postalAddress;

    return (
        <div className="ds-info-box review ds-container">
            <div className="ds-create-customer">
                <div className="row">
                    <div className="ds-flex-col col-xs-12 col-sm-4 col-xs-12 col-sm-4">
                        <span className="review__text text-capitalize">{firstName} {lastName}</span>
                        <span className="review__text">
                            {moment(birthDate).format(DATE_FORMAT.DISPLAY_FORMAT)}
                        </span>
                    </div>
                    <div className="ds-flex-col col-xs-12 col-sm-4">
                        <span className="review__text">{fiscalCode}</span>
                        <span className="review__text">
                            {street}, {streetNumber}, {postalCode}, {city} {stateOrProvince}, {displayCountry}
                        </span>
                    </div>
                    <div className="ds-flex-col col-xs-12 col-sm-4">
                        <span className="review__text">{emailAddress}</span>
                        <span className="review__text">{phoneNumber}</span>
                    </div>
                </div>
            </div>
        </div>
    );
}
