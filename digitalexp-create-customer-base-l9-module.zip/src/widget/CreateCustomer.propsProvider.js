import CreateCustomerUtilsL9 from './CreateCustomer.utils';
import AddressComponentConfig from
    './createCustomer/addressDetails/AddressComponent.config';
import {COMPONENT_MODES} from 
    './CreateCustomer.consts';
import defaultMessages from './CreateCustomer.i18n';


export default class customerPropsProvider {
    constructor(context) {
        this.context = context;
        this.getAddressDetails = this.getAddressDetails.bind(this);
    }
    getCommonProps(props) {
        const {
            intl,
            customerId,
            customerDetails,
            identificationTypes = [], 
            contactMethods = [],
            birthPlaces,
            config,
            preferredcontactTime = [],
            preferredLanguage = [],
            countries,
            setAddressEventTagging
        } = props;
        return {
            intl,
            customerId,
            customerDetails,
            identificationTypes,
            contactMethods,
            birthPlaces,
            config,
            preferredcontactTime,
            preferredLanguage,
            countries
        };
    }

    getValidationForField(props) {
        return (validationName, mandatoryFieldValidation = false) => {
            const {intl, config} = props;
            const validations = CreateCustomerUtilsL9.validations(intl, config, mandatoryFieldValidation);
            return validations[validationName];
        };
    }

    getAddressDetailsHeader(props) {
        const {config: {
            showAddressComponentTitle,
            showAddressComponentIcon,
            showAddressComponentInformationText,
            showChangeLinkInAddressComponentInViewMode,
            showRevertLinkInAddressComponentInEditMode,
            showSaveLinkInAddressComponentInEditMode
        }} = props;
        return {
            showSectionTitle: showAddressComponentTitle,
            showSectionIcon: showAddressComponentIcon,
            showSectionInformationText: showAddressComponentInformationText,
            changeLinkDetails: {
                showChangeLink: showChangeLinkInAddressComponentInViewMode
            },
            revertLinkDetails: {
                showRevertLink: showRevertLinkInAddressComponentInEditMode
            },
            saveLinkDetails: {
                showSaveLink: showSaveLinkInAddressComponentInEditMode
            }
        };
    }

    getAddressDetails(props, isEditFlow) {
        const {
            intl, 
            config, 
            customerId, 
            customerDetails = {}, 
            customerAddress = {},
            postalAddress = {},
            serviceabilityAddress = {}
        } = props;
        let displayModeForAddressDetails;
        if (customerDetails) {
            if (customerDetails.owningIndividual && customerDetails.owningIndividual.postalAddress) {
                customerAddress.postalAddress = customerDetails.owningIndividual.postalAddress;
            }
            customerAddress.billingAddress = customerDetails.billingAddress;        
        }
        if (isEditFlow) {
            displayModeForAddressDetails = COMPONENT_MODES.EDIT;
        } else {
            displayModeForAddressDetails = config.addressComponentMode;
        }
    
        const addressConfig = {
            ...AddressComponentConfig,
            ...config,
            displayMode: displayModeForAddressDetails,
            showChangeLinkInViewMode: config.showChangeLinkInAddressComponentInViewMode,
            showCancelLinkInEditMode: config.showRevertLinkInAddressComponentInEditMode,
            showSaveLinkInEditMode: config.showSaveLinkInAddressComponentInEditMode,
            showInformationText: config.showAddressComponentInformationText
        };
        return {
            config: addressConfig,
            addressDetailsProps: {
                customerId,
                customerAddress,
                postalAddress,
                serviceabilityAddress,
                messages: {
                    address_details_title_part_1: intl.formatMessage(defaultMessages.contact_address_title_text1),
                    address_details_title_part_2: intl.formatMessage(defaultMessages.contact_address_title_text2)
                }
            }
        };
    }
}
