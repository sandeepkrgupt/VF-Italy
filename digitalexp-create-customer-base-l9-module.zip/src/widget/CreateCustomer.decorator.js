import PropTypes from 'prop-types';
import {Container} from 'digitalexp-common-components-l9';
import defaultConfig from './CreateCustomer.config';

const ContainerDecorator = Container({
    config: {
        ...defaultConfig,
        propTypes: {
            identificationTypes: PropTypes.arrayOf(PropTypes.string),
            genderTypes: PropTypes.arrayOf(PropTypes.string),
            preferredContactMethods: PropTypes.arrayOf(PropTypes.string),
            locale: PropTypes.string,
            salesChannel: PropTypes.string,
            orderId: PropTypes.string,
            shoppingCartId: PropTypes.string,
            customerId: PropTypes.string
        }
    }
});

export default ContainerDecorator;
