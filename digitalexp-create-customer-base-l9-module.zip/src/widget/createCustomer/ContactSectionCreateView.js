import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {FormField, ComboBox} from 'digitalexp-common-components-l9';
import _isEqual from 'lodash/isEqual';
import classNames from 'classnames';
import {FormattedMessage} from 'react-intl';
import Messages from '../CreateCustomer.i18n';
import TooltipView from './TooltipView';
import SubmitButtonView from './SubmitButtonView';
import {GeneralMessageConfiguration} from '../CreateCustomer.consts';

const {PhoneNumber, Email} = FormField;

export default class ContactSectionCreateView extends Component {
    static get contextTypes() {
        return {
            getFieldValue: PropTypes.func,
            registerFieldConstraints: PropTypes.func
        };
    }

    constructor(props) {
        super(props);

        const {isEditEnabled} = props;

        this.state = {
            isAccordianCollapsed: !isEditEnabled,
            hideAccordian: isEditEnabled
        };
    }

    componentDidMount = () => {
        const {updateFields} = this.props;
        updateFields([{name: 'owningIndividual.preferredLanguage.name', value: 'it-IT'}]);
    };
    componentWillReceiveProps(nextProps) {
        const {showContinue, isEditEnabled, isFormInvalid} = this.props;
        const {
            showContinue: nextShowContinue,
            isEditEnabled: nextIsEditEnabled,
            isFormInvalid: nextIsFormInvalid
        } = nextProps;
        if (!_isEqual(showContinue, nextShowContinue)) {
            this.setState({
                isAccordianCollapsed: false
            });
        }
        if (!_isEqual(isEditEnabled, nextIsEditEnabled) || !_isEqual(isFormInvalid, nextIsFormInvalid)) {
            this.setState({
                isAccordianCollapsed: false,
                hideAccordian: true
            });
        }
    }

    toggleAccordian = () => {
        const {isAccordianCollapsed} = this.state;
        this.setState({
            isAccordianCollapsed: !isAccordianCollapsed
        });
    };

    render() {
        const {isAccordianCollapsed, hideAccordian} = this.state;

        const {
            intl,
            config,
            formFields,
            getValidationForField,
            addressMainView,
            contactMethods,
            preferredcontactTime,
            preferredLanguage,
            formSubmit,
            submitButtonDetails,
            showContinue,
            isEditEnabled,
            isFormInvalid
        } = this.props;

        const {getFieldValue, registerFieldConstraints} = this.context;

        const accordionClassName = classNames({
            collapsed: isAccordianCollapsed,
            accordian: !hideAccordian
        });

        const getValidationForConfirmEmailAddress = () => {
            const emailValue = getFieldValue('owningIndividual.email.emailAddress');
            return registerFieldConstraints({
                name: 'owningIndividual.email.confirmEmailAddress',
                constraints: {
                    ...getValidationForField('confirmEmail'),
                    equalityCheckWithValue: {
                        valueToCheck: emailValue,
                        message: {
                            ...Messages.confirm_email_not_matching,
                            fieldLabel: Messages.confirm_email.defaultMessage,
                            errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY
                        }
                    }
                }
            });
        };

        const {MandatoryField, Field} = formFields;

        const getContactTimeAndMethod = () => {
            return (
                <div className="ds-row">
                    <Field
                        Component={ComboBox}
                        label={intl.formatMessage(Messages.preferred_contact_method)}
                        name="owningIndividual.preferredContactMethod.name"
                        items={contactMethods}
                        allowItemAdd="true"
                        displayField="displayName"
                        placeholder="Select"
                        searchable={false}
                        config={{
                            hasIcon: true,
                            fieldWrapperClassName: 'col-xs-12 col-sm-4'
                        }}
                        constraints={getValidationForField('preferredContactMethod')}
                        skipConstraints={['presence']}
                    />
                    {config.showPreferredContactTime && (
                        <Field
                            Component={ComboBox}
                            label={intl.formatMessage(Messages.preferred_time)}
                            name="owningIndividual.preferredContactTime.name"
                            items={preferredcontactTime}
                            allowItemAdd="true"
                            displayField="displayName"
                            placeholder="Select"
                            searchable={false}
                            config={{
                                hasIcon: true,
                                fieldWrapperClassName: 'col-xs-12 col-sm-4'
                            }}
                            constraints={getValidationForField('preferredContactTime')}
                            skipConstraints={['presence']}
                        />
                    )}
                    <Field
                        Component={ComboBox}
                        label={intl.formatMessage(Messages.preferred_language)}
                        name="owningIndividual.preferredLanguage.name"
                        items={preferredLanguage}
                        allowItemAdd="true"
                        displayField="displayName"
                        placeholder="Select"
                        searchable={false}
                        config={{
                            hasIcon: true,
                            fieldWrapperClassName: 'col-xs-12 col-sm-4'
                        }}
                        constraints={getValidationForField('preferredLanguage')}
                        skipConstraints={['presence']}
                    />
                </div>
            );
        };

        return (
            <div className="ds-form">
                <fieldset className="ds-form__fieldset">
                    <div className={accordionClassName}>
                        <header
                            className="accordian__header"
                            onClick={!showContinue && !isEditEnabled && !isFormInvalid && this.toggleAccordian}
                        >
                            <div className="ds-title">                                <span className="ds-title__text">                                    <FormattedMessage                                        {...Messages.contactAddressLabel} />                                </span>                            </div>
                        </header>
                        <div className="accordian__body">
                            <section className="contact">
                                <div className="ds-row">
                                    <div className="col-xs-12">
                                        <div className="ds-title__inner ds-row">
                                            <div className="ds-title col-xs-12 col-sm-2">
                                                <span className="ds-title__text">                                                    <FormattedMessage                                                        {...Messages.contactLabel} />                                                </span>
                                            </div>
                                            {config.showContactDetailsTooltip && (
                                                <div className="col-xs-12 col-sm-10">
                                                    <TooltipView
                                                        tooltipTextMessageLabel={
                                                            Messages.contact_details_tooltip_link_text
                                                        }
                                                        id={'contact-details'}
                                                        innerComponent={() => {
                                                            return (
                                                                <section className="ds-tooltip-item__content">
                                                                    <div className="ds-tooltip__text">
                                                                        <FormattedMessage
                                                                            {...Messages.contact_details_tooltip_text}
                                                                        />
                                                                    </div>
                                                                </section>
                                                            );
                                                        }}
                                                    />
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                                <div className="ds-row">
                                    <MandatoryField
                                        Component={Email}
                                        label={intl.formatMessage(Messages.email)}
                                        config={{fieldIconClassName: '', fieldWrapperClassName: 'col-xs-12 col-sm-6'}}
                                        name="owningIndividual.email.emailAddress"
                                        type="text"
                                        constraints={getValidationForField('email')}
                                        skipConstraints={['presence']}
                                    />
                                </div>
                                <div className="ds-row">
                                    <MandatoryField
                                        config={{
                                            hasIcon: true,
                                            fieldIconClassName: '',
                                            fieldWrapperClassName: 'col-xs-12 col-sm-6'
                                        }}
                                        Component={PhoneNumber}
                                        type="text"
                                        placeholder={intl.formatMessage(Messages.phone_number_prefix)}
                                        usePlaceholder="true"
                                        label={intl.formatMessage(Messages.phone_number)}
                                        name="owningIndividual.phone.phoneNumber"
                                        constraints={getValidationForField('phone')}
                                        skipConstraints={['presence']}
                                    />
                                    <div className="col-xs-12 col-sm-6" />
                                </div>
                                {getContactTimeAndMethod()}
                            </section>
                            <section className="address">
                                <div className="ds-row">
                                    <div className="ds-title__inner col-xs-12">
                                        <div className="ds-title">                                            <span className="ds-title__text">                                                <FormattedMessage                                                    {...Messages.address_label} />                                            </span>                                        </div>
                                    </div>
                                </div>
                                {addressMainView()}
                            </section>
                            <SubmitButtonView {...submitButtonDetails} formSubmit={formSubmit} config={config} />
                        </div>
                    </div>
                </fieldset>
            </div>
        );
    }
}
