/**
 * Created by DEVALC on 8/25/2017.
 */
import React, {Component} from 'react';
import PropTypes from 'prop-types';
import isEqual from 'lodash/isEqual';
import cloneDeep from 'lodash/cloneDeep';
import isEmpty from 'lodash/isEmpty';
import get from 'lodash/get';
import {FormField, Form} from 'digitalexp-common-components-l9';
import CreateCustomerComponentView from
    './CreateCustomerComponentView';
import defaultMessages from '../CreateCustomer.i18n';
import {GeneralMessageConfiguration, individualIdentificationType, MONTH_NAME, COMPONENT_MODES, FiscalDerivedMaxAgeLimit} from
    '../CreateCustomer.consts';
import CodeFiscale from '../CodeFiscale.utils';

const {FormContainer} = Form;
const {getDefaultValuesFromOptions, MandatoryField, Field} = FormField;

@FormContainer({hasDefaults: true})
export default class CreateCustomerComponent extends Component {
    static get contextTypes() {
        return {
            config: PropTypes.object,
            intl: PropTypes.object
        };
    }
    constructor(props) {
        super(props);
        this.getCreateCustomerProps = this.getCreateCustomerProps.bind(this);
        this.handleIdentificationChange = this.handleIdentificationChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleFormValidation = this.handleFormValidation.bind(this);
        this.handleAddressFormValidation = this.handleAddressFormValidation.bind(this);
        const {isEditEnabled = false, isFormInvalid = false} = this.props;
        this.getPropsFromFiscalCode = this.getPropsFromFiscalCode.bind(this);
        this.getPropsBirthPlaces = this.getPropsBirthPlaces.bind(this);
        this.getUniqueBirthYear = this.getUniqueBirthYear.bind(this);
        this.continueInIdentificationDetailsHandler = this.continueInIdentificationDetailsHandler.bind(this);

        this.state = {
            showContinueInIdentificationDetails: true,
            isEditEnabled,
            isFormInvalid,
            savedIdentifications: {},
            currentIdType: ''
        };
        this.prevBirthPlaceCode = '';
    }

    componentWillMount() {        
        this.initializeData();
        const {addressDetails, addressComponentMode, setAddressDetails} = this.props;
        const {addressDetailsProps} = addressDetails;
        const {customerAddress, serviceabilityAddress, postalAddress} = addressDetailsProps;
        if (COMPONENT_MODES.NEW === addressComponentMode &&
            (!(postalAddress) || !(customerAddress && customerAddress.postalAddress)) && 
        (serviceabilityAddress)) {
            setAddressDetails(serviceabilityAddress);
        }                    
    }

    componentWillReceiveProps(newProps) {
        const {identificationTypes, isFormInvalid} = newProps;
        if (this.props.identificationTypes && this.props.identificationTypes.length !== identificationTypes.length) {
            const identificationType = getDefaultValuesFromOptions(identificationTypes);
            this.props.updateField(
                {name: individualIdentificationType, value: identificationType},
            );
        }
        if (!isEqual(this.props.isFormInvalid, isFormInvalid)) {
            this.setState({
                isFormInvalid
            });
        }
    }

    componentWillUpdate() {
        this.initializeData();
    }

    getCreateCustomerHeaderProps() {
        const {config: {showScreenPurposeText}} = this.context;
        return {
            showScreenPurposeText
        };
    }

    getPersonalDetails() {
        const {personalDetailsHeader, personalDetailsComponentMode,
            contactMethods, customerSubTitles, nameTitles,
            preferredcontactTime, preferredLanguage, countries} = this.props;
        return {
            contactMethods,
            preferredcontactTime,
            preferredLanguage,
            countries,
            personalDetailsHeader,
            personalDetailsComponentMode,
            customerSubTitles,
            nameTitles
        };
    }

    getIdentificationDetails() {
        const {showAdditionalIDDocumentAttachment} = this.state;
        const {
            idDetailsHeader, 
            IDDetailsComponentMode, 
            identificationTypes, 
            getFieldValue, 
            getFieldError
        } = this.props;
        const {config: {showIDDocumentAttachment, IDDocumentAttachmentMandatory, allowIDDocumentAttachmentByCamera,
            allowIDDocumentAttachmentByFileBrowser}} = this.context;
        const additionalIdDocument = getFieldValue('owningIndividual.individualAttachment.additional');
        const additionalIdDocumentError = getFieldError('owningIndividual.individualAttachment.additional');
        return {
            idDetails: {
                identificationTypes,
                showIDDocumentAttachment,
                allowIDDocumentAttachmentByCamera,
                allowIDDocumentAttachmentByFileBrowser,
                showAdditionalIDDocumentAttachment: showAdditionalIDDocumentAttachment || additionalIdDocument,
                showAdditionalIDDocumentAttachmentLabel: additionalIdDocument && !additionalIdDocumentError,
                IDDocumentAttachmentMandatory,
                handleIdentificationChange: this.handleIdentificationChange
            },
            idDetailsHeader,
            IDDetailsComponentMode
        };
    }

    async getPropsBirthPlaces() {
        const {
            getFieldValue,
            loadBirthPlacesData,
            updateFormErrors,
            intl,
            personalDetailsComponentMode,
            isLoggedIn} = this.props;
        const fiscalCodeValue = this.getFiscalCodeValue();
        const birthPlaceCode = getFieldValue('owningIndividual.fiscalCode')
            .replace(/\s/g, '').substring(11, 15).toUpperCase();
        if (birthPlaceCode !== '' && birthPlaceCode.length === 4 &&
            ((personalDetailsComponentMode === COMPONENT_MODES.EDIT && isLoggedIn()) ||
            personalDetailsComponentMode === COMPONENT_MODES.NEW)) {
            try {
                await loadBirthPlacesData(birthPlaceCode);
            } catch (err) {
                const {errorCode} = err;
                if (errorCode) {
                    updateFormErrors({
                        owningIndividual: {
                            fiscalCode: [{
                                defaultMessage: intl.formatMessage(defaultMessages.fiscalCode_invalid),
                                id: 'fiscalCode_validation_invalid'
                            }]
                        }
                    });
                }
            }
            return this.getPropsFromFiscalCode();
        }
        return Promise.reject('Invalid Fiscale code');
    }


    getPropsFromFiscalCode() {
        const self = this;
        return new Promise((resolve, reject) => {
            const {getFieldValue,
                updateFields,
                birthPlaces,
                updateFormErrors,
                intl,
                personalDetailsComponentMode} = self.props;
            const firstName = getFieldValue('owningIndividual.firstName');
            const lastName = getFieldValue('owningIndividual.lastName');
            const codeFiscaleVal = getFieldValue('owningIndividual.fiscalCode').replace(/\s/g, '');

            if (!birthPlaces) {
                reject('Birth Place Rest Fail');
            }
            if (codeFiscaleVal !== '') {
                if (CodeFiscale.check(codeFiscaleVal)) {
                    const fiscalInfo = CodeFiscale.computeInverse(codeFiscaleVal, birthPlaces);

                    // Code to ensure only 1 value is present in year.
                    if (Array.isArray(fiscalInfo.year) && fiscalInfo.year.length > 1) {
                        const currentYear = (new Date()).getFullYear();
                        const customerBirthYear = fiscalInfo.year.filter((item) => {
                            return (item < currentYear && item > (currentYear - FiscalDerivedMaxAgeLimit));
                        })[0];
                        fiscalInfo.year = customerBirthYear;
                    }

                    fiscalInfo.year = self.getUniqueBirthYear(fiscalInfo.year);

                    let computedNames = null;
                    // Computer fiscale code to cross check (Name & surname field)
                    if (firstName && lastName) {
                        computedNames = `${CodeFiscale.surnameCode(lastName)}${CodeFiscale.nameCode(firstName)}`;
                    }
                    // MONTH_NAME[fiscalInfo.month]
                    const birthDateVal = `${fiscalInfo.day} ${MONTH_NAME[fiscalInfo.month]} ${fiscalInfo.year}`;
                    updateFields([
                            {name: 'owningIndividual.gender', value: fiscalInfo.gender},
                            {name: 'owningIndividual.birthPlace', value: fiscalInfo.birthplace},
                            {name: 'owningIndividual.birthDate', value: birthDateVal},
                            {name: 'owningIndividual.fiscalCode', value: codeFiscaleVal}
                    ]);
                    if (computedNames === codeFiscaleVal.substring(0, 6)) {
                        updateFields([
                            {name: 'owningIndividual.gender', value: fiscalInfo.gender},
                            {name: 'owningIndividual.birthPlace', value: fiscalInfo.birthplace},
                            {name: 'owningIndividual.birthDate', value: birthDateVal},
                            {name: 'owningIndividual.firstName', value: firstName},
                            {name: 'owningIndividual.lastName', value: lastName},
                            {name: 'owningIndividual.fiscalCode', value: codeFiscaleVal}
                        ]);
                        return resolve(codeFiscaleVal);
                    } else if (computedNames !== null) {
                        if (personalDetailsComponentMode !== COMPONENT_MODES.EDIT) {
                            updateFormErrors({
                                owningIndividual: {
                                    fiscalCode: [{
                                        defaultMessage: intl.formatMessage(defaultMessages.fiscalCode_invalid),
                                        id: 'fiscalCode_validation_invalid'
                                    }]
                                }
                            });
                        } else {
                            let surnameError = false;
                            let firstNameError = false;
                            let errorObj = {};
                            const firstNameValError = [{
                                defaultMessage: intl.formatMessage(defaultMessages.firstname_invalid),
                                id: 'firstName_validation_presence'
                            }];
                            const lastNameValError = [{
                                defaultMessage: intl.formatMessage(defaultMessages.lastname_invalid),
                                id: 'lastName_validation_presence'
                            }];

                            if (computedNames && computedNames.substring(0, 3) !== codeFiscaleVal.substring(0, 3)) {
                                surnameError = true;
                            }
                            if (computedNames && computedNames.substring(3, 6) !== codeFiscaleVal.substring(3, 6)) {
                                firstNameError = true;
                                if (surnameError) {
                                    errorObj = {
                                        owningIndividual: {
                                            firstName: firstNameValError,
                                            lastName: lastNameValError
                                        }
                                    };
                                } else {
                                    errorObj = {
                                        owningIndividual: {
                                            firstName: firstNameValError
                                        }
                                    };
                                }
                            }
                            if (!firstNameError && surnameError) {
                                errorObj = {
                                    owningIndividual: {
                                        lastName: lastNameValError
                                    }
                                };
                            }
                            // Todo - This override updateField & DoB, Gender, Birthplace is not populated. Known issue
                            // Case - if user enters invalid name & fiscal code & click validate
                            updateFormErrors(errorObj);
                        }
                    }
                } else {
                    // To return the 'Invalid fiscale Code';
                    updateFields([
                            {name: 'owningIndividual.gender', value: ''},
                            {name: 'owningIndividual.birthPlace', value: ''},
                            {name: 'owningIndividual.birthDate', value: ''}
                    ]);
                    updateFormErrors({
                        owningIndividual: {
                            fiscalCode: [{
                                defaultMessage: intl.formatMessage(defaultMessages.fiscalCode_invalid),
                                id: 'fiscalCode_validation_invalid'
                            }]
                        }
                    });
                }
            }
            return reject('Invalid Fiscale Code');
        });
    }

    getSaveFoLaterButtonDetails() {
        const {config: {showSaveForLaterLink, externalizeSaveButton}} = this.context;
        const {getFieldValue} = this.props;
        return {
            showSaveForLaterLink,
            getFieldValue,
            externalizeSaveButton
        };
    }

    getSubmitButtonDetails() {
        const {config: {showSubmitButton}} = this.context;
        return {
            showSubmitButton,
            onSubmit: this.handleSubmit,
            isFormValid: this.handleFormValidation
        };
    }

    getFiscalCodeValue() {
        const {customerDetails} = this.props;
        if (!isEmpty(customerDetails)) {
            const {owningIndividual = {}} = customerDetails;
            return owningIndividual.fiscalCode;
        }
        return null;
    }

    getCreateCustomerProps() {
        const {
            showContinueInIdentificationDetails,
            isEditEnabled,
            isFormInvalid
        } = this.state;
        const {getValidationForField,
            intl,
            addressDetails,
            setFormInvalid,
            addressComponentMode,
            findCaller,
            contactNumberDetails,
            selectedPaymentMethod,
            onContinueIncorrectMSISDN,
            onContinueIncompatiblePM,
            selectedPaymentOption,
            orderId,
            isLoggedIn,
            updateFields
        } = this.props;
        return {
            intl,
            getValidationForField,
            formFields: {MandatoryField, Field},
            handleAddressFormValidation: this.handleAddressFormValidation,
            handlebillingAddressFormValidation: this.handlebillingAddressFormValidation,
            createCustomerHeader: this.getCreateCustomerHeaderProps(),
            personalDetails: this.getPersonalDetails(),
            identificationDetails: this.getIdentificationDetails(),
            submitButtonDetails: this.getSubmitButtonDetails(),
            saveButtonDetails: this.getSaveFoLaterButtonDetails(),
            addressDetails,
            showContinue: showContinueInIdentificationDetails,
            continueHandler: this.continueInIdentificationDetailsHandler,
            fiscaleCheck: this.getPropsBirthPlaces,
            fiscalCodeValue: this.getFiscalCodeValue(),
            isEditEnabled,
            isFormInvalid,
            setFormInvalid,
            addressComponentMode,
            findCaller,
            onContinueIncorrectMSISDN,
            onContinueIncompatiblePM,
            contactNumberDetails,
            selectedPaymentMethod,
            selectedPaymentOption,
            orderId,
            isLoggedIn,
            updateFields,
            config: this.props.config
        };
    }

    getUniqueBirthYear(birthDateValue) {
        let yearVal = '';
        if (birthDateValue.length < 3) {
            if ((parseInt(birthDateValue, 10) + FiscalDerivedMaxAgeLimit) > (new Date()).getYear()) {
                yearVal = parseInt(`19${birthDateValue}`, 10);
            } else {
                yearVal = parseInt(`20${birthDateValue}`, 10);
            }
        }
        return yearVal;
    }

    handleAddressFormValidation(addressValidationObj) {
        if (!addressValidationObj.isValid) {
            const err = addressValidationObj.formData.errors;
            this.displayErrorMessage(err);
        }        
    }

    generateErrorMessages(validationObject) {
        if (!validationObject.isValid) {
            const err = validationObject.formData.errors;
            this.displayErrorMessage(err);
        }
        return validationObject.isValid;
    }

    async handleFormValidation() {
        const {getFieldValue, getFieldError} = this.props;
        const individualAttachments = getFieldValue('owningIndividual.individualAttachment');
        const individualAdditionalAttachmentsError = getFieldError('owningIndividual.individualAttachment.additional');
        const {main: mainAttachment, additional: additionalAttachment} = individualAttachments;
        // main attachment is empty, but additional attachment is filled and there are no errors while uploading
        if (isEmpty(mainAttachment) && !isEmpty(additionalAttachment)
            && isEmpty(individualAdditionalAttachmentsError)) {
            await this.switchAttachments('', additionalAttachment);
            if (isEmpty(getFieldValue('owningIndividual.individualAttachment.additional'))) {
                this.setState({showAdditionalIDDocumentAttachment: false});
            }
        }
        this.props.clearGeneralMessage();
        const formStatus = this.props.validateForm();
        return this.generateErrorMessages(formStatus);
    }

    handleSubmit(addressDetails) {
        const {onSubmit, additionalFormData = {}} = this.props;
        if (addressDetails) {
            additionalFormData.addressDetails = addressDetails;
        }
        this.props.handleSubmit(onSubmit, additionalFormData);
    }

    handleIdentificationChange(e) {
        const selectedIdType = e.value;
        if (selectedIdType) {
            const isFirstSelect = isEmpty(this.state.savedIdentifications);
            this.saveIdentification(selectedIdType);
            const idDetails = this.state.savedIdentifications[selectedIdType] || {};
            const {identificationNumber = '', issuerName = '', expirationDate = '', issueDate = ''} = idDetails;
            if (!isFirstSelect) {
                this.props.updateFields([
                    {name: 'owningIndividual.identification.identificationNumber', value: identificationNumber},
                    {name: 'owningIndividual.identification.issuerName', value: issuerName},
                    {name: 'owningIndividual.identification.expirationDate', value: expirationDate},
                    {name: 'owningIndividual.identification.issueDate', value: issueDate}
                ]);
            }
        }
    }

    saveIdentification(newIdType) {
        if (newIdType !== this.state.currentIdType) {
            const {savedIdentifications} = this.state;
            const newSavedIdentifications = cloneDeep(savedIdentifications);
            const idDetails = this.props.getFieldValue('owningIndividual.identification');
            const {identificationNumber = '', issuerName = '', expirationDate = '', issueDate = ''} = idDetails;
            newSavedIdentifications[this.state.currentIdType] = {
                identificationNumber,
                issuerName,
                expirationDate,
                issueDate
            };
            this.setState({
                currentIdType: newIdType,
                savedIdentifications: newSavedIdentifications
            });
        }
    }

    get defaultValues() {
        return {
            owningIndividual: {
                identification: {
                    identificationType: ''
                },
                preferredContactMethod: {
                    name: ''
                },
                preferredContactTime: {
                    name: '' 
                },
                preferredLanguage: {
                    name: ''
                }
            },
            reuseAddress: true
        };
    }

    continueInIdentificationDetailsHandler () {
        this.props.setAddressEventTagging(); 
        this.setState({
            showContinueInIdentificationDetails: false
        });
    }

    initializeData() {
        const { 
            customerDetails, 
            customerId} = this.props;
        if (customerId) {
            if (!isEmpty(customerDetails)) {
                let identification;
                const {billingAddress, owningIndividual} = customerDetails;
                if (owningIndividual && owningIndividual.identification) {
                    identification = customerDetails.owningIndividual.identification;
                }
                let shouldReuseAddress = false;
                const billingAddressId = get(billingAddress, 'id') || 'billingId';
                const postalAddressId = get(owningIndividual, 'postalAddress.id') || 'postalId';
                if (billingAddressId === postalAddressId) {
                    shouldReuseAddress = true;
                }
                this.props.initializeFormValues({
                    ...customerDetails,
                    reuseAddress: shouldReuseAddress
                });
                if (isEmpty(this.state.savedIdentifications) && identification) {
                    this.saveIdentification(identification.identificationType);
                }
            }
        } else {
            const {shouldRenderFollowingDefaults} = this.props;
            if (!shouldRenderFollowingDefaults) {
                this.props.initializeFormValues(this.defaultValues);
            }
        }
    }

    displayErrorMessage(err, hasParentArray, fieldNamePrefix) {
        const context = this;
        const {VALIDATION, BUSINESS} = GeneralMessageConfiguration;
        Object.keys(err).forEach((prop) => {
            if (Array.isArray(err[prop])) {
                const errorKey = {};
                errorKey[prop] = err[prop][0];
                context.displayErrorMessage(errorKey, true, fieldNamePrefix);
            } else if (hasParentArray) {
                if (err[prop] && typeof err[prop] !== 'string') {
                    const {errorCategory, fieldLabel} = err[prop];
                    const category = errorCategory === VALIDATION ? VALIDATION : BUSINESS;
                    const errMsg = fieldNamePrefix ? `${fieldNamePrefix} ${fieldLabel}` : fieldLabel;
                    context.props.showGeneralMessage(errMsg, category, errorCategory);
                }
            } else {
                context.displayErrorMessage(err[prop], false, fieldNamePrefix);
            }
        });
    }

    render() {
        const {shouldRenderFollowingDefaults, showEligibilityCheckPopup, showEligibilityCheck} = this.props;
        if (shouldRenderFollowingDefaults) {
            return (<CreateCustomerComponentView
                {...this.getCreateCustomerProps()}
                showEligibilityCheckPopup={showEligibilityCheckPopup}
                showEligibilityCheck={showEligibilityCheck}
            />);
        }
        return null;
    }
}
