import React from 'react';
import {findDOMNode} from 'react-dom';
import ReactTooltip from 'react-tooltip';
import {FormattedMessage} from 'react-intl';

export default function TooltipView({
    innerComponent: InnerComponent,
    tooltipTextMessageLabel,
    id
}) {
    let tooltipLinkRef;
    return (
        <div className="ds-form__input--wrapper option-for__fiscal dropdown__tooltip active">
            <span
                className="ds-btn ds-btn--link"
                onClick={(e) => {
                    e.stopPropagation();
                }}
                data-tip
                data-for={id}
                data-event="click"
                ref={(ref) => {
                    tooltipLinkRef = ref;
                }}
            >
                <FormattedMessage {...tooltipTextMessageLabel} />
            </span>
            <ReactTooltip
                id={id}
                aria-haspopup="true"
                place="bottom"
                event="click"
                globalEventOff="click"
            >
                <div className="ds-tooltip-item ds-tooltip-item__center">
                    <div
                        className="ds-tooltip-item__close"
                        onClick={() => {
                            ReactTooltip.hide(findDOMNode(tooltipLinkRef));
                        }}
                    />
                    <InnerComponent />
                </div>
            </ReactTooltip>
        </div>
    );
}
