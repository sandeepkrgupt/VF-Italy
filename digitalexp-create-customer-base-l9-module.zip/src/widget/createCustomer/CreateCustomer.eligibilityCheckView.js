import React from 'react';
import {Modal, ModalUtils} from 'digitalexp-common-components-l9';
import {FormattedMessage} from 'react-intl';
import messages from '../CreateCustomer.i18n';

const {ModalHeader, ModalBody, ModalFooter} = ModalUtils;

function EligibilityCheckView({cancelOrder, clearCartData}) {
    const config = {
        showOverLay: true
    };
    const cancelOrderClickHandler = () => {
        cancelOrder();
    };
    const selectAnotherPlanClickHandler = () => {
        clearCartData();
    };
    return (
        <Modal config={config}>
            <ModalHeader>
                <h1 className="ds-title">
                    <div className="ds-title--small">
                        <FormattedMessage {...messages.eligibility_Check_header} />
                    </div>
                </h1>
            </ModalHeader>
            <ModalBody>
                <div>
                    <FormattedMessage {...messages.eligibility_Check_warning_first} />
                </div>
                <div>
                    <FormattedMessage {...messages.eligibility_Check_warning_second} />
                </div>
            </ModalBody>
            <ModalFooter>
                <button 
                    className="ds-btn ds-btn--large ds-btn--secondary"
                    onClick={cancelOrderClickHandler}>
                    <FormattedMessage {...messages.cancel_order_button_placehoder} />
                </button>
                <button 
                    className="ds-btn ds-btn--large ds-btn--primary"
                    onClick={selectAnotherPlanClickHandler}>
                    <FormattedMessage {...messages.select_another_plan_button_placehoder} />
                </button>
            </ModalFooter>
        </Modal>
    );
}

export default EligibilityCheckView;

