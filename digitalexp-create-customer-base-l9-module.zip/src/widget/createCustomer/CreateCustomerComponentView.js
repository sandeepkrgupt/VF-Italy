import React, {Component} from 'react';
import get from 'lodash/get';
import isEmpty from 'lodash/isEmpty';
import {ADDRESS_TYPES, PAYMENT_METHODS, MODAL_DISPLAY_MODE} from '../CreateCustomer.consts';
import DefaultAddressDetailsView from './addressDetails/AddressComponent';
import DefaultPersonalDetailsCreateView from './PersonalDetailsCreateView';
import DefaultContactSectionCreateView from './ContactSectionCreateView';
import ErrorModal from './Modal';

class CreateCustomerComponentView extends Component {
    constructor(props) {
        super(props);
        const {config: {showUseThisAddressAsBilling}} = props.addressDetails;
        this.onSubmitButtonClickCallback = this.onSubmitButtonClickCallback.bind(this);
        this.reuseAddressHandler = this.reuseAddressHandler.bind(this);
        this.formSubmit = this.formSubmit.bind(this);
        this.addressMainView = this.addressMainView.bind(this);
        this.closeModalHandler = this.closeModalHandler.bind(this);
        this.continueHandler = this.continueHandler.bind(this);
        const {reuseAddress} = props;
        this.state = {
            reuseAddress: showUseThisAddressAsBilling ? reuseAddress : false,
            showErrorModal: false,
            modalDisplayMode: ''
        };
        this.waitForPromise = new Promise((resolve, reject) => {
            this.resolvePromise = resolve;
            this.rejectPromise = reject;
        });
    }

    async onSubmitButtonClickCallback(onSubmit) {
        const {setFormInvalid, fiscaleCheck, 
            findCaller, contactNumberDetails = {}, selectedPaymentMethod = {}, isLoggedIn} = this.props;
        const addressComponent = this.addressComponentRef;
        const customerProfileFormValid = await this.props.submitButtonDetails.isFormValid();
        const isAddressFormValid = addressComponent.validateFormFields();
        const addressValidationObj = addressComponent.getFormValidationData();
        this.props.handleAddressFormValidation(addressValidationObj);
        // if customer profile Form is valid and postal address Form is valid
        // then verify postal address with REST call if its valid
        // then follow same for billing addres(if present) 
        // if postal address is invalid show modal
        if (customerProfileFormValid && isAddressFormValid) {
            const promiseArray = [];
            const fiscalCode = await fiscaleCheck();

            // TODO: To be developed in next MTVs.for now find caller api is commented below.
            // if (!isLoggedIn()) {
            //     const response = await findCaller(fiscalCode);
                
            //     const subscription = get(response, 'callerDetails.subscription') || [];
            //     const userPaymentType = get(response, 'callerDetails.paymean.vfPayMeanType') || '';
            //     const {phone_number: phoneNumber} = contactNumberDetails;
            //     const isMSISDNCorrect = isEmpty(phoneNumber) || subscription.some(({msisdn}) => {
            //         return msisdn === phoneNumber;
            //     });
            //     const {methodName = ''} = selectedPaymentMethod || {};

            //     if (!isMSISDNCorrect) {
            //         this.setState({
            //             modalDisplayMode: MODAL_DISPLAY_MODE.INCORRECT_MSISDN
            //         });
            //         await this.showModalHandler();
            //     }

            //     if (userPaymentType.toUpperCase() === PAYMENT_METHODS.CREDIT_CARD 
            //         && methodName.toUpperCase() === PAYMENT_METHODS.BANK) {
            //         this.setState({
            //             modalDisplayMode: MODAL_DISPLAY_MODE.INCOMPATIBLE_PM
            //         });
            //         await this.showModalHandler();  
            //     }
            // }
            promiseArray.push(addressComponent.validateAddress());
            Promise.all(promiseArray).then(([postalAddress = {}, billingAddress]) => {
                if (billingAddress) {
                    onSubmit({postalAddress, billingAddress});
                } else {
                    onSubmit({postalAddress: {
                        ...postalAddress,
                        displayStateOrProvince: null
                    }});
                }
            });
        } else {
            setFormInvalid();
        }
    }

    getErrorModalProps() {
        const {contactNumberDetails = {}, orderId, intl} = this.props;
        const {phone_number: phoneNumber} = contactNumberDetails;
        return {
            modalDisplayMode: this.state.modalDisplayMode,
            closeModalHandler: this.closeModalHandler,
            continueHandler: this.continueHandler,
            orderId,
            phoneNumber,
            intl
        };
    }

    showModalHandler() {
        this.setState({
            showErrorModal: true
        });
        return this.waitForPromise;
    }

    closeModalHandler() {
        this.setState({
            showErrorModal: false
        });
        this.rejectPromise();
    }

    continueHandler() {
        const {onContinueIncorrectMSISDN, onContinueIncompatiblePM, selectedPaymentOption} = this.props;

        if (this.state.modalDisplayMode === MODAL_DISPLAY_MODE.INCORRECT_MSISDN) {
            onContinueIncorrectMSISDN().then(() => {
                this.setState({
                    showErrorModal: false
                });
                this.rejectPromise();
            });
        } else if (this.state.modalDisplayMode === MODAL_DISPLAY_MODE.INCOMPATIBLE_PM) {
            const payload = Object.assign({}, selectedPaymentOption);
            const {paymentMethods = []} = payload;
            paymentMethods.forEach((paymentMethod = {}) => {
                const {methodName = ''} = paymentMethod;
                if (PAYMENT_METHODS.CREDIT_CARD === methodName.toUpperCase()) {
                    paymentMethod.isCurrentSelectedPaymentMode = true;
                } else {
                    paymentMethod.isCurrentSelectedPaymentMode = false;
                }
            });
            onContinueIncompatiblePM(payload).then(() => {
                this.setState({
                    showErrorModal: false
                });
                this.resolvePromise();
            });      
        }
    }

    formSubmit = () => {
        const {submitButtonDetails} = this.props;
        const {onSubmit} = submitButtonDetails;
        window.scrollTo(0, 0);
        return this.onSubmitButtonClickCallback(onSubmit);
    };

    reuseAddressHandler() {
        const {reuseAddress} = this.state;
        this.setState({
            reuseAddress: !reuseAddress
        });
    }

    addressMainView() {
        const {addressDetails, addressComponentMode} = this.props;
        return (
            <DefaultAddressDetailsView
                addressType={ADDRESS_TYPES.POSTAL}
                addressComponentMode={addressComponentMode}
                ref={(ref) => {
                    this.addressComponentRef = ref;
                }}
                {...addressDetails}
            />
        );
    }

    render() {
        const {
            intl,
            getValidationForField,
            formFields,
            personalDetails,
            fiscaleCheck,
            identificationDetails,
            submitButtonDetails,
            config,
            isEditEnabled,
            isFormInvalid,
            addressDetails,
            showContinue,
            continueHandler,
            // default view
            PersonalDetailsCreateView = DefaultPersonalDetailsCreateView,
            ContactSectionCreateView = DefaultContactSectionCreateView,
            fiscalCodeValue,
            showEligibilityCheckPopup,
            showEligibilityCheck,
            isLoggedIn,
            updateFields
        } = this.props;
        return (
            <div>
                <div className="ds-create-customer ds-container">
                    <PersonalDetailsCreateView
                        {...personalDetails}
                        identificationDetails={identificationDetails}
                        intl={intl}
                        config={config}
                        fiscaleCheck={fiscaleCheck}
                        formFields={formFields}
                        getValidationForField={getValidationForField}
                        showContinue={showContinue}
                        continueHandler={continueHandler}
                        isEditEnabled={isEditEnabled}
                        isFormInvalid={isFormInvalid}
                        fiscalCodeValue={fiscalCodeValue}
                        updateFields={updateFields}
                        />
                        
                </div>
                <div className="ds-address-widget ds-container">
                    <ContactSectionCreateView
                        {...personalDetails}
                        addressDetails={addressDetails}
                        intl={intl}
                        config={config}
                        formFields={formFields}
                        addressMainView={this.addressMainView}
                        getValidationForField={getValidationForField}
                        submitButtonDetails={submitButtonDetails}
                        showContinue={showContinue}
                        formSubmit={this.formSubmit}
                        isEditEnabled={isEditEnabled}
                        isFormInvalid={isFormInvalid}
                        isLoggedIn={isLoggedIn}
                        updateFields={updateFields}
                        />
                </div>
                {this.state.showErrorModal && <ErrorModal {...this.getErrorModalProps()} />}
                {showEligibilityCheckPopup && showEligibilityCheck && showEligibilityCheck()}
            </div>
        );
    }
}

export default CreateCustomerComponentView;
