import React, {Component} from 'react';
import _isEmpty from 'lodash/isEmpty';
import AddressDetailsWidget from 'digitalexp-address-base-l9-module';
import {COMPONENT_MODES, ADDRESS_STATUS, ADDRESS_FIELD_NAMES} from '../../CreateCustomer.consts';

class AddressComponent extends Component {

    constructor(props) {
        super(props);
        this.validateAddress = this.validateAddress.bind(this);
        this.convertFormValuesToAddress = this.convertFormValuesToAddress.bind(this);
        this.getAddressFromAddressForm = this.getAddressFromAddressForm.bind(this);
        this.getFormValidationData = this.getFormValidationData.bind(this);
    }

    // using refs get address form data from address child widget
    getAddressFromAddressForm() {
        return this.addressWidgetRef.getWrappedInstance().getComponentInstance().getFormData().values;
    }

    getAddressComponentProps(props) {
        const {config, addressDetailsProps, addressType, addressComponentMode} = props;
        return {
            config: {
                ...config,
                displayMode: addressComponentMode 
            },
            ref: (str) => { this.addressWidgetRef = str; },
            instanceId: `create_customer_${addressType}`,
            addressDetails: addressDetailsProps.customerAddress[addressType] || '',
            ...addressDetailsProps
        };
    }

    getFormValidationData() {
        return this.addressWidgetRef.getWrappedInstance()
                .getComponentInstance().addressMainView.getFormValidationData();
    }

    convertFormValuesToAddress(values) {
        if (_isEmpty(values)) {
            return {};
        }

        const address = {};

        address.streetNumber = values[ADDRESS_FIELD_NAMES.STREET_NUMBER];
        address.frazione = values[ADDRESS_FIELD_NAMES.FRAZIONE];
        address.mailBox = values[ADDRESS_FIELD_NAMES.MAIL_BOX];
        address.city = values[ADDRESS_FIELD_NAMES.CITY];
        address.country = values[ADDRESS_FIELD_NAMES.COUNTRY];
        address.state = values[ADDRESS_FIELD_NAMES.STATE];
        address.postalCode = values[ADDRESS_FIELD_NAMES.POSTAL_CODE];
        address.street = values[ADDRESS_FIELD_NAMES.STREET];
        address.stateOrProvince = values[ADDRESS_FIELD_NAMES.STATE];

        return address;
    }

    resolveSubmitPromise(theAddress) {
        if (this.submitAddressResolver) {
            this.submitAddressResolver(theAddress);
        }
    }

    validateFormFields() {
        return this.addressWidgetRef.getWrappedInstance().getComponentInstance().validateForm();
    }

    validateAddress() {
        const {config: {displayMode}} = this.props;
        if (displayMode === COMPONENT_MODES.EDIT || displayMode === COMPONENT_MODES.NEW) {
            return this.addressWidgetRef.getWrappedInstance().getComponentInstance()
                .validateAddress();
        }
        return null;
    }

    showInValidateAddressPopup(invalidAddress, callBack) {
        this.addressWidgetRef.getWrappedInstance()
                .getComponentInstance().showInValidateAddressPopup(invalidAddress, callBack);
    }

    render() {
        const AddressDetails = AddressDetailsWidget.ConnectedWidget;
        return (
            <AddressDetails
                ref={(instance) => { this.addressWidgetRef = instance; }}
                {...this.getAddressComponentProps(this.props)}
            />);
    }
}

export default AddressComponent;
