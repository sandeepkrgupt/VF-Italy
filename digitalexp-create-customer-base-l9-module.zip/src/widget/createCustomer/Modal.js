import React, {Component} from 'react';
import {Modal, ModalUtils} from 'digitalexp-common-components-l9';
import {FormattedMessage} from 'react-intl';

import messages from '../CreateCustomer.i18n';
import {MODAL_DISPLAY_MODE} from '../CreateCustomer.consts';

const {ModalHeader, ModalBody, ModalFooter} = ModalUtils;

export default class GeneralInformationModal extends Component {
    constructor(props) {
        super(props);
        this.getMainView = this.getMainView.bind(this);
        this.getFooterView = this.getFooterView.bind(this);
        this.getHeaderConfig = this.getHeaderConfig.bind(this);
    }

    getMainView() {
        const {intl} = this.props;
        const lineSplitterRegexp = /[\r\n]|[\n]|[\r]/;
        const textIncorrectMSISDN =
            intl.formatMessage(messages.incorrect_msisdn_number_description_text, {MSISDN: this.props.phoneNumber});
        const textIncorrectMSISDNList = textIncorrectMSISDN.split(lineSplitterRegexp);
        
        const textIncompatiblePM = 
            intl.formatMessage(messages.incompatible_pm__description_text, {orderId: this.props.orderId});
        const textIncompatiblePMList = textIncompatiblePM.split(lineSplitterRegexp);
        
        switch (this.props.modalDisplayMode) {

        case MODAL_DISPLAY_MODE.INCORRECT_MSISDN: 
            return [
                <div key="MAIN_INCORRECT_MSISDN_1" className="ds-text-bold">
                    <FormattedMessage {...messages.incorrect_msisdn_number_sub_header} />
                </div>,
                ...textIncorrectMSISDNList.map((textItem) => {
                    return (<p key={textItem}>
                        {textItem}
                    </p>);
                })
            ];
        case MODAL_DISPLAY_MODE.INCOMPATIBLE_PM:
            return [
                <div key="MAIN_INCOMPATIBLE_PM_1" className="ds-text-bold">
                    <FormattedMessage {...messages.incompatible_pm_sub_header} />
                </div>,
                ...textIncompatiblePMList.map((textItem) => {
                    return (<p key={textItem}>
                        {textItem}
                    </p>);
                })
            ];
        default: 
            return null;
        }
    }

    getFooterView() {       
        switch (this.props.modalDisplayMode) {

        case MODAL_DISPLAY_MODE.INCORRECT_MSISDN: 
            return (
                <button 
                    key="FOOT_INCORRECT_MSISDN" 
                    className="ds-btn ds-btn--large ds-btn--primary"
                    onClick={this.props.continueHandler}
                >
                    <FormattedMessage {...messages.incorrect_msisdn_button_label} />
                </button>
            );
        case MODAL_DISPLAY_MODE.INCOMPATIBLE_PM:
            return (
                <button 
                    key="FOOT_INCOMPATIBLE_PM" 
                    className="ds-btn ds-btn--large ds-btn--primary" 
                    onClick={this.props.continueHandler}
                >
                    <FormattedMessage {...messages.incompatible_pm_button_label} />
                </button>
            );
        default: 
            return null;
        }
    }

    getHeaderConfig() {
        const titleText = (this.props.modalDisplayMode === MODAL_DISPLAY_MODE.INCORRECT_MSISDN) ?
            <FormattedMessage {...messages.incorrect_msisdn_number} /> :
            <FormattedMessage {...messages.incompatible_pm_header} />; 
        return {
            showCloseButton: true,
            closeButtonClass: 'ds-modal--close',
            showTitle: true,
            titleText
        };
    }

    render() {
        const config = {
            showOverLay: true
        };
        return (
            <Modal config={config}>
                <ModalHeader config={this.getHeaderConfig()} handleButtonClick={this.props.closeModalHandler} />
                <ModalBody>
                    {this.getMainView()}
                </ModalBody>
                <ModalFooter>
                    {this.getFooterView()}
                </ModalFooter>
            </Modal>
        );
    }
}
