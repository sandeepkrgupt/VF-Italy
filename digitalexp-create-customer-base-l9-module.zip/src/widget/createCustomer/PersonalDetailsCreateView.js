import React, {Component} from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import {FormField, ComboBox, ReactDatePicker} from 'digitalexp-common-components-l9';
import {FormattedMessage} from 'react-intl';
import _isEqual from 'lodash/isEqual';
import classNames from 'classnames';
import Messages from '../CreateCustomer.i18n';
import {COMPONENT_MODES, DATE_FORMAT} from '../CreateCustomer.consts';
import TooltipView from './TooltipView';

const {Input} = FormField;

export default class PersonalDetailsCreateView extends Component {
    static get contextTypes() {
        return {
            getFieldValue: PropTypes.func,
            registerFieldConstraints: PropTypes.func
        };
    }
    constructor(props) {
        super(props);

        const {isEditEnabled} = props;

        this.state = {
            isAccordianCollapsed: false,
            hideAccordian: isEditEnabled
        };
    }

    componentWillReceiveProps(nextProps) {
        const {showContinue, isEditEnabled, isFormInvalid} = this.props;
        const {
            showContinue: nextShowContinue,
            isEditEnabled: nextIsEditEnabled,
            isFormInvalid: nextIsFormInvalid
        } = nextProps;
        if (!_isEqual(showContinue, nextShowContinue)) {
            this.setState({
                isAccordianCollapsed: true
            });
        }
        if (!_isEqual(isEditEnabled, nextIsEditEnabled) || !_isEqual(isFormInvalid, nextIsFormInvalid)) {
            this.setState({
                isAccordianCollapsed: false,
                hideAccordian: true
            });
        }
    }

    onChangeAction = (date) => {
        const {updateFields} = this.props;
        updateFields([{name: 'owningIndividual.identification.expirationDate',
            value: date.format(DATE_FORMAT.SUBMIT_FORMAT)}]);
    };

    onChangeRawHandler = (date) => {
        const {updateFields} = this.props;
        updateFields([{name: 'owningIndividual.identification.expirationDate', value: date.target.value}]);
    }

    getDefaultValue = () => {
        const {config} = this.props;
        let defaultValue = moment().add(config.defaultExpirationOffset, 'days');
        const {getFieldValue} = this.context;
        const date = getFieldValue('owningIndividual.identification.expirationDate');
        if (date) {
            defaultValue = moment(date, DATE_FORMAT.SUBMIT_FORMAT);
        }
        return defaultValue;
    };

    getSelectedDate = () => {
        const {getFieldValue} = this.context;
        const selectedDate = getFieldValue('owningIndividual.identification.expirationDate');
        if (selectedDate) {
            return moment(selectedDate, DATE_FORMAT.SUBMIT_FORMAT);
        }
        return null;
    }

    toggleAccordian = () => {
        const {isAccordianCollapsed} = this.state;
        this.setState({
            isAccordianCollapsed: !isAccordianCollapsed
        });
    };

    render() {
        const {isAccordianCollapsed, hideAccordian} = this.state;

        const {
            intl,
            config,
            formFields,
            fiscaleCheck,
            getValidationForField,
            personalDetailsComponentMode,
            identificationDetails,
            handleIdentificationChange,
            showContinue,
            isEditEnabled,
            isFormInvalid,
            continueHandler,
            countries,
            fiscalCodeValue
        } = this.props;

        if (
            personalDetailsComponentMode !== COMPONENT_MODES.EDIT &&
            personalDetailsComponentMode !== COMPONENT_MODES.NEW
        ) {
            return null;
        }

        const accordionClassName = classNames({
            collapsed: isAccordianCollapsed,
            accordian: !hideAccordian
        });

        const {MandatoryField} = formFields;

        return (
            <div className="ds-form">
                <div className="ds-form__fieldset">
                    <div className={accordionClassName}>
                        <header
                            className="accordian__header"
                            onClick={!isEditEnabled && !isFormInvalid && this.toggleAccordian}
                        >
                            <div className="ds-title">
                                <span className="ds-title__text">
                                    <FormattedMessage {...Messages.id_details} />
                                </span>
                            </div>
                        </header>
                        <section className="accordian__body">
                            <div className=" ds-row">
                                <div className="col-xs-12 ds-note">
                                    <span className="ds-icon ds-icon-id_grey" />
                                    <span className="ds-note__text">
                                        <FormattedMessage {...Messages.identification_note} />
                                    </span>
                                </div>
                            </div>
                            <div className="ds-form__container ds-row">
                                <MandatoryField
                                    Component={Input}
                                    label={intl.formatMessage(Messages.firstname_label)}
                                    name="owningIndividual.firstName"
                                    eventListeners={{onBlur: fiscaleCheck}}
                                    type="text"
                                    constraints={getValidationForField('firstName')}
                                    isMandatory
                                    skipConstraints={['presence']}
                                    config={{fieldWrapperClassName: 'col-xs-12 col-sm-6'}}
                                />
                                <MandatoryField
                                    Component={Input}
                                    label={intl.formatMessage(Messages.lastname_label)}
                                    name="owningIndividual.lastName"
                                    eventListeners={{onBlur: fiscaleCheck}}
                                    type="text"
                                    constraints={getValidationForField('lastName')}
                                    skipConstraints={['presence']}
                                    config={{fieldWrapperClassName: 'col-xs-12 col-sm-6'}}
                                />
                            </div>
                            <div className="ds-form__container ds-row">
                                <div className="col-xs-12">
                                    <div className="ds-form__group row">
                                        <MandatoryField
                                            Component={ComboBox}
                                            label={intl.formatMessage(Messages.nationality_label)}
                                            name="owningIndividual.nation"
                                            items={countries}
                                            allowItemAdd="true"
                                            displayField="displayName"
                                            placeholder="Select"
                                            searchable={false}
                                            config={{
                                                fieldIconClassName: 'ds-form__icon--address',
                                                hasIcon: true,
                                                fieldWrapperClassName: 'col-xs-12 col-sm-3'
                                            }}
                                            constraints={getValidationForField('nationality')}
                                            skipConstraints={['presence']}
                                        />
                                        <MandatoryField
                                            Component={Input}
                                            label={intl.formatMessage(Messages.fiscalCode_label)}
                                            name="owningIndividual.fiscalCode"
                                            type="text"
                                            eventListeners={{onBlur: fiscaleCheck}}
                                            disabled={
                                                personalDetailsComponentMode !== COMPONENT_MODES.NEW && fiscalCodeValue
                                            }
                                            constraints={getValidationForField('fiscalCode')}
                                            skipConstraints={['presence']}
                                            config={{fieldWrapperClassName: 'col-sm-6'}}
                                        />
                                        {config.showFiscalCodeToolTip && (
                                            <div className="ds-form__line col-sm-6 fiscal-tooltip">
                                                <span className="ds-form__label">&nbsp;</span>
                                                <TooltipView
                                                    tooltipTextMessageLabel={Messages.fiscal_code_tooltip_link_text}
                                                    id={'fiscal'}
                                                    innerComponent={() => {
                                                        return (
                                                            <section className="ds-tooltip-item__content">
                                                                <div className="ds-tooltip__text">
                                                                    <FormattedMessage
                                                                        {...Messages.fiscal_code_tooltip_text_1}
                                                                    />
                                                                </div>
                                                                <div className="ds-tooltip__text">
                                                                    <FormattedMessage
                                                                        {...Messages.fiscal_code_tooltip_text_2}
                                                                    />
                                                                </div>
                                                            </section>
                                                        );
                                                    }}
                                                />
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                            <div className="ds-form__container ds-row">
                                {config.showFiscalCodeDerivedParamters && (
                                    <MandatoryField
                                        Component={Input}
                                        label={intl.formatMessage(Messages.gender_label)}
                                        name="owningIndividual.gender"
                                        type="text"
                                        usePlaceholder
                                        placeholder={intl.formatMessage(Messages.gender_label_placeholder)}
                                        readOnly
                                        config={{
                                            fieldWrapperClassName: 'col-xs-12 col-sm-3',
                                            fieldClassName: 'ds-form__input input-border0__item'
                                        }}
                                    />
                                )}
                                {config.showFiscalCodeDerivedParamters && (
                                    <MandatoryField
                                        Component={Input}
                                        label={intl.formatMessage(Messages.birthDate_label)}
                                        name="owningIndividual.birthDate"
                                        readOnly
                                        config={{
                                            fieldWrapperClassName: 'col-xs-12 col-sm-3',
                                            fieldClassName: 'ds-form__input ds-date input-border0__item'
                                        }}
                                        usePlaceholder
                                        placeholder="(DD Month YYYY)"
                                    />
                                )}
                                {config.showFiscalCodeDerivedParamters && (
                                    <MandatoryField
                                        Component={Input}
                                        label={intl.formatMessage(Messages.birthplace_label)}
                                        name="owningIndividual.birthPlace"
                                        readOnly
                                        config={{
                                            fieldWrapperClassName: 'col-xs-12 col-sm-6 birth-place',
                                            fieldClassName: 'ds-form__input input-border0__item'
                                        }}
                                        usePlaceholder
                                        placeholder="(Birth place)"
                                    />
                                )}
                            </div>
                            <div className="ds-form__container acquisition ds-row">
                                <div className="col-xs-12">
                                    <div className="ds-row acquisition__title">
                                        <div className="ds-title col-xs-12 col-sm-4">
                                            <span className="ds-title__text">
                                                <FormattedMessage {...Messages.document_acquisition} />
                                            </span>
                                        </div>
                                        <div className="col-xs-12 col-sm-5">
                                            <TooltipView
                                                tooltipTextMessageLabel={Messages.id_tooltip_link_text}
                                                id={'id'}
                                                innerComponent={() => {
                                                    return (
                                                        <section className="ds-tooltip-item__content">
                                                            <div className="ds-tooltip__text">
                                                                <FormattedMessage {...Messages.id_tooltip_text} />
                                                            </div>
                                                        </section>
                                                    );
                                                }}
                                            />
                                        </div>
                                    </div>
                                </div>
                                <MandatoryField
                                    Component={ComboBox}
                                    label={intl.formatMessage(Messages.idType_label)}
                                    name="owningIndividual.identification.identificationType"
                                    items={identificationDetails.idDetails.identificationTypes}
                                    allowItemAdd="true"
                                    displayField="displayName"
                                    placeholder="Please Specify"
                                    searchable={false}
                                    config={{
                                        fieldIconClassName: 'ds-form__icon--address',
                                        hasIcon: true,
                                        fieldWrapperClassName: 'col-xs-12 col-sm-3'
                                    }}
                                    constraints={getValidationForField('idType')}
                                    validateFieldOn="onChange"
                                    skipConstraints={['presence']}
                                    eventListeners={{onChange: handleIdentificationChange}}
                                />
                                <MandatoryField
                                    Component={Input}
                                    label={intl.formatMessage(Messages.idNumber_label)}
                                    config={{fieldWrapperClassName: 'col-xs-12 col-sm-3'}}
                                    name="owningIndividual.identification.identificationNumber"
                                    type="text"
                                    constraints={getValidationForField('idNumber')}
                                    skipConstraints={['presence']}
                                />
                                <MandatoryField
                                    Component={ComboBox}
                                    label={intl.formatMessage(Messages.issuing_nationality_label)}
                                    name="owningIndividual.identification.nationality"
                                    items={countries}
                                    allowItemAdd="true"
                                    displayField="displayName"
                                    placeholder="Select"
                                    searchable={false}
                                    config={{
                                        fieldIconClassName: 'ds-form__icon--address',
                                        hasIcon: true,
                                        fieldWrapperClassName: 'col-xs-12 col-sm-3'
                                    }}
                                    constraints={getValidationForField('documentNationality')}
                                    skipConstraints={['presence']}
                                />
                                <MandatoryField
                                    Component={ReactDatePicker}
                                    label={intl.formatMessage(Messages.expirationDate_label)}
                                    name="owningIndividual.identification.expirationDate"
                                    constraints={getValidationForField('expirationDate')}
                                    minDate={moment().add(config.defaultExpirationOffset, 'days')}
                                    selected={this.getSelectedDate()}
                                    className="ds-form__input ds-date"
                                    onChange={this.onChangeAction}
                                    onChangeRaw={this.onChangeRawHandler}
                                    config={{fieldWrapperClassName: 'col-xs-12 col-sm-3'}}
                                    placeholderText="YYYY-MM-DD"
                                    dateFormat="YYYY-MM-DD"
                                />
                                <div className="ds-note col-xs-12">
                                    <span className="ds-bold">
                                        <FormattedMessage {...Messages.document_note_label} />
                                        &nbsp;
                                    </span>
                                    <FormattedMessage {...Messages.document_note} />
                                </div>
                            </div>
                            {!isEditEnabled && showContinue && (
                                <div className="ds-row  btn-wrapper">
                                    <div className="col-xs-12">
                                        <button
                                            type="button"
                                            className="ds-btn ds-btn--large ds-btn--primary ds-right"
                                            onClick={() => continueHandler()}
                                        >
                                            <FormattedMessage {...Messages.id_details_continue} />
                                        </button>
                                    </div>
                                </div>
                            )}
                        </section>
                    </div>
                </div>
            </div>
        );
    }
}
