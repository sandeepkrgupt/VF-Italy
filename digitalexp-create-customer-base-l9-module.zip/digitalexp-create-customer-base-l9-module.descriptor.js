const coreCustomerDescriptor =
    require('digitalexp-create-customer-base-module/digitalexp-create-customer-base-module.descriptor.json');
const l9AddressDescriptor =
    require('digitalexp-address-base-l9-module/digitalexp-address-base-l9-module.descriptor.json');

const descriptor = {
    displayName: 'digitalexp-create-customer-base-l9-module',
    widgetId: 'digitalexp-create-customer-base-l9-module',
    widgetCategory: 'Digital Experience',
    widgetDomain: 'Commerce',
    widgetSalesChannel: 'Base',
    widgetDescription: 'None',
    topicName: 'createCustomer',
    behaviorParams: coreCustomerDescriptor.behaviorParams
        // filter unwanted core params
        .filter((behaviorItem) => {
            return (behaviorItem && behaviorItem.itemId &&
                ['displayMode'].indexOf(behaviorItem.itemId) === -1);
        })
        // transform core params
        .map((behaviorItem) => {
            if (behaviorItem) {
                switch (behaviorItem.itemId) {
                case 'minimumAge':
                    behaviorItem.defaultValue = '15';
                    break;
                case 'createCustomerIdDetails':
                    behaviorItem.defaultValue = false;
                    break;
                case 'addressAutoComplete':
                    behaviorItem.defaultValue = false;
                    break;
                case 'showIDDocumentAttachment':
                    behaviorItem.defaultValue = false;
                    break;
                default:
                }
            }
            return behaviorItem;
        })
        // add custom params
        .concat([
            {
                groupId: 'createCustomerGeneralDetails',
                itemId: 'displayMode',
                displayName: 'Widget Display Mode',
                type: 'text',
                control: 'radio',
                possibleValues: [
                    {
                        displayName: 'Create',
                        value: 'EDIT'
                    },
                    {
                        displayName: 'Review',
                        value: 'REVIEW'
                    }
                ],
                description: 'Set to Create: to display input boxes for capturing customer details Set to Review: to ' +
                'display customer details as read only texts',
                defaultValue: 'EDIT'
            },
            {
                groupId: 'createCustomerGeneralDetails',
                itemId: 'showFiscalCodeDerivedParamters',
                displayName: 'Show Fiscal Code Derived Parameters',
                type: 'boolean',
                description: 'Determine whether to display a fiscal code derived parameters.',
                defaultValue: true
            },
            {
                groupId: 'createCustomerGeneralDetails',
                itemId: 'showFiscalCodeToolTip',
                displayName: 'Show Fiscal Code Tool Tip',
                type: 'boolean',
                description: 'Determine whether to display the fiscal code tool tip.',
                defaultValue: true
            },
            {
                groupId: 'createCustomerIdDetails',
                itemId: 'zipLengthLimit',
                displayName: 'Zip needs to have maximum 6 characters',
                type: 'number',
                description: 'Zip needs to have maximum 6 characters',
                defaultValue: 6
            },
            {
                groupId: 'createCustomerIdDetails',
                itemId: 'showContactDetailsTooltip',
                displayName: 'Display Contact Details Tooltip',
                type: 'boolean',
                description: 'Display Contact Details Tooltip',
                defaultValue: true
            },
            {
                groupId: 'createCustomerIdDetails',
                itemId: 'showPreferredContactTime',
                displayName: 'Display Preferred Contact Time',
                type: 'boolean',
                description: 'Display Preferred Contact Time',
                defaultValue: true
            },
            {
                groupId: 'AddressWidgetParams',
                itemId: 'showFrazione',
                displayName: 'Show Frazione',
                type: 'boolean',
                description: '',
                defaultValue: true
            },
            {
                groupId: 'createCustomerIdDetails',
                itemId: 'defaultExpirationOffset',
                displayName: 'defaultExpirationOffset',
                type: 'number',
                description: 'defaultExpirationOffset',
                defaultValue: 30
            }
        ])
    .concat(l9AddressDescriptor.behaviorParams
        .filter((behaviorItem) => {
            return (behaviorItem && behaviorItem.groupId &&
            behaviorItem.groupId === 'behaviorGeolocation');
        })
        ),
    outcomes: coreCustomerDescriptor.outcomes
        // filter unwanted core params
        .filter((outcomeItem) => {
            return (outcomeItem && outcomeItem.actionId &&
                ['UPDATE_CUSTOMER_SUCCESS'].indexOf(outcomeItem.actionId) === -1);
        })
        // new items
        .concat([
            {
                displayName: '',
                actionId: 'NAVIGATE_TO_PLAN_LIST',
                actionType: 'navigateDynamic',
                defaultValue: '',
                description: 'Navigate to Plan List based on PO type',
                parameterDescription: [
                    {
                        name: 'URL',
                        description: 'Url of the redirection'
                    }
                ]
            }
        ]),
    content: [{
        itemId: 'review_customer_title1',
        type: 'text',
        displayName: 'Review customer title1',
        description: 'Review customer title1',
        defaultValue: 'Personal'
    },
    {
        itemId: 'review_customer_title2',
        type: 'text',
        displayName: 'Review customer title2',
        description: 'Review customer title2',
        defaultValue: 'Details'
    },
    {
        itemId: 'create_customer_purpose_text',
        type: 'text',
        displayName: 'Create Customer purpose text',
        description: 'Create Customer purpose text',
        defaultValue: 'Insert Personal Information'
    },
    {
        itemId: 'personal_details_title_text1',
        type: 'text',
        displayName: 'Personal details section title1',
        description: 'Personal details section title1',
        defaultValue: 'Personal'
    },
    {
        itemId: 'personal_details_title_text2',
        type: 'text',
        displayName: 'Personal details section title2',
        description: 'Personal details section title2',
        defaultValue: 'Details'
    },
    {
        itemId: 'personal_details_information_text',
        type: 'text',
        displayName: 'Personal details section information text',
        description: 'Personal details section information text',
        defaultValue: 'We will use this information to contact you'
    },
    {
        itemId: 'id_details_information_text',
        type: 'text',
        displayName: 'ID details section information text',
        description: 'ID details section information text',
        defaultValue: 'We Will Use This Information To Confirm Your Identity'
    },
    {
        itemId: 'id_details_title_text1',
        type: 'text',
        displayName: 'ID details section title1',
        description: 'ID details section title1',
        defaultValue: 'ID'
    },
    {
        itemId: 'id_details_title_text2',
        type: 'text',
        displayName: 'ID details section title2',
        description: 'ID details section title2',
        defaultValue: 'Details'
    },
    {
        itemId: 'address_details_information_text',
        type: 'text',
        displayName: 'Address details section information text',
        description: 'Address details section information text',
        defaultValue: 'This Is Your Personal Address'
    },
    {
        itemId: 'address_details_title_text1',
        type: 'text',
        displayName: 'Address details section title1',
        description: 'Address details section title1',
        defaultValue: 'Address'
    },
    {
        itemId: 'address_details_title_text2',
        type: 'text',
        displayName: 'Address details section title2',
        description: 'Address details section title2',
        defaultValue: 'Details'
    },
    {
        itemId: 'contact_address_label',
        type: 'text',
        displayName: 'Label for Address field in review mode',
        description: 'Label for Address field in review mode',
        defaultValue: 'Contact Address'
    },
    {
        itemId: 'save_button',
        type: 'text',
        displayName: 'Label for save button',
        description: 'Label for save button',
        defaultValue: 'Save'
    },
    {
        itemId: 'firstname_validation_max_length',
        type: 'text',
        displayName: 'Validation Message for maxLength',
        description: 'Validation Message for maxLength',
        defaultValue: 'First name needs to have maximum 30 characters'
    },
    {
        itemId: 'min_age_validation',
        type: 'text',
        displayName: 'Validation Message for minimal age on birthday field',
        description: 'Validation Message for minimal age on birthday field',
        defaultValue: 'For example: 31 12 1970, customer must be {minimumAge} or more.'
    },
    {
        itemId: 'phone_prefix_validation',
        type: 'text',
        displayName: 'Validation Message for phone prefix',
        description: 'Validation Message for phone prefix',
        defaultValue: 'Invalid phone entry'
    },
    {
        itemId: 'issued_on_validation',
        type: 'text',
        displayName: 'Validation Message for issued on',
        description: 'Validation Message for issued on',
        defaultValue: 'Invalid issued date entry'
    },
    {
        itemId: 'expiration_date_validation',
        type: 'text',
        displayName: 'Validation Message for phone prefix',
        description: 'Validation Message for phone prefix',
        defaultValue: 'Invalid expiration date entry'
    },
    {
        itemId: 'id_document_mandatory_validation',
        type: 'text',
        displayName: 'Validation Message for mandatory id document',
        description: 'Validation Message for mandatory id document',
        defaultValue: 'Required field'
    },
    {
        itemId: 'id_document_max_file_size_validation',
        type: 'text',
        displayName: 'Validation Message for id document max file size',
        description: 'Validation Message for id document max file size',
        defaultValue: 'Please upload file upto {maxSize}{unitOfMeasure}'
    },
    {
        itemId: 'id_document_valid_file_format_validation',
        type: 'text',
        displayName: 'Validation Message for id document invalid file format',
        description: 'Validation Message for id document invalid file format',
        defaultValue: 'Please upload {formats} or {lastFormat} file type'
    },
    {
        itemId: 'expiration_date_validation_past',
        type: 'text',
        displayName: 'Validation Message for required field',
        description: 'Validation Message for required field',
        defaultValue: 'The identification document has expired, Please provide an updated ID'
    },
    {
        itemId: 'date_validation_early',
        type: 'text',
        displayName: 'Validation Message for required field',
        description: 'Validation Message for required field',
        defaultValue: 'The provided date is too early'
    },
    {
        itemId: 'date_validation_late',
        type: 'text',
        displayName: 'Validation Message for required field',
        description: 'Validation Message for required field',
        defaultValue: 'The provided date is too late'
    },
    {
        itemId: 'edit_button',
        type: 'text',
        displayName: 'Edit button',
        description: 'Edit button',
        defaultValue: 'Edit'
    },
    {
        itemId: 'cancel_button',
        type: 'text',
        displayName: 'Cancel button',
        description: 'Cancel button',
        defaultValue: 'Cancel'
    },
    {
        itemId: 'change_button',
        type: 'text',
        displayName: 'change button',
        description: 'change button',
        defaultValue: 'Change'
    },
    {
        itemId: 'view_more_label',
        type: 'text',
        displayName: 'view more label',
        description: 'view more label',
        defaultValue: 'View More'
    },
    {
        itemId: 'view_less_label',
        type: 'text',
        displayName: 'view less label',
        description: 'view less label',
        defaultValue: 'View Less'
    },
    {
        itemId: 'change_details_modal_button',
        type: 'text',
        displayName: 'duplicate customer modal change details buttons',
        description: 'duplicate customer modal change details buttons',
        defaultValue: 'Change my Contact Details'
    },
    {
        itemId: 'duplicate_customer_error_body',
        type: 'text',
        displayName: 'duplicate customer modal login button',
        description: 'duplicate customer modal login button',
        defaultValue: 'Login'
    },
    {
        itemId: 'email',
        type: 'text',
        displayName: 'Email',
        description: 'Email',
        defaultValue: 'Email'
    },
    {
        itemId: 'confirm_email',
        type: 'text',
        displayName: 'Confirm Email',
        description: 'Confirm Email',
        defaultValue: 'Confirm Email'
    },
    {
        itemId: 'phone_number',
        type: 'text',
        displayName: 'Phone Number',
        description: 'Phone Number',
        defaultValue: 'Phone Number'
    },
    {
        itemId: 'preferred_contact_method',
        type: 'text',
        displayName: 'Preferred Contact Method',
        description: 'Preferred Contact Method',
        defaultValue: 'Preferred Contact Method'
    },
    {
        itemId: 'preferred_time',
        type: 'text',
        displayName: 'Preferred Time',
        description: 'Preferred Time',
        defaultValue: 'Preferred Time'
    },
    {
        itemId: 'preferred_language',
        type: 'text',
        displayName: 'Preferred Time',
        description: 'Preferred Time',
        defaultValue: 'Preferred Language'
    },
    {
        itemId: 'continue_button',
        type: 'text',
        displayName: 'Label for Submit Button',
        description: 'Label for Submit Button',
        defaultValue: 'Continue'
    },
    // override all the translations as no graphic part of the core is used
    {
        groupId: 'create-customer-title-view',
        displayName: 'Create Customer Title ',
        itemId: 'create_customer_title',
        description: 'Create Customer Title',
        defaultValue: 'In order to create your account, we need some details about you'
    },
    {
        groupId: 'required-field-indicator-view',
        displayName: 'Required field message',
        itemId: 'required_field_indicator_label',
        description: 'Reference text for required field indicator',
        defaultValue: 'Required fields'
    },
    {
        groupId: 'personal-details-view',
        displayName: 'Personal Details section title',
        itemId: 'personal_details',
        description: 'Personal details section title',
        defaultValue: '<span class=\'ds-special\'>Personal</span>Details'
    },
    {
        groupId: 'id-details-view',
        displayName: 'ID Details Section title',
        itemId: 'id_details',
        description: 'ID details section title',
        defaultValue: 'Identification Details'
    },
    {
        groupId: 'address-details-view',
        displayName: 'Address Details Section title',
        itemId: 'address_details',
        description: 'Address details section title',
        defaultValue: '<span class=\'ds-special\'>Address</span>Details'
    },
    {
        groupId: 'address-details-view',
        displayName: 'Billing Address Details Section title',
        itemId: 'billing_address_details',
        description: 'Billing address details section title',
        defaultValue: '<span class=\'ds-special\'>Billing</span>Address'
    },
    {
        groupId: 'create-customer',
        displayName: 'Marketing permissions Section title',
        itemId: 'marketing_permissions',
        description: 'Marketing permissions section title',
        defaultValue: '<span class=\'ds-special\'>Marketing</span>Permissions'
    },
    {
        groupId: 'personal-details-view',
        displayName: 'First Name',
        itemId: 'firstname_label',
        description: 'Label for FirstName field',
        defaultValue: 'First Name'
    },
    {
        groupId: 'personal-details-view',
        displayName: 'Last Name',
        itemId: 'lastname_label',
        description: 'Label for LastName field',
        defaultValue: 'Last Name'
    },
    {
        groupId: 'personal-details-view',
        displayName: 'Fiscal Code',
        itemId: 'fiscalCode_label',
        description: 'Label for Fiscal Code field',
        defaultValue: 'Fiscal Code'
    },
    {
        groupId: 'personal-details-view',
        displayName: 'Birth Place',
        itemId: 'birthplace_label',
        description: 'Label for birth place field',
        defaultValue: 'BIRTHPLACE'
    },
    {
        groupId: 'personal-details-view',
        displayName: 'Fiscal Code Tooltip Link Text',
        itemId: 'fiscal_code_tooltip_link_text',
        description: 'Label for Fiscal Code Tooltip Link Text',
        defaultValue: 'Don\'t have a fiscal code?'
    },
    {
        groupId: 'personal-details-view',
        displayName: 'Fiscal Code Tooltip Text First Paragraph',
        itemId: 'fiscal_code_tooltip_text_1',
        description: 'Label for Fiscal Code Tooltip Text',
        defaultValue: 'If you do not have a Fiscal Code you need to generate a Fiscal Code yourself.'
    },
    {
        groupId: 'personal-details-view',
        displayName: 'Fiscal Code Tooltip Text Second Paragraph',
        itemId: 'fiscal_code_tooltip_text_2',
        description: 'Label for Fiscal Code Tooltip Text',
        defaultValue: 'After generating the code enter it in the Fiscal Code field.'
    },
    {
        groupId: 'personal-details-view',
        displayName: 'Identification Details Tooltip Link Text',
        itemId: 'id_tooltip_link_text',
        description: 'Label for Identification Details Tooltip Link Text',
        defaultValue: 'Why do you need my ID?'
    },
    {
        groupId: 'personal-details-view',
        displayName: 'Identification Details Tooltip Text',
        itemId: 'id_tooltip_text',
        description: 'Label for Identification Details Tooltip Text',
        defaultValue: 'To proceed with activation, if you are not already a Vodafone customer, you will need to ' +
        'send us a copy of your identity document (in compliance with Italian Law Decree No. 144 dated 27/07/2005).'
    },
    {
        groupId: 'personal-details-view',
        displayName: 'Contact Details Tooltip Link Text',
        itemId: 'contact_details_tooltip_link_text',
        description: 'Label for Contact Details Tooltip Link Text',
        defaultValue: 'Why do you need my contact details?'
    },
    {
        groupId: 'personal-details-view',
        displayName: 'Contact Details Tooltip Text',
        itemId: 'contact_details_tooltip_text',
        description: 'Label for Contact Details Tooltip Text',
        defaultValue: 'Why do you need my contact details?'
    },
    {
        groupId: 'personal-details-view',
        displayName: 'Gender',
        itemId: 'gender_label',
        description: 'Label for Gender field',
        defaultValue: 'Gender'
    },
    {
        groupId: 'personal-details-view',
        displayName: 'Gender placeholder text',
        itemId: 'gender_label_placeholder',
        description: 'Placeholder for Gender field',
        defaultValue: '(Male/Female)'
    },        
    {
        groupId: 'personal-details-view',
        displayName: 'Date of birth',
        itemId: 'birthDate_label',
        description: 'Label for Date of birth field',
        defaultValue: 'Date of birth'
    },
    {
        groupId: 'personal-details-view',
        displayName: 'Contact Number',
        itemId: 'contactNumber_label',
        description: 'Label for Contact Number field',
        defaultValue: 'Contact Number'
    },
    {
        groupId: 'personal-details-view',
        displayName: 'Email',
        itemId: 'email_label',
        description: 'Label for Email field',
        defaultValue: 'Email'
    },
    {
        groupId: 'personal-details-view',
        displayName: 'Confirm Email',
        itemId: 'confirm_email_label',
        description: 'Label for Email field',
        defaultValue: 'Confirm Email'
    },
    {
        groupId: 'personal-details-view',
        displayName: 'Phone number prefix',
        itemId: 'phone_number_prefix',
        description: 'Placeholder text for phone number prefix',
        defaultValue: '+39'
    },        
    {
        groupId: 'personal-details-view',
        displayName: 'Identification Details Header',
        itemId: 'identification_label',
        description: 'Label for Identification Details section',
        defaultValue: 'Identification Details'
    },
    {
        groupId: 'personal-details-view',
        displayName: 'Identification Details Note',
        itemId: 'identification_note',
        description: 'Note below the Identification Details header',
        defaultValue: 'Please note, provided information will be used for customer identification'
    },
    {
        groupId: 'preferred-contact-details-view',
        displayName: 'Preferred contact method',
        itemId: 'preferredContact_label',
        description: 'Label for Preferred contact method field',
        defaultValue: 'Preferred contact method'
    },
    {
        groupId: 'preferred-contact-details-view',
        displayName: 'Preferred contact time',
        itemId: 'preferredContactTime_label',
        description: 'Label for Preferred contact time field',
        defaultValue: 'Preferred contact time'
    },
    {
        groupId: 'preferred-contact-details-view',
        displayName: 'Preferred language',
        itemId: 'preferredLanguage_label',
        description: 'Label for Preferred contact time field',
        defaultValue: 'Preferred Language'
    },
    {
        groupId: 'id-details-view',
        displayName: 'ID Type',
        itemId: 'idType_label',
        description: 'Label for ID Type field',
        defaultValue: 'Type Of Document'
    },
    {
        groupId: 'id-details-view',
        displayName: 'ID Number',
        itemId: 'idNumber_label',
        description: 'Label for ID Number field',
        defaultValue: 'Document Number'
    },
    {
        groupId: 'id-details-view',
        displayName: 'Issuing Nation',
        itemId: 'issuing_nationality_label',
        description: 'Label for document Nationality field',
        defaultValue: 'Issuing Nation'
    },
    {
        groupId: 'id-details-view',
        displayName: 'Nationality',
        itemId: 'nationality_label',
        description: 'Label for Nationality field',
        defaultValue: 'Nationality'
    },
    {
        groupId: 'id-details-view',
        displayName: 'Document Acquisition',
        itemId: 'document_acquisition',
        description: 'Document Acquisiton Section Header',
        defaultValue: 'Document Acquisition'
    },
    {
        groupId: 'id-details-view',
        displayName: 'Document Note',
        itemId: 'document_note',
        description: 'Note in the Document Acquisition section',
        defaultValue: 'You will be required to present this document in order to activate your Vodafone ' +
        'subscription.'
    },
    {
        groupId: 'id-details-view',
        displayName: 'Document Note Label',
        itemId: 'document_note_label',
        description: 'Document Note Label',
        defaultValue: 'Important:'
    },
    {
        groupId: 'id-details-view',
        displayName: 'Continue Button',
        itemId: 'id_details_continue',
        description: 'Continue Button in ID Details Section',
        defaultValue: 'Continue'
    },
    {
        groupId: 'passport-identification-details-view',
        displayName: 'Issued By',
        itemId: 'issuedBy_label',
        description: 'Label for Issued By field',
        defaultValue: 'Issued By'
    },
    {
        groupId: 'passport-identification-details-view',
        displayName: 'Issued On',
        itemId: 'issuedOn_label',
        description: 'Label for Issued On field',
        defaultValue: 'Issued On'
    },
    {
        groupId: 'passport-identification-details-view',
        displayName: 'Expiration Date',
        itemId: 'expirationDate_label',
        description: 'Label for Expiration Date field',
        defaultValue: 'Expiration Date'
    },
    {
        groupId: 'address-details-view',
        displayName: 'Address',
        itemId: 'address_label',
        description: 'Label for Address field',
        defaultValue: 'Address'
    },
    {
        groupId: 'address-details-view',
        displayName: 'City',
        itemId: 'city_label',
        description: 'Label for City field',
        defaultValue: 'City'
    },
    {
        groupId: 'address-details-view',
        displayName: 'Country',
        itemId: 'country_label',
        description: 'Label for Country field',
        defaultValue: 'Country'
    },
    {
        groupId: 'address-details-view',
        displayName: 'Zip code',
        itemId: 'zip_label',
        description: 'Label for Zip code field',
        defaultValue: 'Zip code'
    },
    {
        groupId: 'address-details-view',
        displayName: 'Reuse address message',
        itemId: 'reuseAddress_label',
        description: 'Label for Use this address also as your billing address field',
        defaultValue: 'Use this address also as your billing address'
    },
    {
        groupId: 'address-details-view',
        displayName: 'Contact Address title text 1',
        itemId: 'contact_address_title_text1',
        description: 'Contact address details section title1',
        defaultValue: 'Contact'
    },
    {
        groupId: 'address-details-view',
        displayName: 'Contact Address title text 2',
        itemId: 'contact_address_title_text2',
        description: 'Contact address details section title2',
        defaultValue: 'Address'
    },
    {
        groupId: 'address-details-view',
        displayName: 'Billing Address title text 1',
        itemId: 'billing_address_title_text1',
        description: 'Billing address details section title1',
        defaultValue: 'Billing'
    },
    {
        groupId: 'address-details-view',
        displayName: 'Billing Address title text 2',
        itemId: 'billing_address_title_text2',
        description: 'Billing address details section title2',
        defaultValue: 'Address'
    },
    {
        groupId: 'address-details-view',
        displayName: 'Billing Address details section title text',
        itemId: 'billing_address_details_information_text',
        description: 'Billing Address details section title text',
        defaultValue: 'This is where a paper bill will be posted'
    },
    {
        groupId: 'submit-button-view',
        displayName: 'Submit',
        itemId: 'submit_button',
        description: 'Label for submit button',
        defaultValue: 'Delivery and Payment'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Formate Validation: First Name',
        itemId: 'firstname_formate_validation',
        description: 'Validation Message for first name field',
        defaultValue: 'Invalid First Name'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Formate Validation: Last Name',
        itemId: 'lastname_formate_validation',
        description: 'Validation Message for last name field',
        defaultValue: 'Invalid Last Name'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: First Name',
        itemId: 'firstname_validation_presence',
        description: 'Validation Message for required field',
        defaultValue: 'First name is required'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Last Name',
        itemId: 'lastname_validation_presence',
        description: 'Validation Message for required field',
        defaultValue: 'Last name is required'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Last Name',
        itemId: 'lastname_invalid',
        description: 'Validation Message for required field',
        defaultValue: 'Please insert a valid Last Name'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: First Name',
        itemId: 'firstname_invalid',
        description: 'Validation Message for required field',
        defaultValue: 'Please insert a valid First Name'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Email',
        itemId: 'email_validation_presence',
        description: 'Validation Message for required field',
        defaultValue: 'Email is required'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Confirm Email',
        itemId: 'confirm_email_validation_presence',
        description: 'Validation Message for required field',
        defaultValue: 'Confirm Email is required'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Confirm Email Not Same',
        itemId: 'confirm_email_not_matching',
        description: 'Validation Message for Confirm Email Not Same',
        defaultValue: 'Confirm Email is Not same as Email'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Fiscal Code',
        itemId: 'fiscalCode_validation_presence',
        description: 'Validation Message for required field',
        defaultValue: 'Fiscal Code is required'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Fiscal Code Length',
        itemId: 'fiscalCode_validation_max_length',
        description: 'Validation Message for maxLength',
        defaultValue: 'Fiscal Code needs to have maximum 16 characters'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Invalid Fiscal Code',
        itemId: 'fiscalCode_invalid',
        description: 'Validation Message for fiscal code',
        defaultValue: 'Please insert a valid FISCAL CODE'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Last Name Length',
        itemId: 'lastname_validation_max_length',
        description: 'Validation Message for maxLength',
        defaultValue: 'Last name needs to have maximum 30 characters'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Gender',
        itemId: 'gender_validation_presence',
        description: 'Validation Message for required field',
        defaultValue: 'Gender is required'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: BirthDate',
        itemId: 'birthdate_validation_presence',
        description: 'Validation Message for required field',
        defaultValue: 'Date is required'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Phone number',
        itemId: 'phone_validation_presence',
        description: 'Validation Message for required field',
        defaultValue: 'Phone number is required'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Phone number max length',
        itemId: 'phone_validation_max_length',
        description: 'Validation Message for maxLength',
        defaultValue: 'Phone number needs to have maximum {phoneNumberMaxDigits} digits'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Phone number min length',
        itemId: 'phone_validation_min_length',
        description: 'Validation Message for minLength',
        defaultValue: 'Phone number needs to have minimum {phoneNumberMinDigits} digits'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Preferred contact method',
        itemId: 'preferred_contact_validation_presence',
        description: 'Validation Message for required field',
        defaultValue: 'Preferred contact method is required'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Preferred contact time',
        itemId: 'preferred_contact_time_validation_presence',
        description: 'Validation Message for required field',
        defaultValue: 'Preferred contact time is required'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Email max length',
        itemId: 'email_validation_max_length',
        description: 'Validation Message for maxLength',
        defaultValue: 'Email needs to have maximum 80 characters'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Email Format',
        itemId: 'email_validation_email',
        description: 'Validation Message for Email format',
        defaultValue: 'Please enter a valid Email in the following format: jsmith@example.org'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: ID Type',
        itemId: 'idType_validation_presence',
        description: 'Validation Message for required field',
        defaultValue: 'Document type is required'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: ID Number',
        itemId: 'idNumber_validation_presence',
        description: 'Validation Message for required field',
        defaultValue: 'Document number is required'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: ID Number Format',
        itemId: 'idNumber_validation_format',
        description: 'Validation Message for format field',
        defaultValue: 'Document number is invalid' 
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Issue by',
        itemId: 'issue_by_validation_presence',
        description: 'Validation Message for required field',
        defaultValue: 'Issued by is required'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Issue on',
        itemId: 'issue_on_validation_presence',
        description: 'Validation Message for required field',
        defaultValue: 'Issued on is required'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Expiration date',
        itemId: 'expiration_date_validation_presence',
        description: 'Validation Message for required field',
        defaultValue: 'Expiration date is required'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Address',
        itemId: 'address_validation_presence',
        description: 'Validation Message for required field',
        defaultValue: 'Address is required'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Address max Length',
        itemId: 'address_validation_max_length',
        description: 'Validation Message for maxLength',
        defaultValue: 'Address needs to have maximum 200 characters'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: City',
        itemId: 'city_validation_presence',
        description: 'Validation Message for required field',
        defaultValue: 'City is required'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: City max length',
        itemId: 'city_validation_max_length',
        description: 'Validation Message for maxLength',
        defaultValue: 'City needs to have maximum 40 characters'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Country',
        itemId: 'country_validation_presence',
        description: 'Validation Message for required field',
        defaultValue: 'Nationality is required'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Country',
        itemId: 'zip_on_validation_presence',
        description: 'Validation Message for required field',
        defaultValue: 'Zip is required'
    },
    {
        groupId: 'create-customer-validation',
        displayName: 'Validation: Zip max length',
        itemId: 'zip_validation_max_length',
        description: 'Validation Message for maxLength',
        defaultValue: 'Zip needs to have maximum 6 characters'
    },
    {
        groupId: 'create-customer',
        displayName: 'Male Gender',
        itemId: 'gender_type_male',
        description: 'Gender option Male',
        defaultValue: 'Male'
    },
    {
        groupId: 'create-customer',
        displayName: 'Female Gender',
        itemId: 'gender_type_female',
        description: 'Gender option female',
        defaultValue: 'Female'
    },
    {
        groupId: 'create-customer',
        displayName: 'contact Post',
        itemId: 'contact_medium_post',
        description: 'Contact option Post',
        defaultValue: 'Post'
    },
    {
        groupId: 'create-customer',
        displayName: 'Contact Phone',
        itemId: 'contact_medium_phone',
        description: 'Contact option Phone',
        defaultValue: 'Phone'
    },
    {
        groupId: 'create-customer',
        displayName: 'Contact Email',
        itemId: 'contact_medium_email',
        description: 'Contact option email',
        defaultValue: 'Email'
    },
    {
        groupId: 'create-customer',
        displayName: 'eligibility failure heading',
        itemId: 'eligibility_Check_header',
        description: 'eligibility failure heading',
        defaultValue: 'We are sorry, but you are not eligible for this offer'
    },
    {
        groupId: 'create-customer',
        displayName: 'eligibility check warning first',
        itemId: 'eligibility_Check_warning_first',
        description: 'eligibility check warning first',
        defaultValue: 'You might want to go back to see other plans for you or cancel the order.'
    },
    {
        groupId: 'create-customer',
        displayName: 'eligibility check warning second',
        itemId: 'eligibility_Check_warning_second',
        description: 'eligibility check warning second',
        defaultValue: 'Selecting other plan replace the offer currently in your cart.'
    },
    {
        groupId: 'create-customer',
        displayName: 'select another plan button placehoder',
        itemId: 'select_another_plan_button_placehoder',
        description: 'select_another_plan_button_placehoder',
        defaultValue: 'select another plan'
    },
    {
        groupId: 'create-customer',
        displayName: 'cancel order button placehoder',
        itemId: 'cancel_order_button_placehoder',
        description: 'cancel_order_button_placehoder',
        defaultValue: 'cancel the order'
    },
    {
        groupId: 'error-modal',
        displayName: 'Incorrect MSISDN Header',
        itemId: 'incorrect_msisdn_number',
        description: 'Incorrect MSISDN Header Label',
        defaultValue: 'INCORRECT TELEPHONE NUMBER'
    },
    {
        groupId: 'error-modal',
        displayName: 'Incorrect MSISDN Modal Sub-header',
        itemId: 'incorrect_msisdn_number_sub_header',
        description: 'Incorrect MSISDN Sub-Header Label',
        defaultValue: 'THIS ORDER CANNOT BE COMPLETED'
    },
    {
        groupId: 'error-modal',
        displayName: 'incorrect MSISDN Modal Description Text',
        itemId: 'incorrect_msisdn_number_description_text',
        description: 'Incorrect MSISDN Modal Text',
        defaultValue: `This order includes discounts applied to telephone number +{MSISDN}.
            Unfortunately, this number is not associated with your account.
            To check whether you are eligible for a discount you must begin a new order.
            Please return to the catalog and correct the telephone number or remove it
            completely.
            Click "Continue" to proceed.`
    },
    {
        groupId: 'error-modal',
        displayName: 'Incompatible PM Modal Header',
        itemId: 'incompatible_pm_header',
        description: 'Incompatible Payment Method Modal Header',
        defaultValue: 'PAYMENT METHOD NOTIFICATION.'
    },
    {
        groupId: 'error-modal',
        displayName: 'Incompatible PM Modal Sub-header',
        itemId: 'incompatible_pm_sub_header',
        description: 'Incompatible Payment Method Modal Sub-Header',
        defaultValue: 'Oops, it seems that you already have a credit card in your account'
    },
    {
        groupId: 'error-modal',
        displayName: 'Incompatible PM Modal Description Text',
        itemId: 'incompatible_pm__description_text',
        description: 'Incompatible Payment Method Modal Description Text',
        defaultValue: `It appears that you are already a Vodafone customer and there is a credit card
            assigned to your account.
            So the order cannot be completed using the selected payment method (IBAN)
            Don't worry you can continue with your credit card and keep all the benefits and good
            prices.
            If you do not wish to continue with a credit card please contact Vodafone call center
            at 190.
            Your order number is {orderId}.`
    },
    {
        groupId: 'error-modal',
        displayName: 'Incorrect MSISDN Modal Button Label',
        itemId: 'incorrect_msisdn_button_label',
        description: 'Incorrect MSISDN Modal Button Label',
        defaultValue: 'Continue'
    },
    {
        groupId: 'error-modal',
        displayName: 'Incompatible PM Modal Button Label',
        itemId: 'incompatible_pm_button_label',
        description: 'Incompatible PM Modal Button Label',
        defaultValue: 'Continue With Credit Card'
    },
    {
        groupId: 'address-details-view',
        displayName: 'Address label',
        itemId: 'address_label',
        description: 'Address label',
        defaultValue: 'INDIRIZZO'
    },
    {
        groupId: 'address-details-view',
        displayName: 'Contact label',
        itemId: 'contactLabel',
        description: 'Contact label',
        defaultValue: 'INFORMAZIONI DI CONTATTO'
    },
    {
        groupId: 'address-details-view',
        displayName: 'Contact Address label',
        itemId: 'contactAddressLabel',
        description: 'Contact Address label',
        defaultValue: 'Informazioni di contatto'
    }
    ],
    groups: coreCustomerDescriptor.groups.concat(l9AddressDescriptor.groups.filter(
        (groupItem) => { return groupItem.groupId === 'behaviorGeolocation'; }), [{
            groupId: 'error-modal',
            displayName: 'Error Modal'
        }]),
    initializationParams: coreCustomerDescriptor.initializationParams.concat([]),
    stateParams: [],
    availableActions: []
};

module.exports = descriptor;
