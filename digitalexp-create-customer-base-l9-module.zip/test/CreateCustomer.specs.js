/* eslint no-unused-expressions: 0  prefer-arrow-callback: 0 */
import React from 'react';

import {expect} from 'chai';
import {shallow} from 'enzyme';

import CreateCustomerObject from '../src';
const {widget: CreateCustomer} = CreateCustomerObject;

export function tests() {
    describe('DigitalExpCreateCustomerWidget', function() {
        context('when instantiated', function() {
            // it('contains an input element', function() {
            //     const wrapper = shallow(<CreateCustomer />);
            //     expect(wrapper).to.not.be.null;
            // });
        });
    });
}

export default tests();
