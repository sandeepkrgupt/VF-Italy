const descriptor = {
    displayName: 'digitalexp-capture-consents-base-l9-module',
    widgetId: 'digitalexp-capture-consents-base-l9-module',
    widgetCategory: 'Digital Experience',
    widgetDomain: 'Care',
    widgetSalesChannel: 'Base',
    widgetDescription: 'None',
    topicName: 'captureConsents',
    behaviorParams: [
        {
            groupId: '',
            itemId: 'displaySubmitButton',
            displayName: 'Show Submit Button',
            type: 'boolean',
            description: 'Determine to display or not Submit button',
            defaultValue: false
        },
        {
            groupId: '',
            itemId: 'widgetMode',
            displayName: 'Widget Mode',
            type: 'text',
            description: 'Determine Widget Mode',
            defaultValue: 'COP'
        },
        {
            groupId: '',
            itemId: 'subscriptionStatus',
            displayName: 'Subscription Status',
            type: 'text',
            description: 'Subscription Status',
            defaultValue: 'active,suspended'
        },
        {
            groupId: '',
            itemId: 'displayOppositionConsents',
            displayName: 'Show Opposition consents',
            type: 'boolean',
            description: 'Determine to display or not opposition consents',
            defaultValue: true
        },
        {
            groupId: '',
            itemId: 'displayETGConsents',
            displayName: 'Show ETG consents',
            type: 'boolean',
            description: 'Determine to display or not ETG consents',
            defaultValue: true
        },
        {
            groupId: '',
            itemId: 'collapseFirstAccordian',
            displayName: 'Collapse first accordion for VF consents',
            type: 'boolean',
            description: 'VF consents first accordion (if exists i.e. when there are multiple subscriptions) is collapsed on page load',
            defaultValue: true
        },
        {
            groupId: '',
            itemId: 'collapseOppositionAccordian',
            displayName: 'Collapse accordion for Opposition consents',
            type: 'boolean',
            description: 'Accordion for Opposition consents is collapsed on page load',
            defaultValue: true
        },
        {
            groupId: '',
            itemId: 'collapseEtgAccordian',
            displayName: 'Collapse accordion for ETG consents',
            type: 'boolean',
            description: 'Accordion for ETG consents is collapsed on page load',
            defaultValue: true
        }
    ],
    outcomes: [
        /*{
            displayName: '',
            actionId: 'dummy_action_id',
            actionType: 'navigate',
            defaultValue: '',
            description: ''
        }*/
    ],
    content: [
        {
            groupId: '',
            displayName: 'Radio Group Value - Yes',
            itemId: 'radio_group_yes',
            description: 'Radio Group Value - Yes',
            defaultValue: 'Yes'
        },
        {
            groupId: '',
            displayName: 'Radio Group Value - No',
            itemId: 'radio_group_no',
            description: 'Radio Group Value - No',
            defaultValue: 'No'
        },
        {
            groupId: '',
            displayName: 'SUBMIT',
            itemId: 'submit',
            description: '',
            defaultValue: 'SUBMIT'
        },
        {
            groupId: '',
            displayName: 'Read More Label',
            itemId: 'read_more',
            description: 'Read More Label',
            defaultValue: 'Read More'
        },
        {
            groupId: '',
            displayName: 'Manage consent header',
            itemId: 'manage_consent_header',
            description: 'Manage consent header',
            defaultValue: 'Manage consents for your subscriptions'
        },
        {
            groupId: 'chq-consents',
            displayName: 'Manage consent header',
            itemId: 'chq_manage_consent_header',
            description: 'Manage consent header for subscription',
            defaultValue: 'Manage consents for'
        },
        {
            groupId: 'chq-consents',
            displayName: 'Edit Link',
            itemId: 'chq_edit_link',
            description: 'Edit Link',
            defaultValue: 'Edit'
        },
        {
            groupId: 'chq-consents',
            displayName: 'Opposition consents header',
            itemId: 'chq_oppositions_consent_header',
            description: 'Opposition consents header',
            defaultValue: 'Opposition consents'
        },
        {
            groupId: 'chq-consents',
            displayName: 'ETG consents header',
            itemId: 'chq_etg_consent_header',
            description: 'ETG consents header',
            defaultValue: 'ETG consents'
        },
        {
            groupId: 'chq-consents',
            displayName: 'Cancel label',
            itemId: 'chq_cancel_label',
            description: 'Cancel label',
            defaultValue: 'Cancel'
        },
        {
            groupId: 'chq-consents',
            displayName: 'Save label',
            itemId: 'chq_save_label',
            description: 'Save label',
            defaultValue: 'Save'
        }
    ],
    groups: [
        {
            groupId: 'chq-consents',
            displayName: 'CHQ Consents'
        }
    ],
    initializationParams: [
        {
            itemId: 'individualId',
            displayName: 'individualId',
            type: 'text',
            description: 'Individual Id',
            defaultValue: '',
            enableUrlInput: true
        },
        {
            itemId: 'customerId',
            displayName: 'customerId',
            type: 'text',
            description: 'Customer Id',
            defaultValue: '',
            enableUrlInput: true
        }
    ],
    stateParams: [
        /*{
            itemId: '',
            displayName: '',
            type: 'boolean',
            description: '',
            defaultValue: true
        }*/
    ]
};

module.exports = descriptor;
