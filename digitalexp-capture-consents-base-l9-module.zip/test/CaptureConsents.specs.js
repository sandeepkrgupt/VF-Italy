/* eslint no-unused-expressions: 0  prefer-arrow-callback: 0 */
import React from 'react';

import {expect} from 'chai';
import {shallow} from 'enzyme';

import CaptureConsents from '../src/widget/CaptureConsents';

export function tests() {
    describe('DigitalExpCaptureConsentsWidget', function() {
        context('when instantiated', function() {
            it('initialization', function() {
                const wrapper = shallow(<CaptureConsents />);
                expect(wrapper).to.not.be.null;
            }); 
        });
    });
}

export default tests();
