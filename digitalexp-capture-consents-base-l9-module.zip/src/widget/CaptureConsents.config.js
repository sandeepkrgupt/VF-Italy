import descriptor from '../../digitalexp-capture-consents-base-l9-module.descriptor';

// Import the behaviors from the descriptor
const {behaviorParams} = descriptor;
const descriptorValues = behaviorParams.reduce((map, descriptorBehaviour) => {
    const {itemId, defaultValue} = descriptorBehaviour;
    map[itemId] = defaultValue;

    return map;
}, {});

export default {
    defaultName: 'CaptureConsents',

    // Behaviour Parameters
    ...descriptorValues
};
