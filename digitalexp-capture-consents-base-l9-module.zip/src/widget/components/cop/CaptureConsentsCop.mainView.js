import React, {Component} from 'react';
import {FormattedMessage} from 'react-intl';
import isEmpty from 'lodash/isEmpty';
import {Form} from 'digitalexp-common-components-l9';
import {ExternalizeComponent} from 'digitalexp-generic-button-control-module';
import ConsentListView from './ConsentListView';
import Messages from '../../CaptureConsents.i18n';
import {RadioGroupValues} from '../../CaptureConsents.consts';

const {FormContainer} = Form;

@FormContainer({hasDefaults: true})
class CaptureConsentsCOPMainView extends Component {    
    constructor(props) {
        super(props);
        this.updateConsent = this.updateConsent.bind(this);
    }

    componentDidMount() {
        const {onConsentUpdateKey} = this.props;
        ExternalizeComponent.externalizeComponent(onConsentUpdateKey, {
            disabled: false,
            functionCallback: () => {
                return this.updateConsentPost();
            }
        });
        if (this.props.individualId) {
            const queryParams = {
                relatedFlow: 'Provide',
                relatedEntityType: 'Subscriber',
                partyPrivacyType: 'VF'
            };
            this.props.getConsents(this.props.individualId, queryParams).then((consentList) => {
                this.props.validateConsents(false);
                this.props.setTermsAndConditionsAcceptance({termsAndConditionsAccepted: false});
                this.initializeData(consentList);
            });
        }
    }
    
    getConsentFieldValue(consentList = []) {
        const consentDetails = {};
        const updatedConsentDetails = Object.keys(consentList).map((key) => {
            const item = consentList[key];
            item.forEach((consentInfo) => { 
                if (consentInfo.selectedValue !== undefined) {
                    consentDetails[`${key}_${consentInfo.code}`] = 
                    consentInfo.selectedValue ? RadioGroupValues.YES : RadioGroupValues.NO;
                }          
            });
            return consentDetails;
        });
        
        return updatedConsentDetails && [].concat(...updatedConsentDetails)[0];
    }

    getSubscriptionConsents = () => {
        const {consentList, individualId} = this.props;
        const consents = consentList && Object.keys(consentList)
        .filter(key => individualId === key)
        .reduce((obj, key) => {
            obj[key] = consentList[key];
            return obj[key];
        }, {});
        return consents;
    };

    updateConsentPost = () => {
        const {consentList, updateConsentPost, individualId, submitHandler, getProductIdFromCart} = this.props;
        const params = {
            relatedFlow: 'Provide',
            relatedEntityType: 'Subscriber',
            productId: getProductIdFromCart()            
        };
        const promise = new Promise((resolve, reject) => {
            updateConsentPost(individualId, consentList, params).then(() => {
                submitHandler();
            }, (err) => {
                reject(err);
            });
        });
        return promise;
    }

    updateConsent() {
        const {updateConsent, validateConsents, consentList} = this.props;
        const formValid = this.props.validateForm();
        validateConsents(formValid.isValid);
        updateConsent(consentList);
    }

    initializeData(consentList) {
        // const {consentList} = this.props;
        if (!isEmpty(consentList)) {
            const consentDetails = this.getConsentFieldValue(consentList);
            this.props.initializeFormValues({
                ...consentDetails
            });
        }        
    }

    render() {
        if (!isEmpty(this.props.consentList)) {
            return (
                <div className="ds-row ds-payment__frame">
                    <ConsentListView
                        consentList={this.getSubscriptionConsents()}
                        updateConsent={this.updateConsent}
                        intl={this.props.intl}
                        individualId={this.props.individualId}
                    />
                    {this.props.displaySubmitButton && 
                        <div className="ds-confirm-and-pay__pay">
                            <button 
                                className="ds-btn ds-btn--large ds-btn--primary" 
                                onClick={this.updateConsentPost}>
                                <FormattedMessage {...Messages.submit} />
                            </button>
                        </div>
                    }
                </div> 
            );
        }
        return null;
    }    
}

export default CaptureConsentsCOPMainView;
