import React from 'react';
import {FormattedMessage, FormattedHTMLMessage} from 'react-intl';
import {FormField} from 'digitalexp-common-components-l9';
import isEqual from 'lodash/isEqual';
import isEmpty from 'lodash/isEmpty';
import Messages from '../../CaptureConsents.i18n';
import {RadioGroupValues} from '../../CaptureConsents.consts';

const {MandatoryField, RadioGroup} = FormField;

function ConsentListView({
    consentList,
    updateConsent,
    intl,
    individualId
}) {
    const getConsentValidValue = (id) => {
        return [
            {
                id: `${id}--yes`,
                name: RadioGroupValues.YES,
                displayName: <FormattedMessage {...Messages.radio_group_yes} />
            },
            {
                id: `${id}--no`,
                name: RadioGroupValues.NO,
                displayName: <FormattedMessage {...Messages.radio_group_no} />
            }
        ];
    };

    const updateConsentHandler = (event, consent) => {
        const {value} = event;        
        if (isEqual(value, RadioGroupValues.YES)) {
            consent.selectedValue = true;
        } else {
            consent.selectedValue = false;
        }        
        updateConsent();
    };

    const getRadioConstraints = () => {
        const radioValidations = {
            presence: {}
        };
        return radioValidations;
    };

    const getLongDescription = (event, cObj, index) => {
        const parentTag = event.currentTarget.parentNode;        
        const formattedDesc = intl.formatHTMLMessage({id: `consentObj.code_${index}`,
            defaultMessage: cObj.longDescription});
        parentTag.innerHTML = formattedDesc;
    };

    const getDescription = (cObj, index) => {
        return (
            <div>
                <FormattedHTMLMessage 
                    {...{id: `consentObj.code_${index}`,
                        defaultMessage: cObj.description
                    }} 
                />
                {!isEmpty(cObj.longDescription) &&
                    <button 
                        className="ds-btn ds-btn--link" 
                        onClick={(event) => { getLongDescription(event, cObj, index); }}>
                        <FormattedHTMLMessage {...Messages.read_more} />
                    </button>
                }
            </div> 
        );
    };
    
    return (
        <div className="col-xs-12">
            <div className="consents-group">
                <div className="consents primary-sec">
                    <div className="consents-text">
                        <h4>
                            <i className="ds-icon-devicegrey" />
                            <FormattedMessage {...Messages.manage_consent_header} />
                        </h4>                      
                    </div>               
                </div>
                <div className="divider" />
                {
                    consentList.map((consentObj, index) => {
                        return (
                            <div className="consents">
                                <div className="consents-text">
                                    <h4>
                                        {<FormattedHTMLMessage 
                                            {...{id: `${consentObj.code}_id`, defaultMessage: consentObj.title}} 
                                        />}
                                    </h4>
                                    <p>
                                        {getDescription(consentObj, index)}
                                    </p>
                                </div>
                                <div className="consents-action ds-consent">
                                    <MandatoryField
                                        Component={RadioGroup}
                                        name={`${individualId}_${consentObj.code}`}
                                        values={getConsentValidValue(consentObj.id)}
                                        validateFieldOn="onChange"
                                        eventListeners={{
                                            onChange: (e) => {
                                                updateConsentHandler(e, consentObj);
                                            }
                                        }}
                                        constraints={getRadioConstraints(consentObj.code)}
                                        displayInlineError={false}
                                    />
                                </div>                         
                            </div>
                        );
                    })
                }
                <div className="divider" />
            </div>
        </div>
    );
}

export default ConsentListView;
