import React, {Component} from 'react';
import {FormattedMessage, FormattedHTMLMessage} from 'react-intl';
import {Modal, ModalUtils} from 'digitalexp-common-components-l9';

const {ModalHeader, ModalBody} = ModalUtils;

class DescriptionModalView extends Component {

    constructor(props) {
        super(props);
        this.getModalConfig = this.getModalConfig.bind(this);
        this.getHeaderConfig = this.getHeaderConfig.bind(this);
        this.getModalBody = this.getModalBody.bind(this);
    }    

    getModalConfig() {
        const config = {
            showOverLay: true,
            dialogBoxClass: 'ds-modal--wrapper__medium'
        };
        return config;
    }

    getHeaderConfig() {
        const titleText = (<FormattedMessage 
            {...{id: 'consentObj.longDescription',
                defaultMessage: this.props.title
            }} 
        />);
        return {
            showCloseButton: true,
            closeButtonClass: 'ds-modal--close',
            showTitle: true,
            titleText
        };
    }

    getModalBody() {
        const {longDescription} = this.props;
        return (
            <FormattedHTMLMessage 
                {...{id: 'consentObj.longDescription',
                    defaultMessage: longDescription
                }} 
            />
        );
    }   

    render() {
        const {handleModalClose} = this.props;
        return (
            <Modal config={this.getModalConfig()}>
                <ModalHeader config={this.getHeaderConfig()} handleButtonClick={handleModalClose} />
                <ModalBody>
                    {this.getModalBody()}
                </ModalBody>
            </Modal>
        );
    }

}

export default DescriptionModalView;
