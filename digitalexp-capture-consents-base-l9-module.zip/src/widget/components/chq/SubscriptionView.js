import React, {Component} from 'react';
import isEmpty from 'lodash/isEmpty';
import {FormattedMessage} from 'react-intl';
import {Form} from 'digitalexp-common-components-l9';
import Messages from '../../CaptureConsents.i18n';
import ConsentListView from './ConsentListView';
import {RadioGroupValues} from '../../CaptureConsents.consts';

const {FormContainer} = Form;

@FormContainer({hasDefaults: true})
class SubscriptionView extends Component {    
    constructor(props) {
        super(props);
        this.updateConsent = this.updateConsent.bind(this);
    }

    getConsentFieldValue(consentList = []) {
        const consentDetails = {};
        const updatedConsentDetails = Object.keys(consentList).map((key) => {
            const item = consentList[key];
            item.forEach((consentInfo) => { 
                if (consentInfo.selectedValue !== undefined) {
                    consentDetails[`${key}_${consentInfo.code}`] = 
                    consentInfo.selectedValue ? RadioGroupValues.YES : RadioGroupValues.NO;
                }          
            });
            return consentDetails;
        });
        
        return updatedConsentDetails && [].concat(...updatedConsentDetails)[0];
    }

    updateConsent() {
        const {updateConsent, validateConsents, consentList} = this.props;
        const formValid = this.props.validateForm();
        validateConsents(formValid.isValid);
        updateConsent(consentList);
    }

    initializeData(consentList) {
        // const {consentList} = this.props;
        if (!isEmpty(consentList)) {
            const consentDetails = this.getConsentFieldValue(consentList);
            this.props.updateFormValues({
                ...consentDetails
            });
        }        
    }

    render() {
        const {contactSubscriptions} = this.props;
        const getSubscriptionConsent = (subscription) => {
            const consentList = this.props.consentList;
            const consents = consentList && Object.keys(consentList)
            .filter(key => subscription.productId === key)
            .reduce((obj, key) => {
                obj[key] = consentList[key];
                return obj[key];
            }, {});
            return consents;
        };
        const handleSubscriptionClick = (e, subscription) => {
            const consents = getSubscriptionConsent(subscription);
            if (isEmpty(consents)) {
                const queryParams = {
                    relatedFlow: 'Management',
                    relatedEntityType: 'Subscriber',
                    productId: subscription.productId
                };
                this.props.getConsents(subscription.individualId, queryParams).then((consentList) => {
                    // this.props.validateConsents(false);
                    this.initializeData(consentList);
                });
            }            
            const parentTag = e.currentTarget.parentNode;
            if (parentTag.classList.contains('open')) {
                parentTag.classList.remove('open');
            } else {
                parentTag.classList.add('open');
            }
        };

        const handleEditClick = (e) => {                   
            const parentTag = e.currentTarget.parentNode.parentNode;
            const consentNode = parentTag.querySelector('.consents-all');
            consentNode.classList.remove('edit');        
        };

        const getConsentListView = (subscription) => {
            const consents = getSubscriptionConsent(subscription);
            if (!isEmpty(consents)) {
                return (<ConsentListView 
                    consentList={consents}
                    updateConsent={this.updateConsent}
                    intl={this.props.intl}
                    productId={subscription.productId}
                    displayOppositionConsents={this.props.displayOppositionConsents}
                    displayETGConsents={this.props.displayETGConsents}
                    collapseEtgAccordian={this.props.collapseEtgAccordian}
                    collapseOppositionAccordian={this.props.collapseOppositionAccordian}
                    updateConsentPost={this.props.updateConsentPost}
                    individualId={this.props.individualId}
                    completeConsentList={this.props.consentList} />
                );
            }
            return null;
        };

        return (
            <div>
                {
                    contactSubscriptions.map((subscription, index) => {
                        return (
                            <div className="ds-row ds-payment__frame">
                                <div className="col-xs-12">
                                    <div className="consents-group">
                                        <div className="consents primary-sec">
                                            <div className="consents-text">
                                                <h4>
                                                    <i className="ds-icon-devicegrey" />
                                                    <FormattedMessage {...Messages.chq_manage_consent_header} />
                                                    &nbsp;
                                                    <strong>{subscription.msisdn}</strong>
                                                </h4>
                                            </div>
                                            <button 
                                                className="ds-btn ds-btn--link ds-btn--editbtn"
                                                onClick={e => handleEditClick(e)}>
                                                <FormattedMessage {...Messages.chq_edit_link} />
                                            </button>
                                            <button 
                                                className="ds-open" 
                                                onClick={e => handleSubscriptionClick(e, subscription)} />
                                        </div>
                                        {getConsentListView(subscription)}
                                    </div>
                                </div>
                            </div>
                        );
                    })
                }
            </div>      
        );       
    }    
}

export default SubscriptionView;
