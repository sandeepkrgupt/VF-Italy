import React, {Component} from 'react';
import isEmpty from 'lodash/isEmpty';
import SubscriptionView from './SubscriptionView';
import ContactConsentListView from './ContactConsentListView';

class CaptureConsentsCHQMainView extends Component {    
    componentDidMount() {
        const {loadCustomerProducts, customerId, subscriptionStatus} = this.props;
        if (customerId) {
            loadCustomerProducts(customerId, subscriptionStatus).then((response) => {
                const subscriptions = this.props.getContactSubscriptions(this.props.individualId);
                if (isEmpty(subscriptions)) {
                    const queryParams = {
                        relatedFlow: 'Management',
                        relatedEntityType: 'Contact'
                    };
                    this.props.getConsents(this.props.individualId, queryParams);
                }
            });
        }       
    }

    render() {
        if (!isEmpty(this.props.contactSubscriptions)) {
            return (<SubscriptionView 
                {...this.props}
            />);
        } else if (!isEmpty(this.props.consentList)) {
            return (<ContactConsentListView 
                {...this.props}
            />);                        
        }
        return null;        
    }    
}

export default CaptureConsentsCHQMainView;
