import React, {Component} from 'react';
import {FormattedMessage, FormattedHTMLMessage} from 'react-intl';
import classnames from 'classnames';
import {Form, FormField} from 'digitalexp-common-components-l9';
import isEqual from 'lodash/isEqual';
import isEmpty from 'lodash/isEmpty';
import Messages from '../../CaptureConsents.i18n';
import {RadioGroupValues, PartyPrivacyType} from '../../CaptureConsents.consts';
import DescriptionModalView from '../modal/DescriptionModalView';

const {MandatoryField, RadioGroup} = FormField;
const {FormContainer} = Form;

@FormContainer({hasDefaults: true})
class ConsentListView extends Component {
    constructor(props, context) {
        super(props, context);
        this.state = {
            showModal: false,
            modalTitle: null,
            modalDescription: null        
        };
        this.initializeData(this.props.consentList);
    }
    
    getConsentFieldValue(consentList = []) {
        const consentDetails = {};
        const updatedConsentDetails = Object.keys(consentList).map((key) => {
            const item = consentList[key];
            item.forEach((consentInfo) => { 
                if (consentInfo.selectedValue !== undefined) {
                    consentDetails[`${key}_${consentInfo.code}`] = 
                    consentInfo.selectedValue ? RadioGroupValues.YES : RadioGroupValues.NO;
                }          
            });
            return consentDetails;
        });
        
        return updatedConsentDetails && [].concat(...updatedConsentDetails)[0];
    }

    getConsentValidValue = (id) => {
        return [
            {
                id: `${id}--yes`,
                name: RadioGroupValues.YES,
                displayName: <FormattedMessage {...Messages.radio_group_yes} />
            },
            {
                id: `${id}--no`,
                name: RadioGroupValues.NO,
                displayName: <FormattedMessage {...Messages.radio_group_no} />
            }
        ];
    };

    getRadioConstraints = () => {
        const radioValidations = {
            presence: {}
        };
        return radioValidations;
    };

    getLongDescription = (event, cObj) => {
        this.setState({
            showModal: true,
            modalTitle: cObj.title,
            modalDescription: cObj.longDescription
        });
    };

    getDescription = (cObj, index) => {
        return (
            <div>
                <FormattedHTMLMessage 
                    {...{id: `consentObj.code_${index}`,
                        defaultMessage: cObj.description
                    }} 
                />
                {!isEmpty(cObj.longDescription) &&
                    <button 
                        className="ds-btn ds-btn--link" 
                        onClick={(event) => { this.getLongDescription(event, cObj, index); }}>
                        <FormattedHTMLMessage {...Messages.read_more} />
                    </button>
                }                
            </div> 
        );
    };

    getContactConsent = () => {
        const consentList = this.props.consentList;        
        const consents = consentList && Object.keys(consentList)
        .filter(key => this.props.individualId === key)
        .reduce((obj, key) => {
            obj[key] = consentList[key];
            return obj[key];
        }, {});
        return consents;
    };

    initializeData(consentList) {
        // const {consentList} = this.props;
        if (!isEmpty(consentList)) {
            const consentDetails = this.getConsentFieldValue(consentList);
            this.props.updateFormValues({
                ...consentDetails
            });
        }        
    }

    updateConsentHandler = (event, consent) => {
        const {value} = event;        
        if (isEqual(value, RadioGroupValues.YES)) {
            consent.selectedValue = true;
        } else {
            consent.selectedValue = false;
        }        
        this.props.updateConsent();
    };
    
    handleOpenClick = (e) => {            
        const parentTag = e.currentTarget.parentNode.parentNode;
        if (parentTag.classList.contains('open')) {
            parentTag.classList.remove('open');
        } else {
            parentTag.classList.add('open');
        }
    };

    handleEditClick = (e) => {                   
        const parentTag = e.currentTarget.parentNode.parentNode;
        const consentNode = parentTag.querySelector('.consents-all');
        consentNode.classList.remove('edit');        
    };

    /**
     * called from modal upon cancel
     */
    closeModal = () => {
        this.setState({showModal: false});        
    }
   
    render() {
        const consentList = this.getContactConsent();
        const vfConsentList = consentList.filter(consent => consent.partyPrivacyType === PartyPrivacyType.VF);
        const oppoConsentList = consentList.filter(consent => consent.partyPrivacyType === PartyPrivacyType.OPPOSITION);
        const etgConsentList = consentList.filter(consent => consent.partyPrivacyType === PartyPrivacyType.ETG);
        const oppWrapperClass = classnames({
            open: !(this.props.collapseOppositionAccordian)
        }, 'ds-payment__div');
        const etgWrapperClass = classnames({
            open: !(this.props.collapseEtgAccordian)
        }, 'ds-payment__div');
        return (
            <div className="ds-row ds-payment__frame">
                <div className="col-xs-12">
                    <div className="consents-group">
                        <div className="consents primary-sec">
                            <div className="consents-text">
                                <h4>
                                    <i className="ds-icon-devicegrey" />
                                    <FormattedMessage {...Messages.chq_manage_consent_header} />
                                    &nbsp;
                                    <strong>Macro</strong>
                                </h4>
                            </div>
                            <button 
                                className="ds-btn ds-btn--link ds-btn--editbtn"
                                onClick={e => this.handleEditClick(e)}>
                                <FormattedMessage {...Messages.chq_edit_link} />
                            </button>                            
                        </div>
                        <div className="consents-all">
                            <div className="consents-all-edit">
                                {
                                    vfConsentList.map((consentObj, index) => {
                                        return (
                                            <div className="consents">
                                                <div className="consents-text">
                                                    <h4>
                                                        {<FormattedHTMLMessage 
                                                            {...{id: `${consentObj.code}_id`, 
                                                                defaultMessage: consentObj.title}} 
                                                        />}
                                                    </h4>
                                                    <p>
                                                        {this.getDescription(consentObj, index)}
                                                    </p>
                                                </div>
                                                <div className="consents-action ds-consent">
                                                    <MandatoryField
                                                        Component={RadioGroup}
                                                        name={`${this.props.productId}_${consentObj.code}`}
                                                        values={this.getConsentValidValue(consentObj.id)}
                                                        validateFieldOn="onChange"
                                                        eventListeners={{
                                                            onChange: (e) => {
                                                                this.updateConsentHandler(e, consentObj);
                                                            }
                                                        }}
                                                        constraints={this.getRadioConstraints(consentObj.code)}
                                                        displayInlineError={false}
                                                    />
                                                </div>                         
                                            </div>
                                        );
                                    })
                                }
                                {this.props.displayOppositionConsents && <div className="divider" />}                
                                {this.props.displayOppositionConsents &&
                                    <div className={oppWrapperClass}>
                                        <div className="tnc">
                                            <span className="tnc--text">
                                                <FormattedMessage {...Messages.chq_oppositions_consent_header} />
                                            </span>
                                            <button className="ds-open" onClick={e => this.handleOpenClick(e)} />
                                        </div>
                                        <div className="ds-payment__content">
                                            {
                                                oppoConsentList.map((consentObj, index) => {
                                                    return (
                                                        <div className="consents">
                                                            <div className="consents-text">
                                                                <h4>
                                                                    {<FormattedHTMLMessage 
                                                                        {...{
                                                                            id: `${consentObj.code}_id`, 
                                                                            defaultMessage: consentObj.title
                                                                        }} 
                                                                    />}
                                                                </h4>
                                                                <p>
                                                                    {this.getDescription(consentObj, index)}
                                                                </p>
                                                            </div>
                                                            <div className="consents-action ds-consent">
                                                                <MandatoryField
                                                                    Component={RadioGroup}
                                                                    name={`${this.props.productId}_${consentObj.code}`}
                                                                    values={this.getConsentValidValue(consentObj.id)}
                                                                    validateFieldOn="onChange"
                                                                    eventListeners={{
                                                                        onChange: (e) => {
                                                                            this.updateConsentHandler(e, consentObj);
                                                                        }
                                                                    }}
                                                                    constraints={
                                                                        this.getRadioConstraints(consentObj.code)
                                                                    }
                                                                    displayInlineError={false}
                                                                />
                                                            </div>                         
                                                        </div>
                                                    );
                                                })
                                            }
                                        </div>
                                    </div>
                                }
                                {this.props.displayETGConsents && <div className="divider" />}                
                                {this.props.displayETGConsents &&
                                    <div className={etgWrapperClass}>
                                        <div className="tnc">
                                            <span className="tnc--text">
                                                <FormattedMessage {...Messages.chq_etg_consent_header} />
                                            </span>
                                            <button className="ds-open" onClick={e => this.handleOpenClick(e)} />
                                        </div>
                                        <div className="ds-payment__content consents-all edit">
                                            {
                                                etgConsentList.map((consentObj, index) => {
                                                    return (
                                                        <div className="consents">
                                                            <div className="consents-text">
                                                                <h4>
                                                                    {<FormattedHTMLMessage 
                                                                        {...{
                                                                            id: `${consentObj.code}_id`, 
                                                                            defaultMessage: consentObj.title
                                                                        }} 
                                                                    />}
                                                                </h4>
                                                                <p>
                                                                    {this.getDescription(consentObj, index)}
                                                                </p>
                                                            </div>
                                                            <div className="consents-action ds-consent">
                                                                <MandatoryField
                                                                    Component={RadioGroup}
                                                                    name={`${this.props.productId}_${consentObj.code}`}
                                                                    values={this.getConsentValidValue(consentObj.id)}
                                                                    validateFieldOn="onChange"
                                                                    eventListeners={{
                                                                        onChange: (e) => {
                                                                            this.updateConsentHandler(e, consentObj);
                                                                        }
                                                                    }}
                                                                    constraints={
                                                                        this.getRadioConstraints(consentObj.code)
                                                                    }
                                                                    displayInlineError={false}
                                                                />
                                                            </div>                         
                                                        </div>
                                                    );
                                                })
                                            }
                                        </div>
                                    </div>
                                }
                            </div>
                            {this.state.showModal && (<DescriptionModalView 
                                title={this.state.modalTitle}
                                longDescription={this.state.modalDescription}
                                handleModalClose={this.closeModal}
                            />)}
                        </div>
                    </div>
                </div>
            </div>
        );
    }    
}

export default ConsentListView;
