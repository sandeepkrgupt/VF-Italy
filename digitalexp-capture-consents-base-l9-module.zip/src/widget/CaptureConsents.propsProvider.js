class PropsProvider {
    constructor(context) {
        this.context = context;
    }
    getComponentProps(props) {    
        return {
            intl: props.intl,
            consentList: props.consentList,
            getConsents: props.getConsents,
            individualId: props.individualId,
            onConsentUpdateKey: props.onConsentUpdateKey,
            updateConsentPost: props.updateConsentPost,
            displaySubmitButton: props.config.displaySubmitButton,
            validateConsents: props.validateConsents,
            submitHandler: props.submitHandler,
            setTermsAndConditionsAcceptance: props.setTermsAndConditionsAcceptance,
            widgetMode: props.config.widgetMode,
            loadCustomerProducts: props.loadCustomerProducts,
            customerId: props.customerId,
            contactSubscriptions: props.contactSubscriptions,
            subscriptionStatus: props.config.subscriptionStatus,
            displayOppositionConsents: props.config.displayOppositionConsents,
            displayETGConsents: props.config.displayETGConsents,
            updateConsent: props.updateConsent,
            getProductIdFromCart: props.getProductIdFromCart,
            collapseFirstAccordian: props.config.collapseFirstAccordian,
            collapseOppositionAccordian: props.config.collapseOppositionAccordian,
            collapseEtgAccordian: props.config.collapseEtgAccordian,
            getContactSubscriptions: props.getContactSubscriptions
        };
    }
}

export default PropsProvider;
