import React, {Component} from 'react';
import PropTypes from 'prop-types';
import isEqual from 'lodash/isEqual';
import CaptureConsentsCopView from './components/cop/CaptureConsentsCop.mainView';
import CaptureConsentsChqView from './components/chq/CaptureConsentsChq.mainView';
import CaptureConsentsProps from './CaptureConsents.propsProvider';
import {WidgetMode} from './CaptureConsents.consts';

class CaptureConsentsComponent extends Component {
    static get contextTypes() {
        return {
            policy: PropTypes.func,
            permissions: PropTypes.object,
            config: PropTypes.object
        };
    }

    constructor(props) {
        super(props);
        this.propsProvider = new CaptureConsentsProps(this.context);
    }

    render() {
        const {config} = this.props;
        if (isEqual(config.widgetMode, WidgetMode.CHQ)) {
            return (
                <CaptureConsentsChqView 
                    {...this.propsProvider.getComponentProps(this.props)}
                />
            );
        }

        return (
            <CaptureConsentsCopView 
                {...this.propsProvider.getComponentProps(this.props)}
            />
        );         
    }
}

export default CaptureConsentsComponent;

