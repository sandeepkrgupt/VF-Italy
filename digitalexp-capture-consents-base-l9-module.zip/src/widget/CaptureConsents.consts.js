const RadioGroupValues = {
    YES: 'Yes',
    NO: 'No'
};

const WidgetMode = {
    COP: 'COP',
    CHQ: 'CHQ'
};

const PartyPrivacyType = {
    ETG: 'ETG',
    OPPOSITION: 'Opposition',
    VF: 'VF'
};

export {
    RadioGroupValues,
    WidgetMode,
    PartyPrivacyType
};
