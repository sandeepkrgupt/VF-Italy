import {connect} from 'react-redux';
import sdk from 'digitalexp-light-sdk-l9';
import GlobalErrorApi from 'digitalexp-global-error-api-l9';
import LoaderApi from 'digitalexp-loader-api-l9';
import CustomerApi from 'digitalexp-customer-api';
import IndividualApi from 'digitalexp-individual-api-l9';
import OrderApi from 'digitalexp-order-api-l9';
import CustomerProfileApi from 'digitalexp-customer-profile-api-l9';
import CustomerProductsApi from 'digitalexp-customer-products-api-l9';
import CartApi from 'digitalexp-cart-api-l9';
import DecoratedComponent from './CaptureConsents';

export const OUTCOMES = {
    ON_BUTTON_CLICK: 'ON_BUTTON_CLICK'
};

const {getApiInstance} = sdk.getInstance();
const globalErrorApi = getApiInstance(GlobalErrorApi);
const loaderApi = getApiInstance(LoaderApi);
const customerApi = getApiInstance(CustomerApi);
const individualApi = getApiInstance(IndividualApi);
const orderApi = getApiInstance(OrderApi);
const customerProfileApi = getApiInstance(CustomerProfileApi);
const customerProductsApi = getApiInstance(CustomerProductsApi);
const cartApi = getApiInstance(CartApi);

const {errorDecorator} = globalErrorApi;
const {loaderDecorator} = loaderApi;

export const mapStateToProps = (state, ownProps) => {
    const individualId = (ownProps && ownProps.individualId) || customerProfileApi.getIndividualId();
    return {        
        customerId: (ownProps && ownProps.customerId) || customerApi.getCustomerId(),
        consentList: individualApi.getConsentsFromSlice(),
        individualId,
        contactSubscriptions: customerProductsApi.getSubscriptionsForSelectedContact(individualId)
    };   
};

export const mapDispatchToProps = () => {
    return {
        @errorDecorator
        @loaderDecorator
        getConsents: (individualId, queryParams) => {
            return individualApi.getConsents(individualId, queryParams);
        },
        @errorDecorator
        @loaderDecorator
        updateConsent: (payload) => {
            return individualApi.updateConsentsInState(payload);
        },
        @errorDecorator
        @loaderDecorator
        updateConsentPost: (individualId, consentList, params) => {           
            return individualApi.updateConsents(individualId, consentList, params);
        },
        validateConsents: (isConsentsValid) => {
            return orderApi.validateConsents(isConsentsValid);
        },
        @errorDecorator
        @loaderDecorator
        setTermsAndConditionsAcceptance: (termsAndConditionsAcceptance) => {
            return orderApi.setTermsAndConditionsAcceptance(termsAndConditionsAcceptance);
        },
        @errorDecorator
        @loaderDecorator
        loadCustomerProducts: (customerId, status) => {
            return customerProductsApi.loadCustomerProducts(customerId, status);
        },
        getProductIdFromCart: () => {
            return cartApi.getFirstItemProductIdFromCart();
        },
        getContactSubscriptions: (individualId) => {
            return customerProductsApi.getSubscriptionsForSelectedContact(individualId);
        }
    };
};

const ConnectedLoaderWidget = connect(
    mapStateToProps,
    mapDispatchToProps
)(DecoratedComponent);

export default ConnectedLoaderWidget;
