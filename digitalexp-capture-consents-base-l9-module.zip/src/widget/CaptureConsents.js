import Component from './CaptureConsents.component';
import Decorator from './CaptureConsents.decorator';

export default Decorator(Component);
