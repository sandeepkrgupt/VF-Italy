import {exportGlobal} from 'digitalexp-light-framework';

import Widget from './widget/CaptureConsents';
import ConnectedWidget from './widget/CaptureConsents.connect';
import descriptor from '../digitalexp-capture-consents-base-l9-module.descriptor';

const widgetObj = {
    Widget,
    ConnectedWidget,
    descriptor,
    id: descriptor.widgetId
};


export default widgetObj;

exportGlobal(`amdocs.widgets.${widgetObj.id}`, widgetObj);
