import CreateCustomerUtilsL9 from './CreateContact.utils';

export default class customerPropsProvider {
    constructor(context) {
        this.context = context;
    }
    getCommonProps(props) {
        const {
            intl,
            customerId,
            customerDetails,
            identificationTypes = [], 
            contactMethods = [],
            birthPlaces,
            config,
            preferredcontactTime = [],
            preferredLanguage = [],
            countries,
            externalExecuteMethods
        } = props;
        return {
            intl,
            customerId,
            customerDetails,
            identificationTypes,
            contactMethods,
            birthPlaces,
            config,
            preferredcontactTime,
            preferredLanguage,
            countries,
            externalExecuteMethods
        };
    }

    getValidationForField(props) {
        return (validationName, mandatoryFieldValidation = false) => {
            const {intl, config} = props;
            const validations = CreateCustomerUtilsL9.validations(intl, config, mandatoryFieldValidation);
            return validations[validationName];
        };
    } 
}
