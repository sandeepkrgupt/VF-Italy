import {
  MONTH_CODES,
  CHECK_CODE_ODD,
  CHECK_CODE_EVEN,
  OMOCODIA_TABLE,
  CHECK_CODE_CHARS,
  GENDER_FORMAT_FISCAL
} from './CreateContact.consts';

export default class CodiceFiscale {
    static compute (codeFObj) {
        let code = this.surnameCode(codeFObj.surname);
        code += this.nameCode(codeFObj.name);
        code += this.dateCode(codeFObj.day, codeFObj.month, codeFObj.year, codeFObj.gender);
        code += this.findLocationByName(codeFObj.birthplace, codeFObj.birthplaceArr).id;
        code += this.getCheckCode(code);
        return code;
    }

    static check (codiceFiscal) {
        if (typeof codiceFiscal !== 'string') return false;
        const codiceFiscale = codiceFiscal.toUpperCase();
        if (codiceFiscale.length !== 16) return false;
        const expectedCheckCode = codiceFiscale.charAt(15);
        const cf = codiceFiscale.slice(0, 15);
        return CodiceFiscale.getCheckCode(cf) === expectedCheckCode;
    }

    static estraiConsonanti (str) {
        return str.replace(/[^BCDFGHJKLMNPQRSTVWXYZ]/gi, '');
    }

    static getCheckCode (codiceFiscale) {
        let val = 0;
        for (let i = 0; i < 15; i += 1) {
            const c = codiceFiscale[i];
            val += i % 2 ? this.CHECK_CODE_EVEN[c] : this.CHECK_CODE_ODD[c];
        }
        val %= 26;
        return this.CHECK_CODE_CHARS.charAt(val);
    }

    static estraiVocali (str) {
        return str.replace(/[^AEIOU]/gi, '');
    }

    static surnameCode (surname) {
        const codeSurname = `${this.estraiConsonanti(surname)}${this.estraiVocali(surname)}XXX`;
        return codeSurname.substr(0, 3).toUpperCase();
    }

    static nameCode (name) {
        let codNome = this.estraiConsonanti(name);
        if (codNome.length >= 4) {
            codNome = codNome.charAt(0) + codNome.charAt(2) + codNome.charAt(3);
        } else {
            codNome += `${this.estraiVocali(name)}XXX`;
            codNome = codNome.substr(0, 3);
        }
        return codNome.toUpperCase();
    }

    static dateCode (gg, mm, aa, gender) {
        const date = new Date();
        date.setYear(aa);
        date.setMonth(mm - 1, 1);
        date.setDate(gg);
        // Padding year
        let year = `0 + ${date.getFullYear()}`;
        year = year.substr(year.length - 2, 2);

        const month = this.MONTH_CODES[date.getMonth()];
        let day = date.getDate();
        if (gender.toUpperCase() === GENDER_FORMAT_FISCAL.Female) day += 40;

        // Padding day
        day = `0${day}`;
        day = day.substr(day.length - 2, 2);
        return String(year + month + day);
    }

    static findLocationByName(locName, arrPlaces) {
        let birthPlace = {};
        const birthPlaceExist = arrPlaces.find((item) => {
            return item.displayName === locName;
        });
        if (birthPlaceExist) {
            birthPlace = birthPlaceExist;
        }
        return birthPlace;
    }

    static findLocationByCode(locCode, arrPlaces) {
        let birthPlace = {};
        const birthPlaceExist = arrPlaces.find((item) => {
            return item.id === locCode;
        });
        if (birthPlaceExist) {
            birthPlace = birthPlaceExist;
        }
        return birthPlace;
    }

    static getOmocodie (code) {
        const results = [];
        const code1 = code.slice(0, 15);
        let lastOmocode = (code1);
        for (let i = code.length - 1; i >= 0; i -= 1) {
            const char = code[i];
            if (char.match(/\d/)) {
                lastOmocode =
                lastOmocode.substr(0, i) +
                this.OMOCODIA_TABLE[char] +
                lastOmocode.substr(i + 1);
                results.push(lastOmocode + this.getCheckCode(lastOmocode));
            }
        }
        return results;
    }

    static computeInverse (codiceFiscal, birthPlaceData) {
        const isValid = this.check(codiceFiscal);
        let codiceFiscale = codiceFiscal;
        if (isValid) {
            codiceFiscale = codiceFiscale.toUpperCase();
        } else {
            throw new Error(
              'Provided input is not a valid Codice Fiscale'
            );
        }

        const name = codiceFiscale.substr(3, 3);
        const surname = codiceFiscale.substr(0, 3);

        const year = codiceFiscale.substr(6, 2);
        const yearList = [];
        const year19XX = parseInt(`19${year}`, 10);
        const year20XX = parseInt(`20${year}`, 10);
        const currentYear20XX = new Date().getFullYear();
        yearList.push(year19XX);
        if (currentYear20XX - year20XX >= 0) {
            yearList.push(year20XX);
        }

        const monthChar = codiceFiscale.substr(8, 1);
        const month = MONTH_CODES.indexOf(monthChar) + 1;

        let gender = GENDER_FORMAT_FISCAL.Male;
        let day = parseInt(codiceFiscale.substr(9, 2), 10);
        if (day > 31) {
            gender = GENDER_FORMAT_FISCAL.Female;
            day -= 40;
        }

        let birthplace = '';
        if (birthPlaceData) {
            birthplace = birthPlaceData.displayName;
        }

        return {
            name,
            surname,
            gender,
            day,
            month,
            year,
            birthplace
        };
    }
}

CodiceFiscale.MONTH_CODES = MONTH_CODES;
CodiceFiscale.CHECK_CODE_ODD = CHECK_CODE_ODD;
CodiceFiscale.CHECK_CODE_EVEN = CHECK_CODE_EVEN;
CodiceFiscale.OMOCODIA_TABLE = OMOCODIA_TABLE;
CodiceFiscale.CHECK_CODE_CHARS = CHECK_CODE_CHARS;

