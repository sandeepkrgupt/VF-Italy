import Component from './CreateContact.component';
import Decorator from './CreateContact.decorator';

export default Decorator(Component);
