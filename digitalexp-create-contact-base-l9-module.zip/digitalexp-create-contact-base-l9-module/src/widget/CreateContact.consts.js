const COMPONENT_MODES = {
    VIEW: 'View',
    EDIT: 'Edit',
    NEW: 'New',
    NONE: 'None'
};

const WIDGET_MODES = {
    CREATE: 'EDIT',
    REVIEW: 'REVIEW'
};

const CONTACT_MEDIUM_TYPES = {
    EMAIL: 'email',
    PHONE: 'phone',
    POSTAL_ADDRESS: 'postalAddress'
};

const ADDRESS_TYPES = {
    POSTAL: 'postalAddress',
    BILLING: 'billingAddress'
};

const ADDRESS_STATUS = {
    VALID: 'valid',               // Same address is found in system (SOLR or External).
    VALIDAMENDED: 'validAmended', // Not same but similar address is not found in system (SOLR or External).
    INVALID: 'invalid',           // No same or matching address is not found in system (SOLR or External).
    UNVALIDATED: 'unvalidated',   // Not applicable for validate.
    OBSOLETE: 'obsolete'          // Not applicable for validate.
};

const ADDRESS_FIELD_NAMES = {
    STREET_NUMBER: 'address.streetNumber',
    FRAZIONE: 'address.frazione',
    MAIL_BOX: 'address.mailBox',
    CITY: 'address.city',
    COUNTRY: 'address.country',
    STATE: 'address.state',
    POSTAL_CODE: 'address.postalCode'
};

const CART_VALIDATION_STATUS = {
    BLOCKED: 'blocked',
    WARING: 'warning',
    INFORMATION: 'information',
    SUCCESS: 'success'
};

const OPERATION_TYPE = {
    ADD: 'ADD'
};

const SECTIONS = {
    PERSONAL_DETAILS: 'personalDetails',
    ID_DETAILS: 'IdDetails'
};

const ComponentMode = 'ComponentMode';
const GeneralMessageConfiguration = {
    BUSINESS: 'BUSINESS',
    VALIDATION: 'VALIDATION',
    MISSING_MANDATORY: 'MISSING_MANDATORY',
    FORMAT_VALIDATION: 'FORMAT_VALIDATION'
};
const individualIdentificationType = 'identification.identificationType';

const FiscalDerivedMaxAgeLimit = 99;

const FiscalMaxLength = 16;

const GENDER_FORMAT_FISCAL = {
    Male: 'Male',
    Female: 'Female'
};

const MONTH_CODES = [
    'A',
    'B',
    'C',
    'D',
    'E',
    'H',
    'L',
    'M',
    'P',
    'R',
    'S',
    'T'  
];

const CHECK_CODE_ODD = {
    0: 1,
    1: 0,
    2: 5,
    3: 7,
    4: 9,
    5: 13,
    6: 15,
    7: 17,
    8: 19,
    9: 21,
    A: 1,
    B: 0,
    C: 5,
    D: 7,
    E: 9,
    F: 13,
    G: 15,
    H: 17,
    I: 19,
    J: 21,
    K: 2,
    L: 4,
    M: 18,
    N: 20,
    O: 11,
    P: 3,
    Q: 6,
    R: 8,
    S: 12,
    T: 14,
    U: 16,
    V: 10,
    W: 22,
    X: 25,
    Y: 24,
    Z: 23
};

const CHECK_CODE_EVEN = {
    0: 0,
    1: 1,
    2: 2,
    3: 3,
    4: 4,
    5: 5,
    6: 6,
    7: 7,
    8: 8,
    9: 9,
    A: 0,
    B: 1,
    C: 2,
    D: 3,
    E: 4,
    F: 5,
    G: 6,
    H: 7,
    I: 8,
    J: 9,
    K: 10,
    L: 11,
    M: 12,
    N: 13,
    O: 14,
    P: 15,
    Q: 16,
    R: 17,
    S: 18,
    T: 19,
    U: 20,
    V: 21,
    W: 22,
    X: 23,
    Y: 24,
    Z: 25
};

const OMOCODIA_TABLE = {
    0: 'L',
    1: 'M',
    2: 'N',
    3: 'P',
    4: 'Q',
    5: 'R',
    6: 'S',
    7: 'T',
    8: 'U',
    9: 'V'
};

const MONTH_NAME = {
    1: 'January',
    2: 'February',
    3: 'March',
    4: 'April',
    5: 'May',
    6: 'June',
    7: 'July',
    8: 'August',
    9: 'September',
    10: 'October',
    11: 'November',
    12: 'December'
};

const CHECK_CODE_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

const DATE_FORMAT = {
    DISPLAY_FORMAT: 'DD MMMM YYYY',
    SUBMIT_FORMAT: 'YYYY-MM-DD'
};

const TagManagement = {
    INFORMATION_ID_SECONDARY_PAGE: 'Personal information:ID Details',
    CHECKOUT_START_EVENT: 'checkout_start',
    ADDRESS_SECONDARY_PAGE: 'Personal information:Contact and address',
    CHECKOUT_ADDRESS_EVENT: 'checkout_address',
    ID_SECOND_SUB_CATEGORY: 'ID Details',
    ADDRESS_SECOND_SUB_CATEGORY: 'Contact and address'
};

const PAYMENT_METHODS = {
    CREDIT_CARD: 'CREDIT CARD',
    BANK: 'IBAN'
};

const MODAL_DISPLAY_MODE = {
    INCORRECT_MSISDN: 'INCORRECT_MSISDN',
    INCOMPATIBLE_PM: 'INCOMPATIBLE_PM'
};

const ERROR_CODES = {
    INTERNAL_SERVER_ERROR: 500
};

const CONTACT_TYPE_IDENTIFIED = {
    NEW: 'NEW',
    EXISTING: 'EXISTING',
    PARTIAL: 'PARTIAL'
};

const FISCAL_CODE_TYPE = {
    ITALIAN: 'Italian',
    NATO: 'NATO',
    OTHERS: 'Others'
};

const ERROR_CAUSE = {
    INVALID_FISCAL_CODE: 'InvalidFiscalCode'
};

export {
    CONTACT_MEDIUM_TYPES,
    COMPONENT_MODES,
    ADDRESS_TYPES,
    ADDRESS_STATUS,
    ADDRESS_FIELD_NAMES,
    WIDGET_MODES,
    CART_VALIDATION_STATUS,
    OPERATION_TYPE,
    SECTIONS,
    ComponentMode,
    GeneralMessageConfiguration,
    individualIdentificationType,
    FiscalDerivedMaxAgeLimit,
    FiscalMaxLength,
    MONTH_CODES,
    CHECK_CODE_ODD,
    CHECK_CODE_EVEN,
    OMOCODIA_TABLE,
    CHECK_CODE_CHARS,
    MONTH_NAME,
    GENDER_FORMAT_FISCAL,
    DATE_FORMAT,
    TagManagement,
    PAYMENT_METHODS,
    MODAL_DISPLAY_MODE,
    ERROR_CODES,
    CONTACT_TYPE_IDENTIFIED,
    FISCAL_CODE_TYPE,
    ERROR_CAUSE
};
