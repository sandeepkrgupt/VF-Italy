import {Container} from 'digitalexp-common-components-l9';
import defaultConfig from './CreateContact.config';

const ContainerDecorator = Container({
    config: {
        ...defaultConfig
    },
    propTypes: {
    }
});

export default ContainerDecorator;
