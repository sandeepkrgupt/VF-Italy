import React, {Component} from 'react';
import PropTypes from 'prop-types';
import isEmpty from 'lodash/isEmpty';
import CreateCustomerProps from './CreateContact.propsProvider';
import CreateCustomer from './components/CreateContactComponent';
import messages from './CreateContact.i18n';
import {CONTACT_TYPE_IDENTIFIED} from './CreateContact.consts';
import discriptor from '../../digitalexp-create-contact-base-l9-module.descriptor';

class CreateCustomerComponent extends Component {
    static get childContextTypes() {
        return {
            config: PropTypes.object
        };
    }

    static get contextTypes() {
        return {
            MESSAGE_CONTEXT: PropTypes.string
        };
    }

    constructor(props, context) {
        super(props, context);

        this.state = {
            isFormInvalid: false
        };

        this.handleCreateContact = this.handleCreateContact.bind(this);
        this.getSubmitHandler = this.getSubmitHandler.bind(this);
        this.setFormInvalid = this.setFormInvalid.bind(this);

        this.createCustomerProps = new CreateCustomerProps(context);
    }

    getChildContext() {
        return {config: this.props.config};
    }

    componentDidMount() {
        // Provide controller to connect
        this.props.provideController({
            getIntl: () => this.props.intl,
            getMessageContext: () => discriptor.widgetId
        });

        const {
            loadCustomerReferenceData, 
            loadContactMethods,
            loadPreferredContactTime,
            loadPreferredLanguages,
            contactMethods,
            identificationTypes,
            preferredcontactTime,
            preferredLanguage,
            loadCountries,
            countries
        } = this.props;
        
        if (isEmpty(contactMethods)) {
            loadContactMethods();
        }

        if (isEmpty(preferredcontactTime)) {
            loadPreferredContactTime();
        }
        if (isEmpty(preferredLanguage)) {
            loadPreferredLanguages();
        }

        if (isEmpty(identificationTypes)) {
            loadCustomerReferenceData();
        }        

        if (isEmpty(countries)) {
            loadCountries();
        }
    }

    componentWillUnmount() {
        const {clearWidgetMessages, provideController} = this.props;

        clearWidgetMessages();

        // Remove controller from connect
        provideController(null);
    } 

    getCreateCustomerProps() {
        const {isFormInvalid} = this.state;
        return {
            getValidationForField: this.createCustomerProps.getValidationForField(this.props),
            onSubmit: this.getSubmitHandler,
            loadBirthPlacesData: this.props.loadBirthPlacesData,
            clearGeneralMessage: this.props.clearWidgetMessages,
            showGeneralMessage: this.props.showGeneralMessage,
            isFormInvalid,
            setFormInvalid: this.setFormInvalid,
            findCaller: this.props.findCaller,
            retrieveContact: this.props.retrieveContact,
            IdentifiedContactDetails: this.props.IdentifiedContactDetails,
            callerDetails: this.props.callerDetails,
            contactTypeIdentified: this.props.contactTypeIdentified,
            updateContactTypeFlag: this.props.updateContactTypeFlag,
            invalidFiscalCodeTries: this.props.invalidFiscalCodeTries,
            incrementInvalidFiscalCodeTriesCount: this.props.incrementInvalidFiscalCodeTriesCount,
            resetInvalidFiscalCodeTriesCount: this.props.resetInvalidFiscalCodeTriesCount,
            clearAdditionalContactDetails: this.props.clearAdditionalContactDetails,
            ...this.createCustomerProps.getCommonProps(this.props)
        };
    }    

    getSubmitHandler(values) {
        if (this.props.contactTypeIdentified === CONTACT_TYPE_IDENTIFIED.EXISTING ||
            this.props.contactTypeIdentified === CONTACT_TYPE_IDENTIFIED.PARTIAL) {
            return this.handleUpdateContact(values);
        }
        return this.handleCreateContact(values);
    }

    setFormInvalid () {
        this.setState({
            isFormInvalid: true
        });
    }        

    handleCreateContact(values = {}) {
        const {owningIndividualAddress: {id}, customerId} = this.props;
        values.postalAddress = {
            id
        };
        const {intl} = this.props;
        const createCustomerErrorMessage = intl.formatMessage(messages.createContactErrorMessage);
        return this.props.createContact(
            values,
            customerId,
            createCustomerErrorMessage,
            this.props.handleModalClose).then(() => {
                Promise.resolve();
            }, (err) => {
                this.setFormInvalid();
                Promise.reject();
            });
    }

    handleUpdateContact = (values = {}) => {
        const {intl, owningIndividualAddress, IdentifiedContactDetails} = this.props;
        const createCustomerErrorMessage = intl.formatMessage(messages.createContactErrorMessage);
        if (!values.postalAddress) {
            values.postalAddress = IdentifiedContactDetails.postalAddress ?
                IdentifiedContactDetails.postalAddress : owningIndividualAddress;
        }
        const linkCustomerAndContactPayload = {
            contactObjId: IdentifiedContactDetails.contactObjId,
            customerId: this.props.customerId
        };
        return this.props.updateContact(
            values,
            createCustomerErrorMessage,
            this.props.handleModalClose,
            linkCustomerAndContactPayload
        ).then(() => {
            Promise.resolve();
        }, (err) => {
            this.setFormInvalid();
            Promise.reject();
        });
    }

    render() {
        return (
            <CreateCustomer {...this.getCreateCustomerProps()} />
        );        
    }
}

export default CreateCustomerComponent;
