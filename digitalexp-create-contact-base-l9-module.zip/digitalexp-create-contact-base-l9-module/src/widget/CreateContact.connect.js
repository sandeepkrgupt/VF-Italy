import {connect} from 'react-redux';
import sdk from 'digitalexp-light-sdk-l9';
import AddressManagementApiL9 from 'digitalexp-address-management-api-l9';
import CustomerProfileApi from 'digitalexp-customer-profile-api-l9';
import CustomerApiL9 from 'digitalexp-customer-api-l9';
import MessageHandlerApiL9 from 'digitalexp-message-handler-api-l9';
import UserManagementApi from 'digitalexp-user-management-api';
import GlobalErrorApi from 'digitalexp-global-error-api-l9';
import LoaderApi from 'digitalexp-loader-api-l9';
import IndividualApiL9 from 'digitalexp-individual-api-l9';
import CreateCustomerBase from './CreateContact';
import descriptor from '../../digitalexp-create-contact-base-l9-module.descriptor';
import {
    GeneralMessageConfiguration,
    ERROR_CODES,
    ERROR_CAUSE
} from './CreateContact.consts';

const {getApiInstance} = sdk.getInstance();
const customerProfileApi = getApiInstance(CustomerProfileApi);
const customerApiL9 = getApiInstance(CustomerApiL9);
const addressManagementApiL9 = getApiInstance(AddressManagementApiL9).getInstance('create_contact_nationality');
const messageHandlerApiL9 = getApiInstance(MessageHandlerApiL9);
const userManagementApi = getApiInstance(UserManagementApi);
const globalErrorApi = getApiInstance(GlobalErrorApi);
const loaderApi = getApiInstance(LoaderApi);
const individualApiL9 = getApiInstance(IndividualApiL9);

const {errorDecorator} = globalErrorApi;
const {loaderDecorator} = loaderApi;

export const mapStateToProps = (state, ownProps) => {   
    return {
        birthPlaces: customerApiL9.getBirthPlaces(),
        preferredcontactTime: customerProfileApi.getContactTime(),
        preferredLanguage: customerProfileApi.getPreferredLanguages(),
        userInformation: userManagementApi.getUserInformation(),
        alreadyUpdated: customerProfileApi.getAlreadyUpdated(),
        contactId: customerProfileApi.getContactId(),
        identificationId: customerProfileApi.getIdentificationId(),
        contactMethods: customerProfileApi.selectors.contactMethodsSelector(state),
        identificationTypes: customerProfileApi.selectors.idTypesSelector(state),
        countries: addressManagementApiL9.getCountries(),
        customerId: (ownProps && ownProps.customerId) || customerApiL9.getCustomerId(),
        IdentifiedContactDetails: individualApiL9.getAdditionalContactDetails() || {},
        callerDetails: customerProfileApi.getCallerDetails(),
        contactTypeIdentified: customerProfileApi.getContactTypeIdentified(),
        owningIndividualAddress: customerProfileApi.getOwningIndividualPhysicalAddress(),
        invalidFiscalCodeTries: customerProfileApi.getFiscalCodeTriesCount()
    };
};

export const mapDispatchToProps = () => { 
    return { 
        provideController: (ctl) => {
            this.ctl = ctl;
        },
        @errorDecorator
        @loaderDecorator
        loadContactMethods: () => {
            return customerProfileApi.fetchContactMediumOptions();
        },
        @errorDecorator
        @loaderDecorator
        loadBirthPlacesData: async (registryCode) => {
            const birthPlaces = await customerApiL9.loadBirthPlaces(registryCode);
            return birthPlaces;
        },
        @errorDecorator
        @loaderDecorator
        loadPreferredContactTime: () => {
            return customerProfileApi.fetchPreferredContactTime();
        },
        
        showGeneralMessage: (primaryMessage, category = GeneralMessageConfiguration.BUSINESS, errorCode = null) => {
            messageHandlerApiL9.addErrorMessage({
                primaryMessage,
                category,
                errorCode,
                messageContext: this.ctl.getMessageContext(),
                messageOrigin: descriptor.widgetId
            });
        },
        clearWidgetMessages: () => {
            messageHandlerApiL9.clearMessagesByOrigin(descriptor.widgetId);
        },                
        
        @errorDecorator
        @loaderDecorator
        loadPreferredLanguages: () => {
            return customerProfileApi.loadPreferredLanguages();
        },
        @errorDecorator
        @loaderDecorator
        loadCustomerReferenceData: () => {
            return customerProfileApi.fetchCustomerReferenceData();
        },
        @errorDecorator
        @loaderDecorator
        loadCountries: () => {
            return addressManagementApiL9.loadCountries();
        },
        @errorDecorator
        @loaderDecorator
        createContact: (
            createContactPayload,
            customerId,
            primaryMessage,
            handleModalClose
        ) => {
            const category = 'BUSINESS';
            const errorCode = null;
            return individualApiL9.createIndividual(createContactPayload)
                .then((response) => {
                    const {contactObjId} = response;
                    individualApiL9.linkContactAndCustomer({
                        contactObjId,
                        customerId
                    }).then(() => {
                        customerProfileApi.updateSelectedContactForAssignedSubs(response.id);
                        handleModalClose();
                    });
                })
                .catch((err) => {
                    if (err && err.statusCode === ERROR_CODES.INTERNAL_SERVER_ERROR
                        && err.errorCode === ERROR_CAUSE.INVALID_FISCAL_CODE) {
                        customerProfileApi.incrementFiscalCodeTriesFlag();
                    } else if (err && err.statusCode === ERROR_CODES.INTERNAL_SERVER_ERROR) {
                        messageHandlerApiL9.addErrorMessage({
                            primaryMessage,
                            category,
                            errorCode,
                            messageContext: this.ctl.getMessageContext(),
                            messageOrigin: descriptor.widgetId
                        });
                    }
                });
        },

        @errorDecorator
        @loaderDecorator
        findCaller: (data, primaryMessage) => {
            const category = 'BUSINESS';
            const errorCode = null;
            return customerProfileApi.findCaller(data)
                .catch((error) => {
                    if (error && error.statusCode === ERROR_CODES.INTERNAL_SERVER_ERROR) {
                        messageHandlerApiL9.addErrorMessage({
                            primaryMessage,
                            category,
                            errorCode,
                            messageContext: this.ctl.getMessageContext(),
                            messageOrigin: descriptor.widgetId
                        });
                    }
                });
        },

        @errorDecorator
        @loaderDecorator
        retrieveContact: (individualId) => {
            return individualApiL9.loadDetailsForAdditionalContact(individualId);
        },

        @errorDecorator
        @loaderDecorator
        updateContact: (
            createContactPayload,
            primaryMessage,
            handleModalClose,
            linkCustomerAndContactPayload
        ) => {
            const category = 'BUSINESS';
            const errorCode = null;
            return individualApiL9.updateAdditionalIndividual(createContactPayload)
                .then((response) => {
                    const updatedContactId = response.id;
                    individualApiL9.linkContactAndCustomer(linkCustomerAndContactPayload).then(() => {
                        individualApiL9.existingContactLinkedWithCustomer(true);
                        customerProfileApi.updateSelectedContactForAssignedSubs(updatedContactId);
                        handleModalClose();
                        individualApiL9.clearAdditionalContactDetails();
                    });
                }).catch((err) => {
                    individualApiL9.clearAdditionalContactDetails();
                    if (err && err.statusCode === ERROR_CODES.INTERNAL_SERVER_ERROR) {
                        messageHandlerApiL9.addErrorMessage({
                            primaryMessage,
                            category,
                            errorCode,
                            messageContext: this.ctl.getMessageContext(),
                            messageOrigin: descriptor.widgetId
                        });
                    }
                });
        },

        updateContactTypeFlag: (contactType) => {
            customerProfileApi.updateContactTypeFlag(contactType);
        },

        incrementInvalidFiscalCodeTriesCount: () => {
            customerProfileApi.incrementFiscalCodeTriesFlag();
        },

        resetInvalidFiscalCodeTriesCount: () => {
            customerProfileApi.resetInvalidFiscalCodeTriesCount();
        },

        clearAdditionalContactDetails: () => {
            individualApiL9.clearAdditionalContactDetails();
        }
    };
};

const ConnectedWidget = connect(
    mapStateToProps,
    mapDispatchToProps
)(CreateCustomerBase);

export default ConnectedWidget;
