import descriptor from '../../digitalexp-create-contact-base-l9-module.descriptor';

// Import the behaviors from the descriptor
const {behaviorParams} = descriptor;
const descriptorValues = behaviorParams.reduce((map, descriptorBehaviour) => {
    const {itemId, defaultValue} = descriptorBehaviour;
    map[itemId] = defaultValue;

    return map;
}, {});

export default {
    defaultName: 'CreateContact',

    // Behaviour Parameters
    showAddNewContactHeader: descriptorValues.showAddNewContactHeader,
    showFiscalCodeDerivedParamters: descriptorValues.showFiscalCodeDerivedParamters,
    showCreateContactSaveButton: descriptorValues.showCreateContactSaveButton,
    showFiscalCodeToolTip: descriptorValues.showFiscalCodeToolTip,
    showContactDetailsTooltip: descriptorValues.showContactDetailsTooltip,
    showPreferredContactTime: descriptorValues.showPreferredContactTime,
    defaultExpirationOffset: descriptorValues.defaultExpirationOffset,
    maxNumberOfFiscalTries: descriptorValues.maxNumberOfFiscalTries
};
