import React, {Component} from 'react';
import {Modal, ModalUtils} from 'digitalexp-common-components-l9';
import {FormattedMessage} from 'react-intl';
import _uniqueId from 'lodash/uniqueId';
import GenericButtonControlModule, {ExternalizeComponent} from 'digitalexp-generic-button-control-module';
import ClassNames from 'classnames';
import messages from '../CreateContact.i18n';

const {ModalHeader, ModalBody, ModalFooter} = ModalUtils;
const GenericButton = GenericButtonControlModule.Widget;

class ContactVerificationModalView extends Component {

    constructor(props) {
        super(props);
        this.getModalConfig = this.getModalConfig.bind(this);
        this.getHeaderConfig = this.getHeaderConfig.bind(this);
        this.getFooterBody = this.getFooterBody.bind(this);
        this.getFooterCancelProps = this.getFooterCancelProps.bind(this);
        this.getFooterContinueProps = this.getFooterContinueProps.bind(this);
        this.getModalBody = this.getModalBody.bind(this);
        const uniqueId = _uniqueId('CreateContactWidget');
        this.externalExecuteMethods = {
            uniqueId,
            handleContactVerificationCancel: `${uniqueId}.handleContactVerificationCancel`,
            handleContactVerificationContinue: `${uniqueId}.handleContactVerificationContinue`
        };
    }

    componentDidMount() {
        const {
            handleContactVerificationContinue,
            handleModalClose
        } = this.props;
        ExternalizeComponent.externalizeComponent(this.externalExecuteMethods.handleContactVerificationCancel, {
            functionCallback: () => {
                return handleModalClose();
            }
        });
        ExternalizeComponent.externalizeComponent(this.externalExecuteMethods.handleContactVerificationContinue, {
            functionCallback: () => {
                return handleContactVerificationContinue();
            }
        });
    }

    getModalConfig() {
        const config = {
            showOverLay: true,
            dialogBoxClass: 'ds-modal--wrapper__medium'
        };
        return config;
    }

    getHeaderConfig() {
        const titleText = <FormattedMessage {...messages.contact_verification_header} />;
        return {
            showCloseButton: true,
            closeButtonClass: 'ds-modal--close',
            showTitle: true,
            titleText
        };
    }

    getFooterCancelProps() {
        const buttonClass = ClassNames('ds-btn ds-btn--large ds-btn--secondary');
        const {handleContactVerificationCancel} = this.externalExecuteMethods;
        return {
            config: {
                className: buttonClass,
                executemethodKeys: `${handleContactVerificationCancel}`
            },
            children: <FormattedMessage {...messages.contact_verification_cancel_label} />
        };
    }   

    getModalBody() {
        const {callerDetails} = this.props;
        const phoneNumber = callerDetails && callerDetails.individualRef && callerDetails.individualRef.msisdn;
        return (
            <div className="ds-heading">
                <div><FormattedMessage
                    {...messages.contact_verification_message_1}
                    values={{
                        phoneNumber
                    }}
                />
                </div>
                <br />
                <div className="ds-field">
                    <div className="ds-row">
                        <div className="ds-field__line col-xs-12 col-sm-6">
                            <div className="ds-field__line-item">
                                <label className="ds-field__title">
                                    <FormattedMessage {...messages.enter_the_code_label} />
                                </label>
                                <input id="otp-field" className="ds-field__input" type="text" placeholder="XXXX" />
                            </div>                         
                        </div>      
                    </div>
                    <div className="ds-row">
                        <div className="col-xs-12 col-sm-6">                           
                            <FormattedMessage {...messages.contact_verification_message_2} />
                            <button className="ds-btn ds-btn--link ml10">
                                <FormattedMessage {...messages.resend_code_label} />
                            </button>
                        </div>      
                    </div>        
                </div> 
            </div>
        );
    }    

    getFooterContinueProps() {
        const buttonClass = ClassNames('ds-btn ds-btn--large ds-btn--primary');        
        const {handleContactVerificationContinue} = this.externalExecuteMethods;
        return {
            config: {
                className: buttonClass,
                executemethodKeys: `${handleContactVerificationContinue}`
            },
            children: <FormattedMessage {...messages.contact_verification_continue_label} />
        };
    }

    getFooterBody() {
        return (
            <div>
                <GenericButton
                    {...this.getFooterCancelProps()}
                />
                <GenericButton
                    {...this.getFooterContinueProps()}
                />
            </div>
        );
    }

    render() {
        const {handleModalClose} = this.props;
        return (
            <Modal config={this.getModalConfig()}>
                <ModalHeader config={this.getHeaderConfig()} handleButtonClick={handleModalClose} />
                <ModalBody>
                    {this.getModalBody()}
                </ModalBody>
                <ModalFooter>
                    {this.getFooterBody()}
                </ModalFooter>
            </Modal>
        );
    }
}

export default ContactVerificationModalView;
