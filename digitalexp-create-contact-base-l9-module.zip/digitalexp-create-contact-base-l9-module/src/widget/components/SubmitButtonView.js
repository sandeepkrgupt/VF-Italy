import React from 'react';
import {FormattedMessage} from 'react-intl';
import Messages from '../CreateContact.i18n';

export default function SubmitButtonView({showCreateContactSaveButton, formSubmit}) {
    if (!showCreateContactSaveButton) {
        return null;
    }
    return (
        <div className="ds-row btn-wrapper">
            <div className="col-xs-12">
                <button
                    type="submit"
                    className="ds-btn ds-btn--large ds-btn--primary ds-right"
                    onClick={formSubmit}>
                    <FormattedMessage {...Messages.save_button} />
                </button>
            </div>
        </div>
    );
}
