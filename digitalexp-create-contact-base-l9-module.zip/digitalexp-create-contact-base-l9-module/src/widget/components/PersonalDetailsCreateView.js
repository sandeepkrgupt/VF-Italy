import React, {Component} from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import {FormField, ComboBox, ReactDatePicker} from 'digitalexp-common-components-l9';
import {FormattedMessage} from 'react-intl';
import _isEmpty from 'lodash/isEmpty';
import _get from 'lodash/get';
import Messages from '../CreateContact.i18n';
import {
    DATE_FORMAT,
    CONTACT_TYPE_IDENTIFIED,
    FISCAL_CODE_TYPE} from '../CreateContact.consts';
import TooltipView from './TooltipView';

const {Input} = FormField;

export default class PersonalDetailsCreateView extends Component {
    static get contextTypes() {
        return {
            getFieldValue: PropTypes.func,
            registerFieldConstraints: PropTypes.func
        };
    }

    constructor(props) {
        super(props);
        this.state = {
            invalidFiscalTries: 0
        };
    }

    onChangeAction = (date) => {
        const {updateFields} = this.props;
        updateFields([{name: 'identification.expirationDate',
            value: date.format(DATE_FORMAT.SUBMIT_FORMAT)}]);
    };

    onChangeRawHandler = (date) => {
        const {updateFields} = this.props;
        updateFields([{name: 'identification.expirationDate', value: date.target.value}]);
    }

    getDefaultValue = () => {
        const {config} = this.props;
        let defaultValue = moment().add(config.defaultExpirationOffset, 'days');
        const {getFieldValue} = this.context;
        const date = getFieldValue('identification.expirationDate');
        if (date) {
            defaultValue = moment(date, DATE_FORMAT.SUBMIT_FORMAT);
        }
        return defaultValue;
    };

    getSelectedDate = () => {
        const {getFieldValue} = this.props;
        const selectedDate = getFieldValue('identification.expirationDate');
        if (selectedDate) {
            return moment(selectedDate, DATE_FORMAT.SUBMIT_FORMAT);
        }
        return null;
    }

    handleFiscalCodeBlur = () => {
        this.props.fiscaleCheck().then((fiscalCode) => {
            const data = {
                fiscalCode,
                filters: {
                    partialDataFlag: false,
                    noFiscalCodeFlag: FISCAL_CODE_TYPE.ITALIAN
                }
            };
            if (this.props.contactTypeIdentified !== CONTACT_TYPE_IDENTIFIED.PARTIAL) {
                const findCallerFailureMessage = this.props.intl.formatMessage(Messages.findCallerFailureMessage);
                this.props.findCaller(data, findCallerFailureMessage).then((response) => {
                    if (!_isEmpty(_get(response, 'callerDetails.individualRef.id'))) {
                        this.props.updateContactTypeFlag(CONTACT_TYPE_IDENTIFIED.EXISTING);
                        this.props.showExistingContactModal();
                    }
                });
            }
        }).catch((err) => {
            if (err === 'Invalid Fiscale Code') {
                console.log(this.props);
                const maxNumberOfFiscalTries = this.props.config.maxNumberOfFiscalTries;
                if (this.props.invalidFiscalCodeTries === maxNumberOfFiscalTries) {
                    this.props.showInvalidFiscalCodeModal();
                    this.resetFiscalTriesCount();
                } else {
                    this.props.incrementInvalidFiscalCodeTriesCount();
                }
            }
        });
    }
    
    handleNameBlur = () => {
        const firstName = this.props.getFieldValue('firstName');
        const secondName = this.props.getFieldValue('lastName');
        const phoneNumber = this.props.getFieldValue('phoneNumber');
        if (this.props.contactTypeIdentified !== CONTACT_TYPE_IDENTIFIED.EXISTING &&
            !_isEmpty(firstName) &&
            !_isEmpty(secondName) &&
            !_isEmpty(phoneNumber)
        ) {
            this.props.validateField({
                name: 'phoneNumber',
                value: phoneNumber,
                constraint: this.props.getValidationForField('phone')}).then(() => {
                    if (_isEmpty(this.props.getFormData().errors)) {
                        const data = {
                            firstName,
                            secondName,
                            phoneNumber,
                            filters: {
                                partialDataFlag: true,
                                noFiscalCodeFlag: FISCAL_CODE_TYPE.ITALIAN
                            }
                        };
                        const findCallerFailureMessage =
                            this.props.intl.formatMessage(Messages.findCallerFailureMessage);
                        this.props.findCaller(data, findCallerFailureMessage).then((response) => {
                            if (!_isEmpty(_get(response, 'callerDetails.individualRef.id'))) {
                                this.props.retrieveContact(response.callerDetails.individualRef.id);
                                this.props.updateContactTypeFlag(CONTACT_TYPE_IDENTIFIED.PARTIAL);
                            } else {
                                this.props.clearAdditionalContactDetails();
                                this.props.updateContactTypeFlag();
                            }
                        });
                    }
                }
            );
        }
    };

    resetFiscalTriesCount = () => {
        this.props.resetInvalidFiscalCodeTriesCount();
    }

    render() {
        const {
            intl,
            config,
            formFields,
            getValidationForField,
            identificationDetails,
            handleIdentificationChange,           
            countries,
            showAddNewContactHeader,
            getFieldValue,
            IdentifiedContactDetails}
         = this.props;

        const {MandatoryField} = formFields;
        const {identification} = IdentifiedContactDetails;

        return (
            <div className="ds-form">
                <div className="ds-form__fieldset">
                    {showAddNewContactHeader &&
                        <div className="ds-title">
                            <span className="ds-title__text">
                                <FormattedMessage {...Messages.id_details} />
                            </span>
                        </div> 
                    }                    
                    <div className="ds-form__container ds-row">
                        <MandatoryField
                            Component={Input}
                            label={intl.formatMessage(Messages.firstname_label)}
                            name="firstName"
                            eventListeners={{onBlur: this.handleNameBlur}}
                            type="text"
                            constraints={getValidationForField('firstName')}
                            isMandatory
                            skipConstraints={['presence']}
                            config={{fieldWrapperClassName: 'col-xs-12 col-sm-6'}}
                            disabled={this.props.contactTypeIdentified === CONTACT_TYPE_IDENTIFIED.EXISTING &&
                                !_isEmpty(IdentifiedContactDetails.firstName)}
                        />
                        <MandatoryField
                            Component={Input}
                            label={intl.formatMessage(Messages.lastname_label)}
                            name="lastName"
                            eventListeners={{onBlur: this.handleNameBlur}}
                            type="text"
                            constraints={getValidationForField('lastName')}
                            skipConstraints={['presence']}
                            config={{fieldWrapperClassName: 'col-xs-12 col-sm-6'}}
                            disabled={this.props.contactTypeIdentified === CONTACT_TYPE_IDENTIFIED.EXISTING &&
                                !_isEmpty(IdentifiedContactDetails.lastName)}
                        />
                    </div>
                    <div className="ds-form__container ds-row">
                        <div className="col-xs-12">
                            <div className="ds-form__group row">
                                <MandatoryField
                                    Component={ComboBox}
                                    label={intl.formatMessage(Messages.nationality_label)}
                                    name="nation"
                                    items={countries}
                                    allowItemAdd="true"
                                    displayField="displayName"
                                    placeholder="Select"
                                    searchable={false}
                                    config={{
                                        fieldIconClassName: 'ds-form__icon--address',
                                        hasIcon: true,
                                        fieldWrapperClassName: 'col-xs-12 col-sm-3'
                                    }}
                                    constraints={getValidationForField('nationality')}
                                    skipConstraints={['presence']}
                                    disabled={this.props.contactTypeIdentified === CONTACT_TYPE_IDENTIFIED.EXISTING &&
                                    !_isEmpty(IdentifiedContactDetails.nation)}
                                />
                                <MandatoryField
                                    Component={Input}
                                    label={intl.formatMessage(Messages.fiscalCode_label)}
                                    name="fiscalCode"
                                    type="text"
                                    eventListeners={{onBlur: this.handleFiscalCodeBlur}}
                                    constraints={getValidationForField('fiscalCode')}
                                    config={{fieldWrapperClassName: 'col-sm-6'}}
                                    skipConstraints={['presence']}
                                    disabled={this.props.contactTypeIdentified === CONTACT_TYPE_IDENTIFIED.EXISTING &&
                                    !_isEmpty(IdentifiedContactDetails.fiscalCode)}
                                />
                                {config.showFiscalCodeToolTip && (
                                    <div className="ds-form__line col-sm-6 fiscal-tooltip">
                                        <span className="ds-form__label">&nbsp;</span>
                                        <TooltipView
                                            tooltipTextMessageLabel={Messages.fiscal_code_tooltip_link_text}
                                            id={'fiscal'}
                                            innerComponent={() => {
                                                return (
                                                    <section className="ds-tooltip-item__content">
                                                        <div className="ds-tooltip__text">
                                                            <FormattedMessage
                                                                {...Messages.fiscal_code_tooltip_text_1}
                                                            />
                                                        </div>
                                                        <div className="ds-tooltip__text">
                                                            <FormattedMessage
                                                                {...Messages.fiscal_code_tooltip_text_2}
                                                            />
                                                        </div>
                                                    </section>
                                                );
                                            }}
                                        />
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                    <div className="ds-form__container ds-row">
                        {config.showFiscalCodeDerivedParamters && (
                            <MandatoryField
                                Component={Input}
                                label={intl.formatMessage(Messages.gender_label)}
                                name="gender"
                                type="text"
                                usePlaceholder
                                placeholder={intl.formatMessage(Messages.gender_label_placeholder)}
                                readOnly
                                config={{
                                    fieldWrapperClassName: 'col-xs-12 col-sm-3',
                                    fieldClassName: 'ds-form__input input-border0__item'
                                }}
                            />
                        )}
                        {config.showFiscalCodeDerivedParamters && (
                            <MandatoryField
                                Component={Input}
                                label={intl.formatMessage(Messages.birthDate_label)}
                                name="birthDate"
                                readOnly
                                config={{
                                    fieldWrapperClassName: 'col-xs-12 col-sm-3',
                                    fieldClassName: 'ds-form__input ds-date input-border0__item'
                                }}
                                usePlaceholder
                                placeholder="(DD Month YYYY)"
                            />
                        )}
                        {config.showFiscalCodeDerivedParamters && (
                            <MandatoryField
                                Component={Input}
                                label={intl.formatMessage(Messages.birthplace_label)}
                                name="birthPlace"
                                readOnly
                                config={{
                                    fieldWrapperClassName: 'col-xs-12 col-sm-6 birth-place',
                                    fieldClassName: 'ds-form__input input-border0__item'
                                }}
                                usePlaceholder
                                placeholder={intl.formatMessage(Messages.birthplace_label_placeholder)}
                            />
                        )}
                    </div>
                    <div className="ds-form__container acquisition ds-row">
                        <div className="col-xs-12">
                            <div className="ds-row acquisition__title">
                                <div className="ds-title col-xs-12 col-sm-4">
                                    <span className="ds-title__text">
                                        <FormattedMessage {...Messages.document_acquisition} />
                                    </span>
                                </div>
                                <div className="col-xs-12 col-sm-5">
                                    <TooltipView
                                        tooltipTextMessageLabel={Messages.id_tooltip_link_text}
                                        id={'id'}
                                        innerComponent={() => {
                                            return (
                                                <section className="ds-tooltip-item__content">
                                                    <div className="ds-tooltip__text">
                                                        <FormattedMessage {...Messages.id_tooltip_text} />
                                                    </div>
                                                </section>
                                            );
                                        }}
                                    />
                                </div>
                            </div>
                        </div>
                        <MandatoryField
                            Component={ComboBox}
                            label={intl.formatMessage(Messages.idType_label)}
                            name="identification.identificationType"
                            items={identificationDetails.idDetails.identificationTypes}
                            allowItemAdd="true"
                            displayField="displayName"
                            placeholder="Please Specify"
                            searchable={false}
                            config={{
                                fieldIconClassName: 'ds-form__icon--address',
                                hasIcon: true,
                                fieldWrapperClassName: 'col-xs-12 col-sm-6'
                            }}
                            constraints={getValidationForField('idType')}
                            validateFieldOn="onChange"
                            skipConstraints={['presence']}
                            eventListeners={{onChange: handleIdentificationChange}}
                            disabled={this.props.contactTypeIdentified === CONTACT_TYPE_IDENTIFIED.EXISTING &&
                            identification && !_isEmpty(identification[0].identificationType)}
                        />
                        <MandatoryField
                            Component={Input}
                            label={intl.formatMessage(Messages.idNumber_label)}
                            config={{fieldWrapperClassName: 'col-xs-12 col-sm-6'}}
                            name="identification.identificationNumber"
                            type="text"
                            constraints={getValidationForField('idNumber')}
                            skipConstraints={['presence']}
                            disabled={this.props.contactTypeIdentified === CONTACT_TYPE_IDENTIFIED.EXISTING &&
                            identification && !_isEmpty(identification[0].identificationNumber)}
                        />
                        <MandatoryField
                            Component={ComboBox}
                            label={intl.formatMessage(Messages.issuing_nationality_label)}
                            name="identification.nationality"
                            items={countries}
                            allowItemAdd="true"
                            displayField="displayName"
                            placeholder="Select"
                            searchable={false}
                            config={{
                                fieldIconClassName: 'ds-form__icon--address',
                                hasIcon: true,
                                fieldWrapperClassName: 'col-xs-12 col-sm-4'
                            }}
                            constraints={getValidationForField('documentNationality')}
                            skipConstraints={['presence']}
                            disabled={this.props.contactTypeIdentified === CONTACT_TYPE_IDENTIFIED.EXISTING &&
                            identification && !_isEmpty(identification[0].nationality)}
                        />
                        <MandatoryField
                            Component={ReactDatePicker}
                            label={intl.formatMessage(Messages.expirationDate_label)}
                            name="identification.expirationDate"
                            constraints={getValidationForField('expirationDate')}
                            minDate={moment().add(config.defaultExpirationOffset, 'days')}
                            selected={this.getSelectedDate()}
                            className="ds-form__input ds-date"
                            onChange={this.onChangeAction}
                            onChangeRaw={this.onChangeRawHandler}
                            config={{fieldWrapperClassName: 'col-xs-12 col-sm-4'}}
                            dateFormat="YYYY-MM-DD"
                            placeholderText="YYYY-MM-DD"
                            disabled={this.props.contactTypeIdentified === CONTACT_TYPE_IDENTIFIED.EXISTING &&
                            identification && !_isEmpty(identification[0].expirationDate)}
                        />
                        <div className="ds-note col-xs-12">
                            <span className="ds-bold">
                                <FormattedMessage {...Messages.document_note_label} />
                                &nbsp;
                            </span>
                            <FormattedMessage {...Messages.document_note} />
                        </div>
                    </div>                            
                </div>
            </div>
        );
    }
}
