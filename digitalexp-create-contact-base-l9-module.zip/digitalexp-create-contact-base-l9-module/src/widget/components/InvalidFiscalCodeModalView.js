import React, {Component} from 'react';
import {Modal, ModalUtils} from 'digitalexp-common-components-l9';
import {FormattedMessage} from 'react-intl';
import _uniqueId from 'lodash/uniqueId';
import GenericButtonControlModule, {ExternalizeComponent} from 'digitalexp-generic-button-control-module';
import ClassNames from 'classnames';
import messages from '../CreateContact.i18n';

const {ModalHeader, ModalBody, ModalFooter} = ModalUtils;
const GenericButton = GenericButtonControlModule.Widget;

class InvalidFiscalCodeModalView extends Component {

    constructor(props) {
        super(props);
        this.getModalConfig = this.getModalConfig.bind(this);
        this.getHeaderConfig = this.getHeaderConfig.bind(this);
        this.getFooterBody = this.getFooterBody.bind(this);
        this.getFooterLocateStoreProps = this.getFooterLocateStoreProps.bind(this);
        this.getFooterRetypeProps = this.getFooterRetypeProps.bind(this);
        this.getModalBody = this.getModalBody.bind(this);
        const uniqueId = _uniqueId('CreateContactWidget');
        this.externalExecuteMethods = {
            uniqueId,
            handleLocateStore: `${uniqueId}.handleLocateStore`,
            handleRetypeFiscalCode: `${uniqueId}.handleRetypeFiscalCode`
        };
    }

    componentDidMount() {
        const {
            handleRetypeFiscalCode,
            handleModalClose
        } = this.props;
        ExternalizeComponent.externalizeComponent(this.externalExecuteMethods.handleLocateStore, {
            functionCallback: () => {
                return handleModalClose();
            }
        });
        ExternalizeComponent.externalizeComponent(this.externalExecuteMethods.handleRetypeFiscalCode, {
            functionCallback: () => {
                return handleRetypeFiscalCode();
            }
        });
    }

    getModalConfig() {
        const config = {
            showOverLay: true,
            dialogBoxClass: 'ds-modal--wrapper__medium'
        };
        return config;
    }

    getHeaderConfig() {
        const titleText = <FormattedMessage {...messages.invalid_fiscal_code_modal_header} />;
        return {
            showCloseButton: true,
            closeButtonClass: 'ds-modal--close',
            showTitle: true,
            titleText
        };
    }

    getFooterLocateStoreProps() {
        const buttonClass = ClassNames('ds-btn ds-btn--large ds-btn--secondary');
        const {handleLocateStore} = this.externalExecuteMethods;
        return {
            config: {
                className: buttonClass,
                executemethodKeys: `${handleLocateStore}`
            },
            children: <FormattedMessage {...messages.locate_store_label} />
        };
    }   

    getModalBody() {
        return (
            <div className="ds-heading">
                <h4><FormattedMessage {...messages.invalid_fiscal_code_message_1} /></h4>                
                <div className="ds-heading-text"><FormattedMessage {...messages.invalid_fiscal_code_message_2} /></div>
                <br />
                <div className="ds-heading-text"><FormattedMessage {...messages.invalid_fiscal_code_message_3} /></div>
            </div>
        );
    }    

    getFooterRetypeProps() {
        const buttonClass = ClassNames('ds-btn ds-btn--large ds-btn--primary');        
        const {handleRetypeFiscalCode} = this.externalExecuteMethods;
        return {
            config: {
                className: buttonClass,
                executemethodKeys: `${handleRetypeFiscalCode}`
            },
            children: <FormattedMessage {...messages.retype_label} />
        };
    }

    getFooterBody() {
        return (
            <div>
                <GenericButton
                    {...this.getFooterLocateStoreProps()}
                />
                <GenericButton
                    {...this.getFooterRetypeProps()}
                />
            </div>
        );
    }

    render() {
        const {handleModalClose} = this.props;
        return (
            <Modal config={this.getModalConfig()}>
                <ModalHeader config={this.getHeaderConfig()} handleButtonClick={handleModalClose} />
                <ModalBody>
                    {this.getModalBody()}
                </ModalBody>
                <ModalFooter>
                    {this.getFooterBody()}
                </ModalFooter>
            </Modal>
        );
    }
}

export default InvalidFiscalCodeModalView;
