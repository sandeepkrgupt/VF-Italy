import React, {Component} from 'react';
import DefaultPersonalDetailsCreateView from './PersonalDetailsCreateView';
import DefaultContactSectionCreateView from './ContactSectionCreateView';
import SubmitButtonView from './SubmitButtonView';
import InvalidFiscalCodeModalView from './InvalidFiscalCodeModalView';
import ExistingContactModalView from './ExistingContactModalView';
import ContactVerificationModalView from './ContactVerificationModalView';

class CreateContactComponentView extends Component {
    constructor(props) {
        super(props);
        this.formSubmit = this.formSubmit.bind(this);  
        this.getInvalidFiscalCodeModalProps = this.getInvalidFiscalCodeModalProps.bind(this);     
        this.closeInvalidFiscalCodeModal = this.closeInvalidFiscalCodeModal.bind(this); 
        this.handleRetypeFiscalCode = this.handleRetypeFiscalCode.bind(this);
        this.getExistingContactModalProps = this.getExistingContactModalProps.bind(this);
        this.closeExistingContactCodeModal = this.closeExistingContactCodeModal.bind(this);
        this.handleVerifyBySms = this.handleVerifyBySms.bind(this);
        this.state = {
            showInvalidFiscalCodeModal: false,
            showExistingContactModal: false,
            showContactVerificationModal: false
        };
    }     
    
    getInvalidFiscalCodeModalProps() {
        return {
            handleModalClose: this.closeInvalidFiscalCodeModal,
            handleRetypeFiscalCode: this.handleRetypeFiscalCode
        };
    }

    getExistingContactModalProps() {
        return {
            handleModalClose: this.closeExistingContactCodeModal,
            handleVerifyBySms: this.handleVerifyBySms
        };
    }

    getContactVerificationModalProps = () => {
        return {
            handleModalClose: this.closeContactVerificationModal,
            handleContactVerificationContinue: this.handleContactVerificationContinue,
            callerDetails: this.props.callerDetails
        };
    }

    /**
     * called from invalid fiscal code modal upon cancel
     */
    closeInvalidFiscalCodeModal() {        
        this.setState({showInvalidFiscalCodeModal: false});
        this.props.resetInvalidFiscalCodeTriesCount();
        this.props.clear();
    } 

    /**
     * called from existing contact modal upon cancel
     */
    closeExistingContactCodeModal() {        
        this.setState({showExistingContactModal: false});
        this.props.clear();
    }

    /**
     * called from existing contact modal upon cancel
     */
    closeContactVerificationModal = () => {        
        this.setState({showContactVerificationModal: false});
        this.props.clear();
    }

    /**
     * called from invalid fiscal code modal upon Retype
     */
    handleRetypeFiscalCode() {        
        this.setState({showInvalidFiscalCodeModal: false});
        this.props.resetInvalidFiscalCodeTriesCount();
        this.props.clear();
    }

    /**
     * called from existing contact modal upon verify by sms
     */
    handleVerifyBySms() {        
        this.setState({
            showExistingContactModal: false,
            showContactVerificationModal: true
        });  
    }

    /**
     * called from contact verification modal upon continue
     */
    handleContactVerificationContinue = () => {        
        this.setState({showContactVerificationModal: false});
        const callerDetails = this.props.callerDetails;
        if (callerDetails && callerDetails.individualRef) {
            const {id: contactId} = callerDetails.individualRef;
            this.props.retrieveContact(contactId).then(() => {
                this.updateFormForIdentifiedCustomer();
            });
        }
    }

    updateFormForIdentifiedCustomer = () => {
        const contactDetails = this.props.IdentifiedContactDetails;
        let identification;
        if (contactDetails) {
            console.log(contactDetails);
            if (contactDetails.identification && contactDetails.identification.length) {
                identification = {
                    identificationType: contactDetails.identification[0].identificationType,
                    identificationNumber: contactDetails.identification[0].identificationNumber,
                    nationality: contactDetails.identification[0].nationality,
                    expirationDate: contactDetails.identification[0].expirationDate
                };
            }
            this.props.updateFormValues({
                firstName: contactDetails.firstName,
                lastName: contactDetails.lastName,
                identification,
                nation: contactDetails.nation,
                emailAddress: contactDetails.email && contactDetails.email.emailAddress,
                phoneNumber: contactDetails.phone && contactDetails.phone.phoneNumber,
                preferredLanguage: {
                    name: contactDetails.preferredLanguage && contactDetails.preferredLanguage.name
                },
                preferredContactTime: {
                    name: contactDetails.preferredContactTime && contactDetails.preferredContactTime.name
                },
                preferredContactMethod: {
                    name: contactDetails.preferredContactMethod && contactDetails.preferredContactMethod.name
                }
            });
    /*            this.props.updateFields([{name: 'identification.expirationDate',
                value: contactDetails.identification[0].expirationDate}]); */
        }
    }

    formSubmit = () => {
        const {submitButtonDetails} = this.props;
        const {onSubmit} = submitButtonDetails;
        onSubmit();
    };

    showExistingContactModal = () => {
        this.setState({showExistingContactModal: true});
    }

    showInvalidFiscalCodeModal = () => {
        this.setState({
            showInvalidFiscalCodeModal: true
        });
    }

    isInvalidFiscalTriesReached = () => {
        const maxNumberOfFiscalTries = this.props.config.maxNumberOfFiscalTries;
        if (this.props.invalidFiscalCodeTries === maxNumberOfFiscalTries) {
            return true;
        }
        return false;
    }

    render() {
        const {
            intl,
            getValidationForField,
            formFields,
            personalDetails,
            fiscaleCheck,
            identificationDetails,
            submitButtonDetails,
            config,
            // default view
            PersonalDetailsCreateView = DefaultPersonalDetailsCreateView,
            ContactSectionCreateView = DefaultContactSectionCreateView,
            updateFields,
            findCaller,
            retrieveContact,
            IdentifiedContactDetails,
            updateFormValues,
            getFieldValue,
            contactTypeIdentified,
            clear,
            validateField,
            getFormData,
            updateContactTypeFlag,
            invalidFiscalCodeTries,
            incrementInvalidFiscalCodeTriesCount,
            resetInvalidFiscalCodeTriesCount,
            clearAdditionalContactDetails
        } = this.props;
        return (
            <div>
                <div className="ds-create-customer">
                    <PersonalDetailsCreateView
                        {...personalDetails}
                        identificationDetails={identificationDetails}
                        intl={intl}
                        config={config}
                        fiscaleCheck={fiscaleCheck}
                        formFields={formFields}
                        getValidationForField={getValidationForField}
                        updateFields={updateFields}
                        findCaller={findCaller}
                        showExistingContactModal={this.showExistingContactModal}
                        retrieveContact={retrieveContact}
                        IdentifiedContactDetails={IdentifiedContactDetails}
                        updateFormValues={updateFormValues}
                        getFieldValue={getFieldValue}
                        contactTypeIdentified={contactTypeIdentified}
                        showInvalidFiscalCodeModal={this.showInvalidFiscalCodeModal}
                        validateField={validateField}
                        getFormData={getFormData}
                        updateContactTypeFlag={updateContactTypeFlag}
                        invalidFiscalCodeTries={invalidFiscalCodeTries}
                        incrementInvalidFiscalCodeTriesCount={incrementInvalidFiscalCodeTriesCount}
                        resetInvalidFiscalCodeTriesCount={resetInvalidFiscalCodeTriesCount}
                        clearAdditionalContactDetails={clearAdditionalContactDetails}
                        />
                        
                </div>
                <div className="ds-address-widget">
                    <ContactSectionCreateView
                        {...personalDetails}
                        intl={intl}
                        config={config}
                        formFields={formFields}
                        getValidationForField={getValidationForField}
                        updateFields={updateFields}
                        getFieldValue={getFieldValue}
                        contactTypeIdentified={contactTypeIdentified}
                        findCaller={findCaller}
                        validateField={validateField}
                        getFormData={getFormData}
                        IdentifiedContactDetails={IdentifiedContactDetails}
                        updateContactTypeFlag={updateContactTypeFlag}
                        retrieveContact={retrieveContact}
                        clearAdditionalContactDetails={clearAdditionalContactDetails}
                    />
                </div>
                <SubmitButtonView {...submitButtonDetails} formSubmit={this.formSubmit} config={config} />
                {(this.state.showInvalidFiscalCodeModal || this.isInvalidFiscalTriesReached()) &&
                    <InvalidFiscalCodeModalView {...this.getInvalidFiscalCodeModalProps()} />}
                {this.state.showExistingContactModal && 
                    <ExistingContactModalView {...this.getExistingContactModalProps()} />}
                {this.state.showContactVerificationModal && 
                    <ContactVerificationModalView {...this.getContactVerificationModalProps()} />}
            </div>
        );
    }
}

export default CreateContactComponentView;
