import React, {Component} from 'react';
import {FormField, ComboBox} from 'digitalexp-common-components-l9';
import {FormattedMessage} from 'react-intl';
import _isEmpty from 'lodash/isEmpty';
import _get from 'lodash/get';
import Messages from '../CreateContact.i18n';
import {CONTACT_TYPE_IDENTIFIED, FISCAL_CODE_TYPE} from '../CreateContact.consts';
import TooltipView from './TooltipView';

const {PhoneNumber, Email} = FormField;

export default class ContactSectionCreateView extends Component {
    componentDidMount = () => {
        const {updateFields} = this.props;
        updateFields([{name: 'preferredLanguage.name', value: 'it-IT'}]);
    };

    render() {
        const {
            intl,
            config,
            formFields,
            getValidationForField,
            contactMethods,
            preferredcontactTime,
            preferredLanguage,
            getFieldValue,
            IdentifiedContactDetails
        } = this.props;

        const {MandatoryField, Field} = formFields;

        const getContactTimeAndMethod = () => {
            return (
                <div className="ds-row">
                    <Field
                        Component={ComboBox}
                        label={intl.formatMessage(Messages.preferred_contact_method)}
                        name="preferredContactMethod.name"
                        items={contactMethods}
                        allowItemAdd="true"
                        displayField="displayName"
                        placeholder="Select"
                        searchable={false}
                        config={{
                            hasIcon: true,
                            fieldWrapperClassName: 'col-xs-12 col-sm-4'
                        }}
                        constraints={getValidationForField('preferredContactMethod')}
                        skipConstraints={['presence']}
                    />
                    {config.showPreferredContactTime && (
                        <Field
                            Component={ComboBox}
                            label={intl.formatMessage(Messages.preferred_time)}
                            name="preferredContactTime.name"
                            items={preferredcontactTime}
                            allowItemAdd="true"
                            displayField="displayName"
                            placeholder="Select"
                            searchable={false}
                            config={{
                                hasIcon: true,
                                fieldWrapperClassName: 'col-xs-12 col-sm-4'
                            }}
                            constraints={getValidationForField('preferredContactTime')}
                            skipConstraints={['presence']}
                        />
                    )}
                    <Field
                        Component={ComboBox}
                        label={intl.formatMessage(Messages.preferred_language)}
                        name="preferredLanguage.name"
                        items={preferredLanguage}
                        allowItemAdd="true"
                        displayField="displayName"
                        placeholder="Select"
                        searchable={false}
                        config={{
                            hasIcon: true,
                            fieldWrapperClassName: 'col-xs-12 col-sm-4'
                        }}
                        constraints={getValidationForField('preferredLanguage')}
                        skipConstraints={['presence']}
                    />
                </div>
            );
        };

        const handlePhoneNumberBlur = () => {
            const firstName = this.props.getFieldValue('firstName');
            const secondName = this.props.getFieldValue('lastName');
            const phoneNumber = this.props.getFieldValue('phoneNumber');
            if (this.props.contactTypeIdentified !== CONTACT_TYPE_IDENTIFIED.EXISTING &&
                !_isEmpty(firstName) && 
                !_isEmpty(secondName) && 
                !_isEmpty(phoneNumber)
            ) {
                this.props.validateField({
                    name: 'phoneNumber', 
                    value: phoneNumber, 
                    constraint: getValidationForField('phone')}).then(() => {
                        if (_isEmpty(this.props.getFormData().errors)) {
                            const data = {
                                firstName,
                                secondName,
                                phoneNumber,
                                filters: {
                                    partialDataFlag: true,
                                    noFiscalCodeFlag: FISCAL_CODE_TYPE.ITALIAN
                                }
                            };
                            const findCallerFailureMessage =
                                this.props.intl.formatMessage(Messages.findCallerFailureMessage);
                            this.props.findCaller(data, findCallerFailureMessage).then((response) => {
                                if (!_isEmpty(_get(response, 'callerDetails.individualRef.id'))) {
                                    this.props.retrieveContact(response.callerDetails.individualRef.id);
                                    this.props.updateContactTypeFlag(CONTACT_TYPE_IDENTIFIED.PARTIAL);
                                } else {
                                    this.props.clearAdditionalContactDetails();
                                    this.props.updateContactTypeFlag();
                                }
                            });
                        }                       
                    }                       
                );                              
            }                        
        };

        return (
            <div className="ds-form">
                <fieldset className="ds-form__fieldset">
                    <section className="contact">
                        <div className="ds-row">
                            <div className="col-xs-12">
                                <div className="ds-title__inner ds-row">
                                    <div className="ds-title col-xs-12 col-sm-2">
                                        <span className="ds-title__text">
                                            <FormattedMessage {...Messages.contact_section_header} />
                                        </span>
                                    </div>
                                    {config.showContactDetailsTooltip && (
                                        <div className="col-xs-12 col-sm-10">
                                            <TooltipView
                                                tooltipTextMessageLabel={
                                                    Messages.contact_details_tooltip_link_text
                                                }
                                                id={'contact-details'}
                                                innerComponent={() => {
                                                    return (
                                                        <section className="ds-tooltip-item__content">
                                                            <div className="ds-tooltip__text">
                                                                <FormattedMessage
                                                                    {...Messages.contact_details_tooltip_text}
                                                                />
                                                            </div>
                                                        </section>
                                                    );
                                                }}
                                            />
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                        <div className="ds-row">
                            <MandatoryField
                                Component={Email}
                                label={intl.formatMessage(Messages.email)}
                                config={{fieldIconClassName: '', fieldWrapperClassName: 'col-xs-12 col-sm-6'}}
                                name="emailAddress"
                                type="text"
                                constraints={getValidationForField('email')}
                                disabled={this.props.contactTypeIdentified === CONTACT_TYPE_IDENTIFIED.EXISTING &&
                                !_isEmpty(_get(IdentifiedContactDetails, 'email.emailAddress'))}
                            />
                        </div>
                        <div className="ds-row">
                            <MandatoryField
                                config={{
                                    hasIcon: true,
                                    fieldIconClassName: '',
                                    fieldWrapperClassName: 'col-xs-12 col-sm-6'
                                }}
                                Component={PhoneNumber}
                                type="text"
                                placeholder={intl.formatMessage(Messages.phone_number_prefix)}
                                usePlaceholder="true"
                                label={intl.formatMessage(Messages.phone_number)}
                                name="phoneNumber"
                                constraints={getValidationForField('phone')}
                                disabled={this.props.contactTypeIdentified === CONTACT_TYPE_IDENTIFIED.EXISTING &&
                                !_isEmpty(_get(IdentifiedContactDetails, 'phone.phoneNumber'))}
                                eventListeners={{onBlur: handlePhoneNumberBlur}}
                            />
                            <div className="col-xs-12 col-sm-6" />
                        </div>
                        {getContactTimeAndMethod()}
                    </section>
                </fieldset>
            </div>
        );
    }
}
