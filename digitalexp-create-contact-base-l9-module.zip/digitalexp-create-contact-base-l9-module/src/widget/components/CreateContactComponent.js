import React, {Component} from 'react';
import PropTypes from 'prop-types';
import isEqual from 'lodash/isEqual';
import cloneDeep from 'lodash/cloneDeep';
import isEmpty from 'lodash/isEmpty';
import {FormField, Form} from 'digitalexp-common-components-l9';
import {ExternalizeComponent} from 'digitalexp-generic-button-control-module';
import CreateContactComponentView from
    './CreateContactComponentView';
import defaultMessages from '../CreateContact.i18n';
import {GeneralMessageConfiguration, individualIdentificationType, MONTH_NAME, FiscalDerivedMaxAgeLimit} from
    '../CreateContact.consts';
import CodeFiscale from '../CodeFiscale.utils';

const {FormContainer} = Form;
const {getDefaultValuesFromOptions, MandatoryField, Field} = FormField;

@FormContainer({hasDefaults: true})
export default class CreateContactComponent extends Component {
    static get contextTypes() {
        return {
            config: PropTypes.object,
            intl: PropTypes.object
        };
    }
    constructor(props) {
        super(props);
        this.getCreateCustomerProps = this.getCreateCustomerProps.bind(this);
        this.handleIdentificationChange = this.handleIdentificationChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        const {isFormInvalid = false} = this.props;
        this.getPropsFromFiscalCode = this.getPropsFromFiscalCode.bind(this);
        this.getPropsBirthPlaces = this.getPropsBirthPlaces.bind(this);
        this.getUniqueBirthYear = this.getUniqueBirthYear.bind(this);

        this.state = {
            isFormInvalid,
            savedIdentifications: {},
            currentIdType: ''
        };
        this.prevBirthPlaceCode = '';
    }

    componentWillMount() {        
        this.initializeData();                      
    }

    componentDidMount() {
        if (this.props.externalExecuteMethods) {
            const {externalExecuteMethods: {onCreateContactWidgetSave}} = this.props;
            ExternalizeComponent.externalizeComponent(onCreateContactWidgetSave, {
                functionCallback: () => {
                    return this.handleSubmit();
                }
            });
        }       
    }

    componentWillReceiveProps(newProps) {
        const {identificationTypes, isFormInvalid} = newProps;
        if (this.props.identificationTypes && this.props.identificationTypes.length !== identificationTypes.length) {
            const identificationType = getDefaultValuesFromOptions(identificationTypes);
            this.props.updateField(
                {name: individualIdentificationType, value: identificationType},
            );
        }
        if (!isEqual(this.props.isFormInvalid, isFormInvalid)) {
            this.setState({
                isFormInvalid
            });
        }
    }

    componentWillUpdate() {
        this.initializeData();
    }

    getCreateCustomerHeaderProps() {
        const {config: {showScreenPurposeText}} = this.context;
        return {
            showScreenPurposeText
        };
    }

    getPersonalDetails() {
        const {contactMethods, customerSubTitles, nameTitles,
            preferredcontactTime, preferredLanguage, countries, config} = this.props;
        return {
            contactMethods,
            preferredcontactTime,
            preferredLanguage,
            countries,
            customerSubTitles,
            nameTitles,
            showAddNewContactHeader: config.showAddNewContactHeader
        };
    }

    getIdentificationDetails() {
        const {
            identificationTypes 
        } = this.props;
        const {config: {allowIDDocumentAttachmentByFileBrowser}} = this.context;
        return {
            idDetails: {
                identificationTypes,
                allowIDDocumentAttachmentByFileBrowser,
                handleIdentificationChange: this.handleIdentificationChange
            }
        };
    }

    async getPropsBirthPlaces() {
        const {
            getFieldValue,
            loadBirthPlacesData,
            updateFormErrors,
            intl
        } = this.props;
        const fiscalCodeValue = getFieldValue('fiscalCode');
        const birthPlaceCode = fiscalCodeValue
            .replace(/\s/g, '').substring(11, 15).toUpperCase();
        if (birthPlaceCode !== '' && birthPlaceCode.length === 4) {
            try {
                await loadBirthPlacesData(birthPlaceCode);
            } catch (err) {
                const {errorCode} = err;
                if (errorCode) {
                    updateFormErrors({
                        fiscalCode: [{
                            defaultMessage: intl.formatMessage(defaultMessages.fiscalCode_invalid),
                            id: 'fiscalCode_validation_invalid'
                        }]                        
                    });
                }
            }
            return this.getPropsFromFiscalCode();
        } else if (birthPlaceCode === '') {
            return Promise.reject('Fiscal Code is required');
        }
        return Promise.reject('Invalid Fiscale Code');
    }


    getPropsFromFiscalCode() {
        const self = this;
        return new Promise((resolve, reject) => {
            const {getFieldValue,
                updateFields,
                birthPlaces,
                updateFormErrors,
                intl} = self.props;
            const firstName = getFieldValue('firstName');
            const lastName = getFieldValue('lastName');
            const codeFiscaleVal = getFieldValue('fiscalCode').replace(/\s/g, '');

            if (!birthPlaces) {
                reject('Birth Place Rest Fail');
            }
            if (codeFiscaleVal !== '') {
                if (CodeFiscale.check(codeFiscaleVal)) {
                    const fiscalInfo = CodeFiscale.computeInverse(codeFiscaleVal, birthPlaces);

                    // Code to ensure only 1 value is present in year.
                    if (Array.isArray(fiscalInfo.year) && fiscalInfo.year.length > 1) {
                        const currentYear = (new Date()).getFullYear();
                        const customerBirthYear = fiscalInfo.year.filter((item) => {
                            return (item < currentYear && item > (currentYear - FiscalDerivedMaxAgeLimit));
                        })[0];
                        fiscalInfo.year = customerBirthYear;
                    }

                    fiscalInfo.year = self.getUniqueBirthYear(fiscalInfo.year);

                    let computedNames = null;
                    // Computer fiscale code to cross check (Name & surname field)
                    if (firstName && lastName) {
                        computedNames = `${CodeFiscale.surnameCode(lastName)}${CodeFiscale.nameCode(firstName)}`;
                    }
                    // MONTH_NAME[fiscalInfo.month]
                    const birthDateVal = `${fiscalInfo.day} ${MONTH_NAME[fiscalInfo.month]} ${fiscalInfo.year}`;
                    updateFields([
                            {name: 'gender', value: fiscalInfo.gender},
                            {name: 'birthPlace', value: fiscalInfo.birthplace},
                            {name: 'birthDate', value: birthDateVal},
                            {name: 'fiscalCode', value: codeFiscaleVal}
                    ]);
                    if (computedNames === codeFiscaleVal.substring(0, 6)) {
                        updateFields([
                            {name: 'gender', value: fiscalInfo.gender},
                            {name: 'birthPlace', value: fiscalInfo.birthplace},
                            {name: 'birthDate', value: birthDateVal},
                            {name: 'firstName', value: firstName},
                            {name: 'lastName', value: lastName},
                            {name: 'fiscalCode', value: codeFiscaleVal}
                        ]);
                        return resolve(codeFiscaleVal);
                    } else if (computedNames !== null) {
                        updateFormErrors({
                            fiscalCode: [{
                                defaultMessage: intl.formatMessage(defaultMessages.fiscalCode_invalid),
                                id: 'fiscalCode_validation_invalid'
                            }]                                
                        });                        
                    }
                } else {
                    // To return the 'Invalid fiscale Code';
                    updateFields([
                            {name: 'gender', value: ''},
                            {name: 'birthPlace', value: ''},
                            {name: 'birthDate', value: ''}
                    ]);
                    updateFormErrors({
                        fiscalCode: [{
                            defaultMessage: intl.formatMessage(defaultMessages.fiscalCode_invalid),
                            id: 'fiscalCode_validation_invalid'
                        }]                        
                    });
                }
            }
            return reject('Invalid Fiscale Code');
        });
    }  

    getSubmitButtonDetails() {
        const {config: {showCreateContactSaveButton}} = this.context;
        return {
            showCreateContactSaveButton,
            onSubmit: this.handleSubmit
        };
    }

    getCreateCustomerProps() {
        const {
            isFormInvalid
        } = this.state;
        const {getValidationForField,
            intl,
            setFormInvalid,
            updateFields,
            findCaller,
            retrieveContact,
            IdentifiedContactDetails,
            updateFormValues,
            callerDetails,
            getFieldValue,
            contactTypeIdentified,
            clear,
            validateField,
            getFormData,
            updateContactTypeFlag,
            invalidFiscalCodeTries,
            incrementInvalidFiscalCodeTriesCount,
            resetInvalidFiscalCodeTriesCount,
            clearAdditionalContactDetails
        } = this.props;
        return {
            intl,
            getValidationForField,
            formFields: {MandatoryField, Field},
            createCustomerHeader: this.getCreateCustomerHeaderProps(),
            personalDetails: this.getPersonalDetails(),
            identificationDetails: this.getIdentificationDetails(),
            submitButtonDetails: this.getSubmitButtonDetails(),
            fiscaleCheck: this.getPropsBirthPlaces,
            isFormInvalid,
            setFormInvalid,
            updateFields,
            config: this.props.config,
            findCaller,
            retrieveContact,
            IdentifiedContactDetails,
            updateFormValues,
            callerDetails,
            getFieldValue,
            contactTypeIdentified,
            clear,
            validateField,
            getFormData,
            updateContactTypeFlag,
            invalidFiscalCodeTries,
            incrementInvalidFiscalCodeTriesCount,
            resetInvalidFiscalCodeTriesCount,
            clearAdditionalContactDetails
        };
    }

    getUniqueBirthYear(birthDateValue) {
        let yearVal = '';
        if (birthDateValue.length < 3) {
            if ((parseInt(birthDateValue, 10) + FiscalDerivedMaxAgeLimit) > (new Date()).getYear()) {
                yearVal = parseInt(`19${birthDateValue}`, 10);
            } else {
                yearVal = parseInt(`20${birthDateValue}`, 10);
            }
        }
        return yearVal;
    }    

    generateErrorMessages(validationObject) {
        if (!validationObject.isValid) {
            const err = validationObject.formData.errors;
            this.displayErrorMessage(err);
        }
        return validationObject.isValid;
    } 

    handleSubmit() {
        const {onSubmit, additionalFormData = {}} = this.props;       
        this.props.handleSubmit(onSubmit, additionalFormData);
    }

    handleIdentificationChange(e) {
        const selectedIdType = e.value;
        if (selectedIdType) {
            const isFirstSelect = isEmpty(this.state.savedIdentifications);
            this.saveIdentification(selectedIdType);
            const idDetails = this.state.savedIdentifications[selectedIdType] || {};
            const {identificationNumber = '', issuerName = '', expirationDate = '', issueDate = ''} = idDetails;
            if (!isFirstSelect) {
                this.props.updateFields([
                    {name: 'identification.identificationNumber', value: identificationNumber},
                    {name: 'identification.issuerName', value: issuerName},
                    {name: 'identification.expirationDate', value: expirationDate},
                    {name: 'identification.issueDate', value: issueDate}
                ]);
            }
        }
    }

    saveIdentification(newIdType) {
        if (newIdType !== this.state.currentIdType) {
            const {savedIdentifications} = this.state;
            const newSavedIdentifications = cloneDeep(savedIdentifications);
            const idDetails = this.props.getFieldValue('identification');
            const {identificationNumber = '', issuerName = '', expirationDate = '', issueDate = ''} = idDetails;
            newSavedIdentifications[this.state.currentIdType] = {
                identificationNumber,
                issuerName,
                expirationDate,
                issueDate
            };
            this.setState({
                currentIdType: newIdType,
                savedIdentifications: newSavedIdentifications
            });
        }
    }

    get defaultValues() {
        return {
            identification: {
                identificationType: ''
            },
            preferredContactMethod: {
                name: ''
            },
            preferredContactTime: {
                name: '' 
            },
            preferredLanguage: {
                name: ''
            }            
        };
    }    

    initializeData() {     
        const {shouldRenderFollowingDefaults} = this.props;
        if (!shouldRenderFollowingDefaults) {
            this.props.initializeFormValues(this.defaultValues);
        }        
    }

    displayErrorMessage(err, hasParentArray, fieldNamePrefix) {
        const context = this;
        const {VALIDATION, BUSINESS} = GeneralMessageConfiguration;
        Object.keys(err).forEach((prop) => {
            if (Array.isArray(err[prop])) {
                const errorKey = {};
                errorKey[prop] = err[prop][0];
                context.displayErrorMessage(errorKey, true, fieldNamePrefix);
            } else if (hasParentArray) {
                if (err[prop] && typeof err[prop] !== 'string') {
                    const {errorCategory, fieldLabel} = err[prop];
                    const category = errorCategory === VALIDATION ? VALIDATION : BUSINESS;
                    const errMsg = fieldNamePrefix ? `${fieldNamePrefix} ${fieldLabel}` : fieldLabel;
                    context.props.showGeneralMessage(errMsg, category, errorCategory);
                }
            } else {
                context.displayErrorMessage(err[prop], false, fieldNamePrefix);
            }
        });
    }

    render() {
        const {shouldRenderFollowingDefaults} = this.props;
        if (shouldRenderFollowingDefaults) {
            return (<CreateContactComponentView {...this.getCreateCustomerProps()} />);
        }
        return null;
    }
}
