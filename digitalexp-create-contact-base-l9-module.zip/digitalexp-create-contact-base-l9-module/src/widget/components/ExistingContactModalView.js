import React, {Component} from 'react';
import {Modal, ModalUtils} from 'digitalexp-common-components-l9';
import {FormattedMessage} from 'react-intl';
import _uniqueId from 'lodash/uniqueId';
import GenericButtonControlModule, {ExternalizeComponent} from 'digitalexp-generic-button-control-module';
import ClassNames from 'classnames';
import messages from '../CreateContact.i18n';

const {ModalHeader, ModalBody, ModalFooter} = ModalUtils;
const GenericButton = GenericButtonControlModule.Widget;

class ExistingContactModalView extends Component {

    constructor(props) {
        super(props);
        this.getModalConfig = this.getModalConfig.bind(this);
        this.getHeaderConfig = this.getHeaderConfig.bind(this);
        this.getFooterBody = this.getFooterBody.bind(this);
        this.getFooterNoButtonProps = this.getFooterNoButtonProps.bind(this);
        this.getFooterYesButtonProps = this.getFooterYesButtonProps.bind(this);
        this.getModalBody = this.getModalBody.bind(this);
        const uniqueId = _uniqueId('CreateContactWidget');
        this.externalExecuteMethods = {
            uniqueId,
            handleCreateNewContact: `${uniqueId}.handleCreateNewContact`,
            handleVerifyBySms: `${uniqueId}.handleVerifyBySms`
        };
    }

    componentDidMount() {
        const {
            handleVerifyBySms,
            handleModalClose
        } = this.props;
        ExternalizeComponent.externalizeComponent(this.externalExecuteMethods.handleCreateNewContact, {
            functionCallback: () => {
                return handleModalClose();
            }
        });
        ExternalizeComponent.externalizeComponent(this.externalExecuteMethods.handleVerifyBySms, {
            functionCallback: () => {
                return handleVerifyBySms();
            }
        });
    }

    getModalConfig() {
        const config = {
            showOverLay: true,
            dialogBoxClass: 'ds-modal--wrapper__medium'
        };
        return config;
    }

    getHeaderConfig() {
        const titleText = <FormattedMessage {...messages.existing_contact_header_label} />;
        return {
            showCloseButton: true,
            closeButtonClass: 'ds-modal--close',
            showTitle: true,
            titleText
        };
    }

    getFooterNoButtonProps() {
        const buttonClass = ClassNames('ds-btn ds-btn--large ds-btn--secondary');
        const {handleCreateNewContact} = this.externalExecuteMethods;
        return {
            config: {
                className: buttonClass,
                executemethodKeys: `${handleCreateNewContact}`
            },
            children: <FormattedMessage {...messages.no_create_new_contact_label} />
        };
    }   

    getModalBody() {
        return (
            <div className="ds-heading">
                <h4><FormattedMessage {...messages.existing_contact_message_1} /></h4>                
                <div className="ds-heading-text"><FormattedMessage {...messages.existing_contact_message_2} /></div>
                <div className="ds-heading-text"><FormattedMessage {...messages.existing_contact_message_3} /></div>
                <div className="ds-heading-text"><FormattedMessage {...messages.existing_contact_message_4} /></div>
            </div>
        );
    }    

    getFooterYesButtonProps() {
        const buttonClass = ClassNames('ds-btn ds-btn--large ds-btn--primary');        
        const {handleVerifyBySms} = this.externalExecuteMethods;
        return {
            config: {
                className: buttonClass,
                executemethodKeys: `${handleVerifyBySms}`
            },
            children: <FormattedMessage {...messages.verify_by_sms_label} />
        };
    }

    getFooterBody() {
        return (
            <div>
                <GenericButton
                    {...this.getFooterNoButtonProps()}
                />
                <GenericButton
                    {...this.getFooterYesButtonProps()}
                />
            </div>
        );
    }

    render() {
        const {handleModalClose} = this.props;
        return (
            <Modal config={this.getModalConfig()}>
                <ModalHeader config={this.getHeaderConfig()} handleButtonClick={handleModalClose} />
                <ModalBody>
                    {this.getModalBody()}
                </ModalBody>
                <ModalFooter>
                    {this.getFooterBody()}
                </ModalFooter>
            </Modal>
        );
    }
}

export default ExistingContactModalView;
