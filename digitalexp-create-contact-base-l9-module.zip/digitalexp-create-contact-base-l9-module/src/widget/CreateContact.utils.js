import getConfig, {appConfig} from 'digitalexp-runtime-configuration-l9';
import {Formatter} from 'digitalexp-formatters-l9-module';
import clone from 'lodash/clone';
import Messages from './CreateContact.i18n';
import {GeneralMessageConfiguration} from './CreateContact.consts';

export default class CreateCustomerUtils {
    static getMinMaxValidation(config, intl) {
        const {validatePhoneNumberMinDigits, validatePhoneNumberMaxDigits} = config;
        const phoneNumberMaxDigits = getConfig('phoneNumberMaxDigits');
        const phoneNumberMinDigits = getConfig('phoneNumberMinDigits');
        let phoneMinMaxValidation = {};
        if (validatePhoneNumberMaxDigits) {
            phoneMinMaxValidation = {
                maximum: phoneNumberMaxDigits,
                tooLong: {...Messages.phone_validation_max_length, 
                    ...{defaultMessage: 
                        intl.formatMessage(Messages.phone_validation_max_length, {phoneNumberMaxDigits})
                    },
                    ...{fieldLabel: Messages.contactNumber_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                }
            };
        }

        if (validatePhoneNumberMinDigits) {
            phoneMinMaxValidation = {
                ...phoneMinMaxValidation,
                minimum: phoneNumberMinDigits,
                tooShort: {...Messages.phone_validation_min_length, 
                    ...{defaultMessage: 
                        intl.formatMessage(Messages.phone_validation_min_length, {phoneNumberMinDigits})
                    },
                    ...{fieldLabel: Messages.contactNumber_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                }
            };
        }
        return phoneMinMaxValidation;
    }

    static getPhoneValidations(config) {
        const phoneNumberPrefix = getConfig('phoneNumberPrefix');
        const {validatePhoneNumberPrefix} = config;
        let phoneValidation = {};

        // TODO: add pattern configuration support
        if (validatePhoneNumberPrefix) {
            phoneValidation = {
                format: {
                    pattern: `^[${phoneNumberPrefix}][0-9]+`,
                    flags: 'i',
                    message: {
                        ...Messages.phone_prefix_validation, 
                        ...{fieldLabel: Messages.contactNumber_label.defaultMessage, 
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }
                }
            };
        }
        return phoneValidation;
    }
  
    static getMinAgeValidations(intl, config) {
        const {validateMinimumAge, minimumAge} = config;
        if (validateMinimumAge) {
            return {
                minAge: {
                    age: minimumAge,
                    message: {...Messages.min_age_validation, 
                        ...{defaultMessage: intl.formatMessage(Messages.min_age_validation, {minimumAge})
                        },
                        ...{fieldLabel: Messages.birthDate_label.defaultMessage, 
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }
                }
            };
        }
        return {};
    }

    static validations(intl, config) {
        const {defaultExpirationOffset} = config;
        const firstnameMaxLength = getConfig('firstNameMaxChars');
        const lastnameMaxLength = getConfig('lastNameMaxChars');
        const maxCharsInEmailAddress = getConfig('maxCharsInEmailAddress');
        const maxYearRangeFuture = getConfig('maxYearRangeFuture');
        const {phoneNoFormat, fiscalCodeMaxLength, fiscalCodeMinLength, letterOnly} = appConfig;
        const validation = {
            firstName: {
                presence: {message: {
                    ...Messages.firstname_validation_presence, 
                    ...{fieldLabel: Messages.firstname_label.defaultMessage, 
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }},
                length: {
                    maximum: firstnameMaxLength,
                    tooLong: {
                        ...Messages.firstname_validation_max_length, 
                        ...{fieldLabel: Messages.firstname_label.defaultMessage, 
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }},
                format: {
                    pattern: letterOnly,
                    flags: 'i',
                    message: {
                        ...Messages.firstname_formate_validation,
                        fieldLabel: Messages.firstname_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION
                    }
                }
            },
            lastName: {
                presence: {message: {
                    ...Messages.lastname_validation_presence, 
                    ...{fieldLabel: Messages.lastname_label.defaultMessage, 
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }},
                length: {
                    maximum: lastnameMaxLength,
                    tooLong: {
                        ...Messages.lastname_validation_max_length, 
                        ...{fieldLabel: Messages.lastname_label.defaultMessage, 
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }},
                format: {
                    pattern: letterOnly,
                    flags: 'i',
                    message: {
                        ...Messages.lastname_formate_validation,
                        fieldLabel: Messages.lastname_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION
                    }
                }
            },
            gender: {
                presence: {message: {
                    ...Messages.gender_validation_presence, 
                    ...{fieldLabel: Messages.gender_label.defaultMessage, 
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }}
            },
            birthDate: {
                ...this.getMinAgeValidations(intl, config)
            },
            phone: {
                length: {
                    ...this.getMinMaxValidation(config, intl)
                },
                presence: {message: {
                    ...Messages.phone_validation_presence, 
                    ...{fieldLabel: Messages.contactNumber_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }},
                format: {
                    pattern: phoneNoFormat,
                    flags: 'i',
                    message: {
                        ...Messages.phone_prefix_validation,
                        fieldLabel: Messages.contactNumber_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION
                    }
                },
                ...this.getPhoneValidations(config)
            },
            preferredContactMethod: {
                presence: {message: {
                    ...Messages.preferred_contact_validation_presence, 
                    ...{fieldLabel: Messages.preferredContact_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }}
            },
            preferredContactTime: {
                presence: {message: {
                    ...Messages.preferred_contact_time_validation_presence,
                    ...{fieldLabel: Messages.preferredContactTime_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }}
            },
            preferredLanguage: {
                presence: {message: {
                    ...Messages.preferred_langugage_validation_presence,
                    ...{fieldLabel: Messages.preferredLanguage_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }}
            },
            email: {
                length: {
                    maximum: maxCharsInEmailAddress,
                    tooLong: {...Messages.email_validation_max_length, 
                        ...{fieldLabel: Messages.email_label.defaultMessage, 
                            errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                    }
                },
                optionalEmail: {message: {
                    ...Messages.email_validation_email, 
                    ...{fieldLabel: Messages.email_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                }},
                presence: {
                    message: {
                        ...Messages.email_validation_presence,
                        fieldLabel: Messages.email.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY
                    }
                }
            },           
            idType: {
                selectListPresence: {message: {
                    ...Messages.idType_validation_presence, 
                    ...{fieldLabel: Messages.idType_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }}
            },
            idNumber: {
                presence: {message: {
                    ...Messages.idNumber_validation_presence, 
                    ...{fieldLabel: Messages.idNumber_label.defaultMessage, 
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }},
                format: {
                    pattern: '^[a-z0-9]+',
                    flags: 'i',
                    message: {
                        ...Messages.idNumber_validation_format, 
                        ...{fieldLabel: Messages.idNumber_label.defaultMessage, 
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }
                }
            },
            expirationDate: {
                presence: {message: {
                    ...Messages.expiration_date_validation_presence, 
                    ...{fieldLabel: Messages.expirationDate_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY}
                }},
                format: {
                    pattern: '^[0-9]{4}-[0-9]{2}-[0-9]{2}$',
                    flags: 'i',
                    message: {...Messages.expiration_date_validation,
                        ...{fieldLabel: Messages.expirationDate_label.defaultMessage,
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }
                },
                datetime: {
                    message: {...Messages.expiration_date_validation,
                        ...{fieldLabel: Messages.expirationDate_label.defaultMessage,
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }
                },
                documentExpirationPast: {
                    message: {...Messages.expiration_date_validation_past,
                        ...{fieldLabel: Messages.expirationDate_label.defaultMessage,
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    },
                    expirationDaysOffset: defaultExpirationOffset
                },
                tooLateDate: {
                    yearsLimit: maxYearRangeFuture,
                    message: {...Messages.date_validation_late,
                        ...{fieldLabel: Messages.expirationDate_label.defaultMessage, 
                            errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION}
                    }
                }
            },                     
            fiscalCode: {
                presence: {
                    message: {
                        ...Messages.fiscalCode_validation_presence,
                        fieldLabel: Messages.fiscalCode_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY
                    }
                },
                length: {
                    maximum: fiscalCodeMaxLength,
                    tooLong: {
                        ...Messages.fiscalCode_validation_max_length, 
                        fieldLabel: Messages.fiscalCode_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION
                    },
                    minimum: fiscalCodeMinLength,
                    tooShort: {
                        ...Messages.fiscalCode_invalid,
                        fieldLabel: Messages.fiscalCode_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.FORMAT_VALIDATION
                    }

                }
            },
            nationality: {
                presence: {
                    message: {
                        ...Messages.country_validation_presence,
                        fieldLabel: Messages.nationality_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY
                    }
                }
            },
            documentNationality: {
                presence: {
                    message: {
                        ...Messages.country_validation_presence,
                        fieldLabel: Messages.nationality_label.defaultMessage,
                        errorCategory: GeneralMessageConfiguration.MISSING_MANDATORY
                    }
                }
            }
        };
        return validation;
    }

    static formatIdentificationDates(identification) {
        const newIdentificationDates = clone(identification);
        newIdentificationDates.issueDate = Formatter.formatDateView(identification.issueDate);
        newIdentificationDates.expirationDate = Formatter.formatDateView(identification.expirationDate);
        return newIdentificationDates;
    }
}
