/* eslint no-unused-expressions: 0  prefer-arrow-callback: 0 */
import React from 'react';

import {expect} from 'chai';
import {shallow} from 'enzyme';

import CreateContact from '../src/widget/CreateContact';

export function tests() {
    describe('DigitalExpCreateContactWidget', function() {
        context('when instantiated', function() {
            it('initialization', function() {
                const wrapper = shallow(<CreateContact />);
                expect(wrapper).to.not.be.null;
            }); 
        });
    });
}

export default tests();
