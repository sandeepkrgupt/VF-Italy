const descriptor = {
    displayName: 'digitalexp-create-contact-base-l9-module',
    widgetId: 'digitalexp-create-contact-base-l9-module',
    widgetCategory: 'Digital Experience',
    widgetDomain: 'Care',
    widgetSalesChannel: 'Base',
    widgetDescription: 'None',
    topicName: 'createContact',
    behaviorParams: [   
        {
            groupId: 'create-contact-general-details',
            itemId: 'showAddNewContactHeader',
            displayName: 'Show Add New Contact widget header',
            type: 'boolean',
            description: 'Determine whether to display widget header.',
            defaultValue: false
        },   
        {
            groupId: 'create-contact-general-details',
            itemId: 'showFiscalCodeDerivedParamters',
            displayName: 'Show Fiscal Code Derived Parameters',
            type: 'boolean',
            description: 'Determine whether to display a fiscal code derived parameters.',
            defaultValue: true
        },
        {
            groupId: 'create-contact-general-details',
            itemId: 'showCreateContactSaveButton',
            displayName: 'Show Save Button',
            type: 'boolean',
            description: 'Determine whether to display a save button.',
            defaultValue: false
        },
        {
            groupId: 'create-contact-general-details',
            itemId: 'showFiscalCodeToolTip',
            displayName: 'Show Fiscal Code Tool Tip',
            type: 'boolean',
            description: 'Determine whether to display the fiscal code tool tip.',
            defaultValue: true
        },       
        {
            groupId: 'create-contact-id-details',
            itemId: 'showContactDetailsTooltip',
            displayName: 'Display Contact Details Tooltip',
            type: 'boolean',
            description: 'Display Contact Details Tooltip',
            defaultValue: true
        },
        {
            groupId: 'create-contact-id-details',
            itemId: 'showPreferredContactTime',
            displayName: 'Display Preferred Contact Time',
            type: 'boolean',
            description: 'Display Preferred Contact Time',
            defaultValue: true
        },      
        {
            groupId: 'create-contact-id-details',
            itemId: 'defaultExpirationOffset',
            displayName: 'defaultExpirationOffset',
            type: 'number',
            description: 'defaultExpirationOffset',
            defaultValue: 30
        },
        {
            groupId: 'create-contact-general-details',
            itemId: 'maxNumberOfFiscalTries',
            displayName: 'maxNumberOfFiscalTries',
            type: 'number',
            description: 'maxNumberOfFiscalTries',
            defaultValue: 3
        }
    ],
    outcomes: [],
    content: [       
        {
            itemId: 'save_button',
            type: 'text',
            displayName: 'Label for save button',
            description: 'Label for save button',
            defaultValue: 'Save'
        },
        {
            itemId: 'firstname_validation_max_length',
            type: 'text',
            displayName: 'Validation Message for maxLength',
            description: 'Validation Message for maxLength',
            defaultValue: 'First name needs to have maximum 30 characters'
        },
        {
            itemId: 'min_age_validation',
            type: 'text',
            displayName: 'Validation Message for minimal age on birthday field',
            description: 'Validation Message for minimal age on birthday field',
            defaultValue: 'For example: 31 12 1970, customer must be {minimumAge} or more.'
        },
        {
            itemId: 'phone_prefix_validation',
            type: 'text',
            displayName: 'Validation Message for phone prefix',
            description: 'Validation Message for phone prefix',
            defaultValue: 'Invalid phone entry'
        },
        {
            itemId: 'issued_on_validation',
            type: 'text',
            displayName: 'Validation Message for issued on',
            description: 'Validation Message for issued on',
            defaultValue: 'Invalid issued date entry'
        },
        {
            itemId: 'expiration_date_validation',
            type: 'text',
            displayName: 'Validation Message for phone prefix',
            description: 'Validation Message for phone prefix',
            defaultValue: 'Invalid expiration date entry'
        },
        {
            itemId: 'id_document_mandatory_validation',
            type: 'text',
            displayName: 'Validation Message for mandatory id document',
            description: 'Validation Message for mandatory id document',
            defaultValue: 'Required field'
        },
        {
            itemId: 'id_document_max_file_size_validation',
            type: 'text',
            displayName: 'Validation Message for id document max file size',
            description: 'Validation Message for id document max file size',
            defaultValue: 'Please upload file upto {maxSize}{unitOfMeasure}'
        },
        {
            itemId: 'id_document_valid_file_format_validation',
            type: 'text',
            displayName: 'Validation Message for id document invalid file format',
            description: 'Validation Message for id document invalid file format',
            defaultValue: 'Please upload {formats} or {lastFormat} file type'
        },
        {
            itemId: 'expiration_date_validation_past',
            type: 'text',
            displayName: 'Validation Message for required field',
            description: 'Validation Message for required field',
            defaultValue: 'The identification document has expired, Please provide an updated ID'
        },
        {
            itemId: 'date_validation_early',
            type: 'text',
            displayName: 'Validation Message for required field',
            description: 'Validation Message for required field',
            defaultValue: 'The provided date is too early'
        },
        {
            itemId: 'date_validation_late',
            type: 'text',
            displayName: 'Validation Message for required field',
            description: 'Validation Message for required field',
            defaultValue: 'The provided date is too late'
        },
        {
            itemId: 'edit_button',
            type: 'text',
            displayName: 'Edit button',
            description: 'Edit button',
            defaultValue: 'Edit'
        },
        {
            itemId: 'cancel_button',
            type: 'text',
            displayName: 'Cancel button',
            description: 'Cancel button',
            defaultValue: 'Cancel'
        },
        {
            itemId: 'change_button',
            type: 'text',
            displayName: 'change button',
            description: 'change button',
            defaultValue: 'Change'
        },
        {
            itemId: 'view_more_label',
            type: 'text',
            displayName: 'view more label',
            description: 'view more label',
            defaultValue: 'View More'
        },
        {
            itemId: 'view_less_label',
            type: 'text',
            displayName: 'view less label',
            description: 'view less label',
            defaultValue: 'View Less'
        },
        {
            itemId: 'change_details_modal_button',
            type: 'text',
            displayName: 'duplicate customer modal change details buttons',
            description: 'duplicate customer modal change details buttons',
            defaultValue: 'Change my Contact Details'
        },
        {
            itemId: 'duplicate_customer_error_body',
            type: 'text',
            displayName: 'duplicate customer modal login button',
            description: 'duplicate customer modal login button',
            defaultValue: 'Login'
        },
        {
            itemId: 'email',
            type: 'text',
            displayName: 'Email',
            description: 'Email',
            defaultValue: 'Email'
        },
        {
            itemId: 'confirm_email',
            type: 'text',
            displayName: 'Confirm Email',
            description: 'Confirm Email',
            defaultValue: 'Confirm Email'
        },
        {
            itemId: 'phone_number',
            type: 'text',
            displayName: 'Phone Number',
            description: 'Phone Number',
            defaultValue: 'Phone Number'
        },
        {
            itemId: 'preferred_contact_method',
            type: 'text',
            displayName: 'Preferred Contact Method',
            description: 'Preferred Contact Method',
            defaultValue: 'Preferred Contact Method'
        },
        {
            itemId: 'preferred_time',
            type: 'text',
            displayName: 'Preferred Time',
            description: 'Preferred Time',
            defaultValue: 'Preferred Time'
        },
        {
            itemId: 'preferred_language',
            type: 'text',
            displayName: 'Preferred Time',
            description: 'Preferred Time',
            defaultValue: 'Preferred Language'
        },        
        // override all the translations as no graphic part of the core is used       
        {
            groupId: 'required-field-indicator-view',
            displayName: 'Required field message',
            itemId: 'required_field_indicator_label',
            description: 'Reference text for required field indicator',
            defaultValue: 'Required fields'
        },
        {
            groupId: 'personal-details-view',
            displayName: 'Personal Details section title',
            itemId: 'personal_details',
            description: 'Personal details section title',
            defaultValue: '<span class=\'ds-special\'>Personal</span>Details'
        },
        {
            groupId: 'id-details-view',
            displayName: 'Add a New Contact Section title',
            itemId: 'id_details',
            description: 'Add a New Contact section title',
            defaultValue: 'Add new contact'
        },
        {
            groupId: 'create-contact',
            displayName: 'Marketing permissions Section title',
            itemId: 'marketing_permissions',
            description: 'Marketing permissions section title',
            defaultValue: '<span class=\'ds-special\'>Marketing</span>Permissions'
        },
        {
            groupId: 'personal-details-view',
            displayName: 'First Name',
            itemId: 'firstname_label',
            description: 'Label for FirstName field',
            defaultValue: 'First Name'
        },
        {
            groupId: 'personal-details-view',
            displayName: 'Last Name',
            itemId: 'lastname_label',
            description: 'Label for LastName field',
            defaultValue: 'Last Name'
        },
        {
            groupId: 'personal-details-view',
            displayName: 'Fiscal Code',
            itemId: 'fiscalCode_label',
            description: 'Label for Fiscal Code field',
            defaultValue: 'Fiscal Code'
        },
        {
            groupId: 'personal-details-view',
            displayName: 'Birth Place',
            itemId: 'birthplace_label',
            description: 'Label for birth place field',
            defaultValue: 'BIRTHPLACE'
        },
        {
            groupId: 'personal-details-view',
            displayName: 'Fiscal Code Tooltip Link Text',
            itemId: 'fiscal_code_tooltip_link_text',
            description: 'Label for Fiscal Code Tooltip Link Text',
            defaultValue: 'Don\'t have a fiscal code?'
        },
        {
            groupId: 'personal-details-view',
            displayName: 'Fiscal Code Tooltip Text First Paragraph',
            itemId: 'fiscal_code_tooltip_text_1',
            description: 'Label for Fiscal Code Tooltip Text',
            defaultValue: 'If you do not have a Fiscal Code you need to generate a Fiscal Code yourself.'
        },
        {
            groupId: 'personal-details-view',
            displayName: 'Fiscal Code Tooltip Text Second Paragraph',
            itemId: 'fiscal_code_tooltip_text_2',
            description: 'Label for Fiscal Code Tooltip Text',
            defaultValue: 'After generating the code enter it in the Fiscal Code field.'
        },
        {
            groupId: 'personal-details-view',
            displayName: 'Identification Details Tooltip Link Text',
            itemId: 'id_tooltip_link_text',
            description: 'Label for Identification Details Tooltip Link Text',
            defaultValue: 'Why is it needed?'
        },
        {
            groupId: 'personal-details-view',
            displayName: 'Identification Details Tooltip Text',
            itemId: 'id_tooltip_text',
            description: 'Label for Identification Details Tooltip Text',
            defaultValue: 'To proceed with activation, if you are not already a Vodafone customer, you will need to ' +
            'send us a copy of your identity document (in compliance with Italian Law Decree No. 144 dated 27/07/2005).'
        },
        {
            groupId: 'personal-details-view',
            displayName: 'Contact Details Tooltip Link Text',
            itemId: 'contact_details_tooltip_link_text',
            description: 'Label for Contact Details Tooltip Link Text',
            defaultValue: 'Why do you need my contact details?'
        },
        {
            groupId: 'personal-details-view',
            displayName: 'Contact Details Tooltip Text',
            itemId: 'contact_details_tooltip_text',
            description: 'Label for Contact Details Tooltip Text',
            defaultValue: 'Why do you need my contact details?'
        },
        {
            groupId: 'personal-details-view',
            displayName: 'Gender',
            itemId: 'gender_label',
            description: 'Label for Gender field',
            defaultValue: 'Gender'
        },
        {
            groupId: 'personal-details-view',
            displayName: 'Gender placeholder text',
            itemId: 'gender_label_placeholder',
            description: 'Placeholder for Gender field',
            defaultValue: '(Male/Female)'
        },  
        {
            groupId: 'personal-details-view',
            displayName: 'Birthplace placeholder text',
            itemId: 'birthplace_label_placeholder',
            description: 'Placeholder for Birthplace field',
            defaultValue: '(Birth place)'
        },      
        {
            groupId: 'personal-details-view',
            displayName: 'Date of birth',
            itemId: 'birthDate_label',
            description: 'Label for Date of birth field',
            defaultValue: 'Date of birth'
        },
        {
            groupId: 'personal-details-view',
            displayName: 'Contact Number',
            itemId: 'contactNumber_label',
            description: 'Label for Contact Number field',
            defaultValue: 'Contact Number'
        },
        {
            groupId: 'personal-details-view',
            displayName: 'Email',
            itemId: 'email_label',
            description: 'Label for Email field',
            defaultValue: 'Email'
        },
        {
            groupId: 'personal-details-view',
            displayName: 'Confirm Email',
            itemId: 'confirm_email_label',
            description: 'Label for Email field',
            defaultValue: 'Confirm Email'
        },
        {
            groupId: 'personal-details-view',
            displayName: 'Phone number prefix',
            itemId: 'phone_number_prefix',
            description: 'Placeholder text for phone number prefix',
            defaultValue: '+39'
        },        
        {
            groupId: 'personal-details-view',
            displayName: 'Identification Details Header',
            itemId: 'identification_label',
            description: 'Label for Identification Details section',
            defaultValue: 'Identification Details'
        },
        {
            groupId: 'preferred-contact-details-view',
            displayName: 'Preferred contact method',
            itemId: 'preferredContact_label',
            description: 'Label for Preferred contact method field',
            defaultValue: 'Preferred contact method'
        },
        {
            groupId: 'preferred-contact-details-view',
            displayName: 'Preferred contact time',
            itemId: 'preferredContactTime_label',
            description: 'Label for Preferred contact time field',
            defaultValue: 'Preferred contact time'
        },
        {
            groupId: 'preferred-contact-details-view',
            displayName: 'Preferred language',
            itemId: 'preferredLanguage_label',
            description: 'Label for Preferred contact time field',
            defaultValue: 'Preferred Language'
        },
        {
            groupId: 'preferred-contact-details-view',
            displayName: 'Contact Section Header',
            itemId: 'contact_section_header',
            description: 'Contact Section Header',
            defaultValue: 'Contact'
        },
        {
            groupId: 'id-details-view',
            displayName: 'ID Type',
            itemId: 'idType_label',
            description: 'Label for ID Type field',
            defaultValue: 'Type Of Document'
        },
        {
            groupId: 'id-details-view',
            displayName: 'ID Number',
            itemId: 'idNumber_label',
            description: 'Label for ID Number field',
            defaultValue: 'Document Number'
        },
        {
            groupId: 'id-details-view',
            displayName: 'Issuing Nation',
            itemId: 'issuing_nationality_label',
            description: 'Label for document Nationality field',
            defaultValue: 'Issuing Nation'
        },
        {
            groupId: 'id-details-view',
            displayName: 'Nationality',
            itemId: 'nationality_label',
            description: 'Label for Nationality field',
            defaultValue: 'Nationality'
        },
        {
            groupId: 'id-details-view',
            displayName: 'Document Acquisition',
            itemId: 'document_acquisition',
            description: 'Document Acquisiton Section Header',
            defaultValue: 'Document Acquisition'
        },
        {
            groupId: 'id-details-view',
            displayName: 'Document Note',
            itemId: 'document_note',
            description: 'Note in the Document Acquisition section',
            defaultValue: 'You will be required to present this document in order to activate your Vodafone ' +
            'subscription.'
        },
        {
            groupId: 'id-details-view',
            displayName: 'Document Note Label',
            itemId: 'document_note_label',
            description: 'Document Note Label',
            defaultValue: 'Important:'
        },
        {
            groupId: 'id-details-view',
            displayName: 'Continue Button',
            itemId: 'id_details_continue',
            description: 'Continue Button in ID Details Section',
            defaultValue: 'Continue'
        },
        {
            groupId: 'passport-identification-details-view',
            displayName: 'Issued By',
            itemId: 'issuedBy_label',
            description: 'Label for Issued By field',
            defaultValue: 'Issued By'
        },
        {
            groupId: 'passport-identification-details-view',
            displayName: 'Issued On',
            itemId: 'issuedOn_label',
            description: 'Label for Issued On field',
            defaultValue: 'Issued On'
        },
        {
            groupId: 'passport-identification-details-view',
            displayName: 'Expiration Date',
            itemId: 'expirationDate_label',
            description: 'Label for Expiration Date field',
            defaultValue: 'Expiration Date'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Formate Validation: First Name',
            itemId: 'firstname_formate_validation',
            description: 'Validation Message for first name field',
            defaultValue: 'Invalid First Name'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Formate Validation: Last Name',
            itemId: 'lastname_formate_validation',
            description: 'Validation Message for last name field',
            defaultValue: 'Invalid Last Name'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: First Name',
            itemId: 'firstname_validation_presence',
            description: 'Validation Message for required field',
            defaultValue: 'First name is required'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Last Name',
            itemId: 'lastname_validation_presence',
            description: 'Validation Message for required field',
            defaultValue: 'Last name is required'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Last Name',
            itemId: 'lastname_invalid',
            description: 'Validation Message for required field',
            defaultValue: 'Please insert a valid Last Name'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: First Name',
            itemId: 'firstname_invalid',
            description: 'Validation Message for required field',
            defaultValue: 'Please insert a valid First Name'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Email',
            itemId: 'email_validation_presence',
            description: 'Validation Message for required field',
            defaultValue: 'Email is required'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Confirm Email',
            itemId: 'confirm_email_validation_presence',
            description: 'Validation Message for required field',
            defaultValue: 'Confirm Email is required'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Confirm Email Not Same',
            itemId: 'confirm_email_not_matching',
            description: 'Validation Message for Confirm Email Not Same',
            defaultValue: 'Confirm Email is Not same as Email'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Fiscal Code',
            itemId: 'fiscalCode_validation_presence',
            description: 'Validation Message for required field',
            defaultValue: 'Fiscal Code is required'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Fiscal Code Length',
            itemId: 'fiscalCode_validation_max_length',
            description: 'Validation Message for maxLength',
            defaultValue: 'Fiscal Code needs to have maximum 16 characters'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Invalid Fiscal Code',
            itemId: 'fiscalCode_invalid',
            description: 'Validation Message for fiscal code',
            defaultValue: 'Please insert a valid FISCAL CODE'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Last Name Length',
            itemId: 'lastname_validation_max_length',
            description: 'Validation Message for maxLength',
            defaultValue: 'Last name needs to have maximum 30 characters'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Gender',
            itemId: 'gender_validation_presence',
            description: 'Validation Message for required field',
            defaultValue: 'Gender is required'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: BirthDate',
            itemId: 'birthdate_validation_presence',
            description: 'Validation Message for required field',
            defaultValue: 'Date is required'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Phone number',
            itemId: 'phone_validation_presence',
            description: 'Validation Message for required field',
            defaultValue: 'Phone number is required'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Phone number max length',
            itemId: 'phone_validation_max_length',
            description: 'Validation Message for maxLength',
            defaultValue: 'Phone number needs to have maximum {phoneNumberMaxDigits} digits'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Phone number min length',
            itemId: 'phone_validation_min_length',
            description: 'Validation Message for minLength',
            defaultValue: 'Phone number needs to have minimum {phoneNumberMinDigits} digits'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Preferred contact method',
            itemId: 'preferred_contact_validation_presence',
            description: 'Validation Message for required field',
            defaultValue: 'Preferred contact method is required'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Preferred contact time',
            itemId: 'preferred_contact_time_validation_presence',
            description: 'Validation Message for required field',
            defaultValue: 'Preferred contact time is required'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Email max length',
            itemId: 'email_validation_max_length',
            description: 'Validation Message for maxLength',
            defaultValue: 'Email needs to have maximum 80 characters'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Email Format',
            itemId: 'email_validation_email',
            description: 'Validation Message for Email format',
            defaultValue: 'Please enter a valid Email in the following format: jsmith@example.org'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: ID Type',
            itemId: 'idType_validation_presence',
            description: 'Validation Message for required field',
            defaultValue: 'Document type is required'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: ID Number',
            itemId: 'idNumber_validation_presence',
            description: 'Validation Message for required field',
            defaultValue: 'Document number is required'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: ID Number Format',
            itemId: 'idNumber_validation_format',
            description: 'Validation Message for format field',
            defaultValue: 'Document number is invalid' 
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Issue by',
            itemId: 'issue_by_validation_presence',
            description: 'Validation Message for required field',
            defaultValue: 'Issued by is required'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Issue on',
            itemId: 'issue_on_validation_presence',
            description: 'Validation Message for required field',
            defaultValue: 'Issued on is required'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Expiration date',
            itemId: 'expiration_date_validation_presence',
            description: 'Validation Message for required field',
            defaultValue: 'Expiration date is required'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Address',
            itemId: 'address_validation_presence',
            description: 'Validation Message for required field',
            defaultValue: 'Address is required'
        }, 
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Country',
            itemId: 'country_validation_presence',
            description: 'Validation Message for required field',
            defaultValue: 'Nationality is required'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Country',
            itemId: 'zip_on_validation_presence',
            description: 'Validation Message for required field',
            defaultValue: 'Zip is required'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Validation: Zip max length',
            itemId: 'zip_validation_max_length',
            description: 'Validation Message for maxLength',
            defaultValue: 'Zip needs to have maximum 6 characters'
        },
        {
            groupId: 'create-contact',
            displayName: 'Male Gender',
            itemId: 'gender_type_male',
            description: 'Gender option Male',
            defaultValue: 'Male'
        },
        {
            groupId: 'create-contact',
            displayName: 'Female Gender',
            itemId: 'gender_type_female',
            description: 'Gender option female',
            defaultValue: 'Female'
        },
        {
            groupId: 'create-contact',
            displayName: 'contact Post',
            itemId: 'contact_medium_post',
            description: 'Contact option Post',
            defaultValue: 'Post'
        },
        {
            groupId: 'create-contact',
            displayName: 'Contact Phone',
            itemId: 'contact_medium_phone',
            description: 'Contact option Phone',
            defaultValue: 'Phone'
        },
        {
            groupId: 'create-contact',
            displayName: 'Contact Email',
            itemId: 'contact_medium_email',
            description: 'Contact option email',
            defaultValue: 'Email'
        },
        {
            groupId: 'error-modal',
            displayName: 'Incorrect MSISDN Header',
            itemId: 'incorrect_msisdn_number',
            description: 'Incorrect MSISDN Header Label',
            defaultValue: 'INCORRECT TELEPHONE NUMBER'
        },
        {
            groupId: 'error-modal',
            displayName: 'Incorrect MSISDN Modal Sub-header',
            itemId: 'incorrect_msisdn_number_sub_header',
            description: 'Incorrect MSISDN Sub-Header Label',
            defaultValue: 'THIS ORDER CANNOT BE COMPLETED'
        },
        {
            groupId: 'error-modal',
            displayName: 'incorrect MSISDN Modal Description Text',
            itemId: 'incorrect_msisdn_number_description_text',
            description: 'Incorrect MSISDN Modal Text',
            defaultValue: `This order includes discounts applied to telephone number +{MSISDN}.
                Unfortunately, this number is not associated with your account.
                To check whether you are eligible for a discount you must begin a new order.
                Please return to the catalog and correct the telephone number or remove it
                completely.
                Click "Continue" to proceed.`
        },,
        {
            groupId: 'error-modal',
            displayName: 'Incompatible PM Modal Header',
            itemId: 'incompatible_pm_header',
            description: 'Incompatible Payment Method Modal Header',
            defaultValue: 'PAYMENT METHOD NOTIFICATION.'
        },
        {
            groupId: 'error-modal',
            displayName: 'Incompatible PM Modal Sub-header',
            itemId: 'incompatible_pm_sub_header',
            description: 'Incompatible Payment Method Modal Sub-Header',
            defaultValue: 'Oops, it seems that you already have a credit card in your account'
        },
        {
            groupId: 'error-modal',
            displayName: 'Incompatible PM Modal Description Text',
            itemId: 'incompatible_pm__description_text',
            description: 'Incompatible Payment Method Modal Description Text',
            defaultValue: `It appears that you are already a Vodafone customer and there is a credit card
                assigned to your account.
                So the order cannot be completed using the selected payment method (IBAN)
                Don't worry you can continue with your credit card and keep all the benefits and good
                prices.
                If you do not wish to continue with a credit card please contact Vodafone call center
                at 190.
                Your order number is {orderId}.`
        },
        {
            groupId: 'error-modal',
            displayName: 'Incorrect MSISDN Modal Button Label',
            itemId: 'incorrect_msisdn_button_label',
            description: 'Incorrect MSISDN Modal Button Label',
            defaultValue: 'Continue'
        },
        {
            groupId: 'error-modal',
            displayName: 'Incompatible PM Modal Button Label',
            itemId: 'incompatible_pm_button_label',
            description: 'Incompatible PM Modal Button Label',
            defaultValue: 'Continue With Credit Card'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'createContactErrorMessage',
            itemId: 'createContactErrorMessage',
            description: 'cerate Contact Error Message',
            defaultValue: 'Contact could not be created.'
        },
        {
            groupId: 'invalid_fiscal_code_popup',
            itemId: 'retype_label',
            displayName: 'Retype label',
            description: 'Retype label',
            defaultValue: 'Retype'
        },
        {
            groupId: 'invalid_fiscal_code_popup',
            itemId: 'locate_store_label',
            displayName: 'Locate store label',
            description: 'Locate store label',
            defaultValue: 'Locate a Store'
        },
        {
            groupId: 'invalid_fiscal_code_popup',
            itemId: 'invalid_fiscal_code_modal_header',
            displayName: 'Invalid Fiscal Code Modal Header',
            description: 'Invalid Fiscal Code Modal Header',
            defaultValue: 'Non valid Fiscal Code'
        },
        {
            groupId: 'invalid_fiscal_code_popup',
            itemId: 'invalid_fiscal_code_message_1',
            displayName: 'Invalid Fiscal Code Message 1',
            description: 'Invalid Fiscal Code Message 1',
            defaultValue: 'It seems you are trying to enter a non valid Fiscal code.'
        },
        {
            groupId: 'invalid_fiscal_code_popup',
            itemId: 'invalid_fiscal_code_message_2',
            displayName: 'Invalid Fiscal Code Message 2',
            description: 'Invalid Fiscal Code Message 2',
            defaultValue: 'Self service is available for citizens only.'
        },
        {
            groupId: 'invalid_fiscal_code_popup',
            itemId: 'invalid_fiscal_code_message_3',
            displayName: 'Invalid Fiscal Code Message 3',
            description: 'Invalid Fiscal Code Message 3',
            defaultValue: `If you have fiscal code you can try to type again. 
                If you don't have fiscal code please reach one on our brand store for help and further information.`
        },
        {
            groupId: 'existing_contact_popup',
            itemId: 'verify_by_sms_label',
            displayName: 'Verify by SMS label',
            description: 'Verify by SMS label',
            defaultValue: 'Yes, verify by SMS'
        },
        {
            groupId: 'existing_contact_popup',
            itemId: 'existing_contact_message_1',
            displayName: 'Existing Contact Message 1',
            description: 'Existing Contact Message 1',
            defaultValue: 'It seems the information provided belongs to that of an existing contact.'
        },
        {
            groupId: 'existing_contact_popup',
            itemId: 'existing_contact_message_2',
            displayName: 'Existing Contact Message 2',
            description: 'Existing Contact Message 2',
            defaultValue: 'You can continue with the contact details after a short verification via SMS or call center at 190.'
        },
        {
            groupId: 'existing_contact_popup',
            itemId: 'existing_contact_message_3',
            displayName: 'Existing Contact Message 3',
            description: 'Existing Contact Message 3',
            defaultValue: 'You can also go back update the contact information and create a new contact.'
        },
        {
            groupId: 'existing_contact_popup',
            itemId: 'existing_contact_message_4',
            displayName: 'Existing Contact Message 4',
            description: 'Existing Contact Message 4',
            defaultValue: 'Would you like to verify the contact details by SMS?'
        },
        {
            groupId: 'existing_contact_popup',
            itemId: 'no_create_new_contact_label',
            displayName: 'No, Create New Contact label',
            description: 'No, Create New Contact label',
            defaultValue: 'No, create new contact'
        },
        {
            groupId: 'existing_contact_popup',
            itemId: 'existing_contact_header_label',
            displayName: 'Existing Contact Header label',
            description: 'Existing Contact Header label',
            defaultValue: 'Is this an existing contact?'
        },
        {
            groupId: 'contact_verification_popup',
            itemId: 'contact_verification_continue_label',
            displayName: 'Contact Verification Continue label',
            description: 'Contact Verification Continue label',
            defaultValue: 'Continue'
        },
        {
            groupId: 'contact_verification_popup',
            itemId: 'contact_verification_message_1',
            displayName: 'Contact Verification Message 1',
            description: 'Contact Verification Message 1',
            defaultValue: 'To insure your privacy we sent you an SMS with a 4 digit verification code to number: +{phoneNumber}'
        },
        {
            groupId: 'contact_verification_popup',
            itemId: 'enter_the_code_label',
            displayName: 'Enter the code label',
            description: 'Enter the code label',
            defaultValue: 'Enter the code'
        },
        {
            groupId: 'contact_verification_popup',
            itemId: 'contact_verification_message_2',
            displayName: 'Contact Verification Message 2',
            description: 'Contact Verification Message 2',
            defaultValue: `Didn't receive the code?`
        },
        {
            groupId: 'contact_verification_popup',
            itemId: 'resend_code_label',
            displayName: 'Resend Code label',
            description: 'Resend Code label',
            defaultValue: 'Resend code'
        },
        {
            groupId: 'contact_verification_popup',
            itemId: 'contact_verification_cancel_label',
            displayName: 'Contact Verification Cancel label',
            description: 'Contact Verification Cancel label',
            defaultValue: 'Cancel'
        },
        {
            groupId: 'contact_verification_popup',
            itemId: 'contact_verification_header',
            displayName: 'Contact Verification Header',
            description: 'Contact Verification Header',
            defaultValue: 'Contact Verification'
        },
        {
            groupId: 'create-contact-validation',
            itemId: 'findCallerFailureMessage',
            displayName: 'findCallerFailureMessage',
            description: 'find caller failure',
            defaultValue: 'Something went wrong. Please try again'
        }
    ],
    groups: [
        {
            groupId: 'error-modal',
            displayName: 'Error Modal'
        },
        {
            groupId: 'create-contact',
            displayName: 'Create Contact'
        },
        {
            groupId: 'create-contact-validation',
            displayName: 'Create Contact Validation'
        },
        {
            groupId: 'passport-identification-details-view',
            displayName: 'Identification Details'
        },
        {
            groupId: 'id-details-view',
            displayName: 'Id Details'
        },
        {
            groupId: 'preferred-contact-details-view',
            displayName: 'Preferred Contact Details'
        },
        {
            groupId: 'personal-details-view',
            displayName: 'Personal Details'
        },
        {
            groupId: 'required-field-indicator-view',
            displayName: 'Required Field Indicator'
        },
        {
            groupId: 'create-contact-id-details',
            displayName: 'Create Contact ID Details Parameters'
        },
        {
            groupId: 'create-contact-general-details',
            displayName: 'Create Contact General Details Parameters'
        },
        {
            groupId: 'invalid_fiscal_code_popup',
            displayName: 'Invalid Fiscal Code Modal'
        },
        {
            groupId: 'existing_contact_popup',
            displayName: 'Existing Contact Modal'
        },
        {
            groupId: 'contact_verification_popup',
            displayName: 'Contact Verification Popup'
        }
    ],
    initializationParams: [
        {
            itemId: 'customerId',
            displayName: 'Customer ID',
            type: 'text',
            description: '',
            defaultValue: '',
            enableUrlInput: true
        }
    ],
    stateParams: [],
    availableActions: []
};

module.exports = descriptor;
